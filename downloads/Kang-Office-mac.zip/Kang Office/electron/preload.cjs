const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("kangDesktop", {
  openSite: (url) => ipcRenderer.invoke("open-site", url),
});
