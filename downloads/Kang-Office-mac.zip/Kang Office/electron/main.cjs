const { app, BrowserWindow, ipcMain, Menu, shell } = require("electron");
const path = require("path");

const ALLOWED_UPGRADE_HOSTS = new Set([
  "kang998851.github.io",
  "kangstudio.github.io",
  "www.kangstudio.com",
  "kangstudio.com",
]);

function createWindow() {
  const win = new BrowserWindow({
    width: 1240,
    height: 820,
    minWidth: 960,
    minHeight: 680,
    backgroundColor: "#0a0a0a",
    title: "Kang Office",
    titleBarStyle: "hiddenInset",
    trafficLightPosition: { x: 16, y: 18 },
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  win.loadFile(path.join(__dirname, "../src/index.html"));
}

app.whenReady().then(() => {
  app.setName("Kang Office");
  if (process.platform !== "darwin") Menu.setApplicationMenu(null);
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

ipcMain.handle("open-site", async (_event, url) => {
  let parsed;
  try {
    parsed = new URL(String(url));
  } catch {
    return false;
  }
  if (parsed.protocol !== "https:") return false;
  if (!ALLOWED_UPGRADE_HOSTS.has(parsed.hostname)) return false;
  await shell.openExternal(parsed.toString());
  return true;
});
