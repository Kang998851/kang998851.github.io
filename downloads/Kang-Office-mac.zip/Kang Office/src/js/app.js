import { FILTERS, aboutView, chromeView, editView, footView, homeView, listView, loginView, templatesView, todosPreviewPage } from "./views.js";
import { UPGRADE_URL } from "./config.js";
import {
  createMeeting,
  createQuote,
  createReport,
  createTodo,
  emptyAction,
  emptyItem,
  exportName,
  filterTodos,
  lastReport,
  lineSubtotal,
  meetingMarkdown,
  meetingPlain,
  meetingPreview,
  mergeUnique,
  nextStatus,
  openTodos,
  quoteCsv,
  quoteMarkdown,
  quotePlain,
  quotePreview,
  quoteTotal,
  reportMarkdown,
  reportPlain,
  reportPreview,
  selectedActions,
  sortByUpdated,
  todosMarkdown,
  todosPlain,
  todosPreview,
} from "./docs.js";
import { loadState, saveState } from "./storage.js";
import { copyText, downloadText, filled, money, setPath, stamp, weekRangeFrom } from "./util.js";
import { createAccount, emptyAccount, hasPassword, shouldUnlock, startGuest, unlockAccount } from "./auth.js";

const ui = {
  view: "login",
  loginMode: "create",
  loginError: "",
  module: "",
  mode: "edit",
  id: "",
  filter: "today",
};

const state = loadState();
state.meetings = sortByUpdated(state.meetings);
state.reports = sortByUpdated(state.reports);
state.quotes = sortByUpdated(state.quotes);
state.todos = sortByUpdated(state.todos);
if (!state.trialStartedAt) state.trialStartedAt = new Date().toISOString().slice(0, 10);
if (!state.account) state.account = emptyAccount();

let sessionOpen = shouldUnlock(state.account);
ui.view = sessionOpen ? "home" : "login";
ui.loginMode = hasPassword(state.account) ? "enter" : "create";

const chromeEl = document.getElementById("chrome");
const viewEl = document.getElementById("view");
const footEl = document.getElementById("foot");
const toastEl = document.getElementById("toast");

document.body.classList.toggle("electron", Boolean(window.kangDesktop));

chromeEl.addEventListener("click", onClick);
viewEl.addEventListener("click", onClick);
viewEl.addEventListener("submit", onSubmit);
viewEl.addEventListener("input", onInput);
viewEl.addEventListener("change", onChange);
document.addEventListener("keydown", onKey);

render();

function persist() {
  saveState(state);
}

async function onSubmit(event) {
  const form = event.target.closest("[data-form=login]");
  if (!form) return;
  event.preventDefault();
  const name = form.name?.value || "";
  const password = form.password?.value || "";
  const confirm = form.confirm?.value || "";
  const stay = Boolean(form.stay?.checked);
  const creating = ui.loginMode === "create";
  if (!creating && !hasPassword(state.account)) {
    ui.loginError = "这台电脑还没有账户。请先创建，或先试用。";
    render();
    return;
  }
  if (creating) {
    if (password !== confirm) {
      ui.loginError = "两次密码不一致。";
      render();
      return;
    }
    const result = await createAccount(name, password, stay);
    if (!result.ok) {
      ui.loginError = result.error;
      render();
      return;
    }
    enterApp(result.account);
    return;
  }
  const result = await unlockAccount(state.account, password, stay);
  if (!result.ok) {
    ui.loginError = result.error;
    render();
    return;
  }
  enterApp(result.account);
}

function enterApp(account) {
  state.account = account;
  sessionOpen = true;
  ui.loginError = "";
  ui.view = "home";
  persist();
  render();
}

function render() {
  chromeEl.innerHTML = chromeView(ui, state);
  footEl.innerHTML = footView();
  document.body.classList.toggle("gate", ui.view === "login");
  viewEl.className = ui.view === "login" ? "gate-mode" : "";
  if (ui.view === "login") viewEl.innerHTML = loginView(ui, state);
  else if (ui.view === "home") viewEl.innerHTML = homeView(state);
  else if (ui.view === "about") viewEl.innerHTML = aboutView(state);
  else if (ui.view === "templates") viewEl.innerHTML = templatesView(ui);
  else if (ui.view === "preview-todos") viewEl.innerHTML = todosPreviewPage(ui, state);
  else if (ui.view === "edit") viewEl.innerHTML = editView(ui, state);
  else viewEl.innerHTML = listView(ui, state);
  viewEl.scrollTop = 0;
}

function toast(message) {
  toastEl.textContent = message;
  toastEl.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => {
    toastEl.hidden = true;
  }, 1800);
}

function currentDoc() {
  const list = collection();
  return list.find((item) => item.id === ui.id);
}

function collection() {
  if (ui.module === "meetings") return state.meetings;
  if (ui.module === "reports") return state.reports;
  if (ui.module === "quotes") return state.quotes;
  if (ui.module === "todos") return state.todos;
  return [];
}

function go(next) {
  if (!sessionOpen) {
    ui.view = "login";
    render();
    return;
  }
  ui.view = next.view || ui.view;
  if (next.module != null) ui.module = next.module;
  if (next.id != null) ui.id = next.id;
  if (next.mode != null) ui.mode = next.mode;
  if (next.filter != null) ui.filter = next.filter;
  if (ui.view === "home" || ui.view === "list") {
    state.meetings = sortByUpdated(state.meetings);
    state.reports = sortByUpdated(state.reports);
    state.quotes = sortByUpdated(state.quotes);
    state.todos = sortByUpdated(state.todos);
  }
  render();
}

function onClick(event) {
  const btn = event.target.closest("[data-act]");
  if (!btn) return;
  const act = btn.dataset.act;

  if (act === "login-mode") {
    ui.loginMode = btn.dataset.mode;
    ui.loginError = "";
    render();
    return;
  }
  if (act === "trial") {
    const form = document.querySelector("[data-form=login]");
    if (hasPassword(state.account)) {
      sessionOpen = true;
      ui.loginError = "";
      ui.view = "home";
      render();
      return;
    }
    enterApp(startGuest(form?.name?.value || "", form?.stay?.checked));
    return;
  }
  if (act === "logout") {
    sessionOpen = false;
    state.account = { ...state.account, stay: false };
    ui.view = "login";
    ui.loginMode = hasPassword(state.account) ? "enter" : "create";
    ui.loginError = "";
    persist();
    render();
    return;
  }
  if (act === "clear-account") {
    if (!window.confirm("清除本机账户后需重新创建。工作资料不会删除。确定？")) return;
    state.account = emptyAccount();
    sessionOpen = false;
    ui.view = "login";
    ui.loginMode = "create";
    ui.loginError = "";
    persist();
    render();
    return;
  }
  if (act === "go") {
    go({
      view: btn.dataset.view,
      module: btn.dataset.module || (btn.dataset.view === "home" || btn.dataset.view === "about" ? "" : ui.module),
      id: "",
      mode: "edit",
    });
    return;
  }
  if (act === "new") {
    if (ui.module === "todos") {
      const doc = createTodo();
      state.todos.unshift(doc);
      persist();
      go({ view: "edit", id: doc.id, mode: "edit" });
      return;
    }
    go({ view: "templates", id: "" });
    return;
  }
  if (act === "pick-template") {
    const templateId = btn.dataset.template;
    let doc;
    if (ui.module === "meetings") doc = createMeeting(templateId);
    else if (ui.module === "reports") doc = createReport(templateId);
    else doc = createQuote(templateId);
    collection().unshift(doc);
    persist();
    go({ view: "edit", id: doc.id, mode: "edit" });
    return;
  }
  if (act === "open") {
    go({ view: "edit", id: btn.dataset.id, mode: "edit" });
    return;
  }
  if (act === "preview") {
    go({ view: "preview-todos" });
    return;
  }
  if (act === "toggle-mode") {
    ui.mode = ui.mode === "preview" ? "edit" : "preview";
    render();
    return;
  }
  if (act === "filter") {
    ui.filter = btn.dataset.filter;
    render();
    return;
  }
  if (act === "region") {
    state.region = btn.dataset.region;
    persist();
    render();
    return;
  }
  if (act === "open-site") {
    openSite(btn.dataset.url || UPGRADE_URL);
    return;
  }
  if (act === "add-line") {
    const doc = currentDoc();
    if (!doc) return;
    const field = btn.dataset.field;
    doc[field] = [...(doc[field] || []), ""];
    touch(doc);
    persist();
    render();
    return;
  }
  if (act === "remove-line") {
    const doc = currentDoc();
    if (!doc) return;
    const field = btn.dataset.field;
    const index = Number(btn.dataset.index);
    const list = [...(doc[field] || [])];
    list.splice(index, 1);
    doc[field] = list.length ? list : [""];
    touch(doc);
    persist();
    render();
    return;
  }
  if (act === "add-action") {
    const doc = currentDoc();
    if (!doc) return;
    doc.actions = [...(doc.actions || []), emptyAction()];
    touch(doc);
    persist();
    render();
    return;
  }
  if (act === "remove-action") {
    const doc = currentDoc();
    if (!doc) return;
    const index = Number(btn.dataset.index);
    const list = [...(doc.actions || [])];
    list.splice(index, 1);
    doc.actions = list.length ? list : [emptyAction()];
    touch(doc);
    persist();
    render();
    return;
  }
  if (act === "add-item") {
    const doc = currentDoc();
    if (!doc) return;
    doc.items = [...(doc.items || []), emptyItem()];
    touch(doc);
    persist();
    render();
    return;
  }
  if (act === "remove-item") {
    const doc = currentDoc();
    if (!doc) return;
    const index = Number(btn.dataset.index);
    const list = [...(doc.items || [])];
    list.splice(index, 1);
    doc.items = list.length ? list : [emptyItem()];
    touch(doc);
    persist();
    render();
    return;
  }
  if (act === "delete") {
    if (!window.confirm("删除后无法恢复。确定删除？")) return;
    const list = collection();
    const index = list.findIndex((item) => item.id === ui.id);
    if (index >= 0) list.splice(index, 1);
    persist();
    go({ view: "list", id: "" });
    toast("已删除");
    return;
  }
  if (act === "copy") {
    copyCurrent().then((ok) => toast(ok ? "已复制" : "复制失败"));
    return;
  }
  if (act === "export") {
    exportCurrent(btn.dataset.format);
    return;
  }
  if (act === "transfer-meeting") {
    transferMeeting();
    return;
  }
  if (act === "transfer-report") {
    transferReport();
    return;
  }
  if (act === "import-last-report") {
    importLastReport();
    return;
  }
  if (act === "import-open-todos") {
    importOpenTodos();
    return;
  }
  if (act === "cycle-status") {
    const todo = state.todos.find((item) => item.id === btn.dataset.id);
    if (!todo) return;
    todo.status = nextStatus(todo.status);
    touch(todo);
    persist();
    render();
  }
}

function onInput(event) {
  const el = event.target;
  if (!el.dataset.field) return;
  applyField(el);
  persist();
  refreshPreview();
}

function onChange(event) {
  const el = event.target;
  if (!el.dataset.field) return;
  applyField(el);
  const doc = currentDoc();
  if (el.dataset.rerender === "week" && doc && ui.module === "reports") {
    const week = weekRangeFrom(doc.weekStart);
    doc.weekStart = week.start;
    doc.weekEnd = week.end;
  }
  persist();
  if (el.dataset.rerender) render();
  else refreshPreview();
}

function onKey(event) {
  if (event.key === "Escape" && ui.view !== "home" && ui.view !== "login") {
    if (ui.view === "edit") go({ view: "list", id: "" });
    else go({ view: "home", module: "", id: "" });
  }
}

function applyField(el) {
  const doc = currentDoc();
  if (!doc) return;
  const path = el.dataset.field;
  let value = el.type === "checkbox" ? el.checked : el.value;
  if (path.endsWith(".qty") || path.endsWith(".price")) value = Number(el.value) || 0;
  setPath(doc, path, value);
  touch(doc);
}

function touch(doc) {
  doc.updatedAt = stamp();
}

function refreshPreview() {
  const doc = currentDoc();
  const preview = document.getElementById("live-preview");
  if (preview && doc) {
    if (ui.module === "meetings") preview.innerHTML = meetingPreview(doc);
    else if (ui.module === "reports") preview.innerHTML = reportPreview(doc);
    else if (ui.module === "quotes") preview.innerHTML = quotePreview(doc);
    else preview.innerHTML = todosPreview([doc], doc.title || "未命名待办");
  }
  if (doc && ui.module === "quotes") {
    const total = document.getElementById("quote-total");
    if (total) total.textContent = money(quoteTotal(doc), doc.currency);
    document.querySelectorAll("[data-subtotal]").forEach((cell) => {
      const i = Number(cell.dataset.subtotal);
      const item = doc.items?.[i];
      if (item) cell.textContent = money(lineSubtotal(item), doc.currency);
    });
  }
}

function payload() {
  if (ui.view === "preview-todos") {
    const label = FILTERS.find((item) => item.id === ui.filter)?.label || "今天";
    const rows = filterTodos(state.todos, ui.filter);
    return {
      md: todosMarkdown(rows, label),
      txt: todosPlain(rows, label),
      name: exportName("todos", label),
    };
  }
  const doc = currentDoc();
  if (!doc) return null;
  if (ui.module === "meetings") {
    return { md: meetingMarkdown(doc), txt: meetingPlain(doc), name: exportName("meeting", doc) };
  }
  if (ui.module === "reports") {
    return { md: reportMarkdown(doc), txt: reportPlain(doc), name: exportName("report", doc) };
  }
  if (ui.module === "quotes") {
    return {
      md: quoteMarkdown(doc),
      txt: quotePlain(doc),
      csv: quoteCsv(doc),
      name: exportName("quote", doc),
    };
  }
  return {
    md: todosMarkdown([doc], doc.title || "待办"),
    txt: todosPlain([doc], doc.title || "待办"),
    name: exportName("todos", doc.title || "待办"),
  };
}

async function copyCurrent() {
  const data = payload();
  if (!data) return false;
  return copyText(data.md);
}

function exportCurrent(format) {
  const data = payload();
  if (!data) return;
  if (format === "csv") {
    if (!data.csv) {
      toast("仅报价单支持 CSV");
      return;
    }
    downloadText(`${data.name}.csv`, data.csv, "text/csv;charset=utf-8");
    toast("已导出 CSV");
    return;
  }
  if (format === "txt") {
    downloadText(`${data.name}.txt`, data.txt, "text/plain;charset=utf-8");
    toast("已导出文本");
    return;
  }
  downloadText(`${data.name}.md`, data.md, "text/markdown;charset=utf-8");
  toast("已导出 Markdown");
}

function transferMeeting() {
  const doc = currentDoc();
  if (!doc) return;
  const items = selectedActions(doc);
  if (!items.length) {
    toast("请先勾选尚未转入的事项");
    return;
  }
  items.forEach((item) => {
    state.todos.unshift(
      createTodo({
        title: item.owner.trim() ? `${item.title.trim()} · ${item.owner.trim()}` : item.title.trim(),
        due: item.due,
        source: "meeting",
        sourceId: doc.id,
        status: "open",
      }),
    );
    item.transferred = true;
    item.selected = false;
  });
  touch(doc);
  persist();
  render();
  toast(`已转入 ${items.length} 项待办`);
}

function transferReport() {
  const doc = currentDoc();
  if (!doc) return;
  const items = filled(doc.next);
  const existing = new Set(
    state.todos.filter((todo) => todo.source === "report" && todo.sourceId === doc.id).map((todo) => todo.title),
  );
  const fresh = items.filter((title) => !existing.has(title));
  if (!fresh.length) {
    toast("没有可转入的新计划");
    return;
  }
  fresh.forEach((title) => {
    state.todos.unshift(
      createTodo({
        title,
        due: doc.weekEnd,
        source: "report",
        sourceId: doc.id,
        status: "open",
      }),
    );
  });
  persist();
  render();
  toast(`已转入 ${fresh.length} 项待办`);
}

function importLastReport() {
  const doc = currentDoc();
  if (!doc) return;
  const prev = lastReport(state.reports, doc);
  if (!prev) {
    toast("没有更早的周报");
    return;
  }
  doc.done = mergeUnique(doc.done, prev.next);
  touch(doc);
  persist();
  render();
  toast("已带入上周计划");
}

function importOpenTodos() {
  const doc = currentDoc();
  if (!doc) return;
  const titles = openTodos(state.todos).map((item) => item.title.trim());
  if (!titles.length) {
    toast("没有未完成待办");
    return;
  }
  doc.done = mergeUnique(doc.done, titles);
  touch(doc);
  persist();
  render();
  toast("已带入未完成待办");
}

async function openSite(url) {
  if (window.kangDesktop?.openSite) {
    const ok = await window.kangDesktop.openSite(url);
    if (!ok) toast("无法打开该地址");
    return;
  }
  window.open(url, "_blank", "noopener");
}
