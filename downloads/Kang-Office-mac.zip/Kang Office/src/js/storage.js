import { todayISO } from "./util.js";
import { emptyAccount, normalizeAccount } from "./auth.js";

const KEY = "kang-office-v1";

export function emptyState() {
  return {
    meetings: [],
    reports: [],
    quotes: [],
    todos: [],
    trialStartedAt: todayISO(),
    region: "cn",
    account: emptyAccount(),
  };
}

export function loadState() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return emptyState();
    const parsed = JSON.parse(raw);
    return {
      ...emptyState(),
      ...parsed,
      meetings: Array.isArray(parsed.meetings) ? parsed.meetings : [],
      reports: Array.isArray(parsed.reports) ? parsed.reports : [],
      quotes: Array.isArray(parsed.quotes) ? parsed.quotes : [],
      todos: Array.isArray(parsed.todos) ? parsed.todos : [],
      account: normalizeAccount(parsed.account),
    };
  } catch {
    return emptyState();
  }
}

export function saveState(state) {
  localStorage.setItem(
    KEY,
    JSON.stringify({
      meetings: state.meetings,
      reports: state.reports,
      quotes: state.quotes,
      todos: state.todos,
      trialStartedAt: state.trialStartedAt,
      region: state.region === "int" ? "int" : "cn",
      account: normalizeAccount(state.account),
    }),
  );
}
