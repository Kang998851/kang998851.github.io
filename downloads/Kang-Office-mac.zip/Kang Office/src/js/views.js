import { MEETING_TEMPLATES, MODULES, PRICES, QUOTE_TEMPLATES, REPORT_TEMPLATES, SITE_URL, TODO_STATUS, UPGRADE_URL } from "./config.js";
import {
  filterTodos,
  findTemplate,
  lineSubtotal,
  meetingPreview,
  meetingTitle,
  quotePreview,
  quoteTitle,
  quoteTotal,
  reportPreview,
  reportTitle,
  sourceLabel,
  statusLabel,
  todoTitle,
  todosPreview,
} from "./docs.js";
import { displayName, hasPassword } from "./auth.js";
import { escapeHtml as h, formatDate, formatRange, money } from "./util.js";

const FILTERS = [
  { id: "today", label: "今天" },
  { id: "week", label: "本周" },
  { id: "overdue", label: "已过期" },
  { id: "all", label: "全部" },
];

export function chromeView(ui, state) {
  if (ui.view === "login") {
    return `<span class="brand">Kang Office</span>`;
  }
  const mod = MODULES.find((item) => item.id === ui.module);
  const crumb = mod ? `<span class="crumb">${h(mod.name)}</span>` : "";
  const who = displayName(state?.account);
  return `
    <button class="brand" type="button" data-act="go" data-view="home">Kang Office</button>
    ${crumb}
    <div class="title-actions">
      <span class="pill">${h(who ? `${who} · 已试用` : "已试用")}</span>
      <button class="text-btn" type="button" data-act="go" data-view="about">需回官网升级</button>
      <button class="text-btn" type="button" data-act="logout">退出</button>
    </div>
  `;
}

export function footView() {
  return `<p>Kang Office 属于 <span class="brand-inline">KangStudio</span></p>`;
}

export function loginView(ui, state) {
  const locked = hasPassword(state.account);
  const mode = ui.loginMode || (locked ? "enter" : "create");
  const creating = mode === "create";
  return `
    <section class="gate-screen">
      <div class="gate-card">
        <p class="eyebrow">KangStudio</p>
        <h1>Kang Office</h1>
        <p class="lede">电脑端办公软件。账户只存在这台电脑，不上传、不联网登录。打开软件后在此进入，不是网站。</p>
        <div class="segment" role="tablist" aria-label="进入方式">
          <button type="button" class="${creating ? "" : "is-on"}" data-act="login-mode" data-mode="enter">进入</button>
          <button type="button" class="${creating ? "is-on" : ""}" data-act="login-mode" data-mode="create">创建本机账户</button>
        </div>
        <form class="gate-form" data-form="login">
          <label>显示名
            <input name="name" type="text" maxlength="40" autocomplete="username" value="${h(state.account?.name || "")}" placeholder="例如 王敏" ${!creating && locked ? "readonly" : ""}>
          </label>
          <label>${creating ? "设置密码" : "密码"}
            <input name="password" type="password" maxlength="64" autocomplete="${creating ? "new-password" : "current-password"}" placeholder="${creating ? "至少 4 位，只保存在本机" : "本机密码"}">
          </label>
          ${
            creating
              ? `<label>确认密码
                  <input name="confirm" type="password" maxlength="64" autocomplete="new-password">
                </label>`
              : ""
          }
          <label class="check">
            <input name="stay" type="checkbox" ${state.account?.stay !== false ? "checked" : ""}>
            在这台电脑保持进入
          </label>
          ${ui.loginError ? `<p class="gate-error">${h(ui.loginError)}</p>` : ""}
          <button class="solid" type="submit">${creating ? "创建并进入" : "进入 Kang Office"}</button>
        </form>
        <button class="ghost" type="button" data-act="trial">先试用，不设密码</button>
        ${locked ? `<button class="text-btn" type="button" data-act="clear-account">清除本机账户</button>` : ""}
        <p class="hint">软件内不收款。升级请回官网，未成年须由监护人代付。密码无法远程找回。</p>
      </div>
    </section>
  `;
}

export function homeView(state) {
  const counts = {
    meetings: state.meetings.length,
    reports: state.reports.length,
    quotes: state.quotes.length,
    todos: filterTodos(state.todos, "today").filter((item) => item.status !== "done").length,
  };
  const countLabel = {
    meetings: (n) => `${n} 份纪要`,
    reports: (n) => `${n} 份周报`,
    quotes: (n) => `${n} 份报价`,
    todos: (n) => (n ? `今天 ${n} 项未完成` : "今天没有未完成项"),
  };
  return `
    <section class="home">
      <p class="eyebrow">KangStudio</p>
      <h1>日常办公的模板与流程。</h1>
      <p class="lede">覆盖会议纪要、周报、报价单和待办事项。在电脑上选模板、填内容、跟进度、导出文件。数据保存在本机，无需账号。</p>
      <div class="modules">
        ${MODULES.map(
          (mod) => `
          <button class="mod" type="button" data-act="go" data-view="list" data-module="${mod.id}">
            <span class="mod-kicker">${mod.index}</span>
            <h2>${h(mod.name)}</h2>
            <p>${h(mod.blurb)}</p>
            <span class="mod-count">${h(countLabel[mod.id](counts[mod.id]))}</span>
          </button>
        `,
        ).join("")}
      </div>
    </section>
  `;
}

export function aboutView(state) {
  const prices = PRICES[state.region] || PRICES.cn;
  return `
    <section class="page about">
      <button class="ghost" type="button" data-act="go" data-view="home">返回首页</button>
      <p class="eyebrow">关于</p>
      <h1>已试用 · 需回官网升级</h1>
      <div class="about-grid">
        <article class="panel">
          <h2>试用状态</h2>
          <p>自 ${h(formatDate(state.trialStartedAt))} 起可完整使用四个模块。本软件不登录、不收款、不在软件内放置支付表单。</p>
          <p>升级请到 KangStudio 官网完成付款。未成年用户须由监护人代付，请勿瞒着家长付款。</p>
          <p class="mono site-url">${h(SITE_URL)}</p>
          <div class="row-actions">
            <button class="solid" type="button" data-act="open-site" data-url="${h(UPGRADE_URL)}">打开官网定价页</button>
          </div>
        </article>
        <article class="panel">
          <h2>定价</h2>
          <p class="hint">与官网同一档。此处只展示，不收款。</p>
          <div class="segment" role="group" aria-label="计价地区">
            <button type="button" class="${state.region === "cn" ? "is-on" : ""}" data-act="region" data-region="cn">国内</button>
            <button type="button" class="${state.region === "int" ? "is-on" : ""}" data-act="region" data-region="int">国际</button>
          </div>
          <ul class="price-list">
            ${prices.map((item) => `<li><span>${h(item.period)}</span><strong>${h(item.value)}</strong></li>`).join("")}
          </ul>
        </article>
      </div>
    </section>
  `;
}

export function listView(ui, state) {
  if (ui.module === "meetings") return meetingList(state);
  if (ui.module === "reports") return reportList(state);
  if (ui.module === "quotes") return quoteList(state);
  return todoList(ui, state);
}

function pageHead(title, actions) {
  return `
    <div class="page-head">
      <button class="ghost" type="button" data-act="go" data-view="home">首页</button>
      <h1>${h(title)}</h1>
      <div class="head-actions">${actions}</div>
    </div>
  `;
}

function emptyCard(text, actionLabel) {
  return `
    <div class="empty">
      <p>${h(text)}</p>
      <button class="solid" type="button" data-act="new">${h(actionLabel)}</button>
    </div>
  `;
}

function meetingList(state) {
  const rows = state.meetings;
  return `
    <section class="page">
      ${pageHead("会议纪要", `<button class="solid" type="button" data-act="new">新建纪要</button>`)}
      ${
        rows.length
          ? `<ul class="rows">${rows
              .map(
                (item) => `
            <li>
              <button class="row" type="button" data-act="open" data-id="${h(item.id)}">
                <span class="row-title">${h(meetingTitle(item))}</span>
                <span class="row-meta">${h(formatDate(item.date))} · ${h(findTemplate(MEETING_TEMPLATES, item.templateId).name)}</span>
              </button>
            </li>`,
              )
              .join("")}</ul>`
          : emptyCard("还没有纪要。选一个空白模板开始填写。", "选模板")
      }
    </section>
  `;
}

function reportList(state) {
  const rows = state.reports;
  return `
    <section class="page">
      ${pageHead("周报", `<button class="solid" type="button" data-act="new">新建周报</button>`)}
      ${
        rows.length
          ? `<ul class="rows">${rows
              .map(
                (item) => `
            <li>
              <button class="row" type="button" data-act="open" data-id="${h(item.id)}">
                <span class="row-title">${h(reportTitle(item))}</span>
                <span class="row-meta">${h(findTemplate(REPORT_TEMPLATES, item.templateId).name)}</span>
              </button>
            </li>`,
              )
              .join("")}</ul>`
          : emptyCard("还没有周报。先选定本周区间，再填写完成、问题和下周计划。", "选模板")
      }
    </section>
  `;
}

function quoteList(state) {
  const rows = state.quotes;
  return `
    <section class="page">
      ${pageHead("报价单", `<button class="solid" type="button" data-act="new">新建报价</button>`)}
      ${
        rows.length
          ? `<ul class="rows">${rows
              .map(
                (item) => `
            <li>
              <button class="row" type="button" data-act="open" data-id="${h(item.id)}">
                <span class="row-title">${h(quoteTitle(item))}</span>
                <span class="row-meta">${h(money(quoteTotal(item), item.currency))} · 有效至 ${h(item.validUntil || "未填")}</span>
              </button>
            </li>`,
              )
              .join("")}</ul>`
          : emptyCard("还没有报价单。填写客户、项目和明细后会自动合计。", "选模板")
      }
    </section>
  `;
}

function todoList(ui, state) {
  const filter = ui.filter || "today";
  const rows = filterTodos(state.todos, filter);
  const label = FILTERS.find((item) => item.id === filter)?.label || "今天";
  return `
    <section class="page">
      ${pageHead(
        "待办",
        `
        <button class="ghost" type="button" data-act="preview">预览</button>
        <button class="solid" type="button" data-act="new">新建待办</button>
      `,
      )}
      <div class="segment" role="tablist" aria-label="待办范围">
        ${FILTERS.map(
          (item) =>
            `<button type="button" class="${filter === item.id ? "is-on" : ""}" data-act="filter" data-filter="${item.id}">${h(item.label)}</button>`,
        ).join("")}
      </div>
      ${
        rows.length
          ? `<ul class="todo-rows">${rows
              .map(
                (item) => `
            <li class="todo-row">
              <button class="status-btn status-${h(item.status)}" type="button" data-act="cycle-status" data-id="${h(item.id)}">${h(statusLabel(item.status))}</button>
              <button class="todo-main" type="button" data-act="open" data-id="${h(item.id)}">
                <span class="row-title">${h(todoTitle(item))}</span>
                <span class="row-meta">截止 ${h(item.due || "未填")} · ${h(sourceLabel(item.source))}</span>
              </button>
            </li>`,
              )
              .join("")}</ul>`
          : `<div class="empty"><p>${h(label)}没有待办。可手动新建，或从纪要、周报转入。</p><button class="solid" type="button" data-act="new">新建待办</button></div>`
      }
    </section>
  `;
}

export function templatesView(ui) {
  const map = {
    meetings: MEETING_TEMPLATES,
    reports: REPORT_TEMPLATES,
    quotes: QUOTE_TEMPLATES,
  };
  const list = map[ui.module] || [];
  const title = MODULES.find((item) => item.id === ui.module)?.name || "";
  return `
    <section class="page">
      ${pageHead(`选择${title}模板`, `<button class="ghost" type="button" data-act="go" data-view="list" data-module="${h(ui.module)}">返回列表</button>`)}
      <p class="hint">模板是空白结构，不会替你填写业务内容。</p>
      <div class="modules template-grid">
        ${list
          .map(
            (item) => `
          <button class="mod" type="button" data-act="pick-template" data-template="${h(item.id)}">
            <span class="mod-kicker">模板</span>
            <h2>${h(item.name)}</h2>
            <p>${h(item.blurb)}</p>
          </button>`,
          )
          .join("")}
      </div>
    </section>
  `;
}

function lineFields(list, field, placeholder) {
  return (list || [""])
    .map(
      (value, i) => `
      <div class="line">
        <input data-field="${field}.${i}" value="${h(value)}" placeholder="${h(placeholder)}">
        <button class="icon-btn" type="button" data-act="remove-line" data-field="${field}" data-index="${i}" aria-label="删除此行">删</button>
      </div>`,
    )
    .join("");
}

function workspace(form, preview, actions, mode) {
  const previewOn = mode === "preview";
  return `
    <section class="workspace ${previewOn ? "is-preview" : ""}">
      <div class="form-pane">${form}</div>
      <aside class="preview-pane">
        <p class="pane-label">预览</p>
        <article class="doc" id="live-preview">${preview}</article>
      </aside>
    </section>
    <div class="dock">
      <button class="ghost" type="button" data-act="go" data-view="list">返回列表</button>
      <button class="ghost danger" type="button" data-act="delete">删除</button>
      <span class="dock-spacer"></span>
      ${actions}
      <button class="ghost" type="button" data-act="copy">复制</button>
      <button class="ghost" type="button" data-act="export" data-format="md">导出 Markdown</button>
      <button class="ghost" type="button" data-act="export" data-format="txt">导出文本</button>
      <button class="solid" type="button" data-act="toggle-mode">${previewOn ? "返回填写" : "预览"}</button>
    </div>
  `;
}

export function editView(ui, state) {
  if (ui.module === "meetings") return meetingEdit(ui, state);
  if (ui.module === "reports") return reportEdit(ui, state);
  if (ui.module === "quotes") return quoteEdit(ui, state);
  return todoEdit(ui, state);
}

function meetingEdit(ui, state) {
  const doc = state.meetings.find((item) => item.id === ui.id);
  if (!doc) return missing();
  const tpl = findTemplate(MEETING_TEMPLATES, doc.templateId);
  const form = `
    <div class="page-head compact">
      <p class="eyebrow">${h(tpl.name)}</p>
      <h1>填写纪要</h1>
    </div>
    <label>会议名
      <input data-field="title" value="${h(doc.title)}" placeholder="填写会议名称">
    </label>
    <div class="two">
      <label>日期
        <input type="date" data-field="date" value="${h(doc.date)}">
      </label>
      <label>出席
        <input data-field="attendees" value="${h(doc.attendees)}" placeholder="姓名，用顿号或逗号分隔">
      </label>
    </div>
    <fieldset>
      <legend>${h(tpl.labels.agenda)}</legend>
      ${lineFields(doc.agenda, "agenda", "一条议题")}
      <button class="text-btn" type="button" data-act="add-line" data-field="agenda">添加议题</button>
    </fieldset>
    <fieldset>
      <legend>${h(tpl.labels.conclusions)}</legend>
      ${lineFields(doc.conclusions, "conclusions", "一条结论")}
      <button class="text-btn" type="button" data-act="add-line" data-field="conclusions">添加结论</button>
    </fieldset>
    <fieldset>
      <legend>${h(tpl.labels.actions)}</legend>
      ${(doc.actions || [])
        .map(
          (item, i) => `
        <div class="action-card">
          <label class="check">
            <input type="checkbox" data-field="actions.${i}.selected" ${item.selected ? "checked" : ""}>
            <span>转入待办</span>
          </label>
          <input data-field="actions.${i}.title" value="${h(item.title)}" placeholder="事项">
          <div class="two">
            <input data-field="actions.${i}.owner" value="${h(item.owner)}" placeholder="归属人">
            <input type="date" data-field="actions.${i}.due" value="${h(item.due)}">
          </div>
          <div class="action-foot">
            ${item.transferred ? `<span class="tag">已转入待办</span>` : ""}
            <button class="icon-btn" type="button" data-act="remove-action" data-index="${i}">删</button>
          </div>
        </div>`,
        )
        .join("")}
      <button class="text-btn" type="button" data-act="add-action">添加待办归属</button>
    </fieldset>
  `;
  const actions = `<button class="ghost" type="button" data-act="transfer-meeting">将勾选项转入待办</button>`;
  return workspace(form, meetingPreview(doc), actions, ui.mode);
}

function reportEdit(ui, state) {
  const doc = state.reports.find((item) => item.id === ui.id);
  if (!doc) return missing();
  const tpl = findTemplate(REPORT_TEMPLATES, doc.templateId);
  const form = `
    <div class="page-head compact">
      <p class="eyebrow">${h(tpl.name)}</p>
      <h1>填写周报</h1>
    </div>
    <label>本周任意一天（自动取周一至周日）
      <input type="date" data-field="weekStart" data-rerender="week" value="${h(doc.weekStart)}">
    </label>
    <p class="hint">${h(formatRange(doc.weekStart, doc.weekEnd))}</p>
    <div class="row-actions wrap">
      <button class="ghost" type="button" data-act="import-last-report">从上周周报带入</button>
      <button class="ghost" type="button" data-act="import-open-todos">从未完成待办带入</button>
    </div>
    <fieldset>
      <legend>本周完成</legend>
      ${lineFields(doc.done, "done", "一项完成")}
      <button class="text-btn" type="button" data-act="add-line" data-field="done">添加完成项</button>
    </fieldset>
    <fieldset>
      <legend>问题</legend>
      ${lineFields(doc.issues, "issues", "一项问题")}
      <button class="text-btn" type="button" data-act="add-line" data-field="issues">添加问题</button>
    </fieldset>
    <fieldset>
      <legend>下周计划</legend>
      ${lineFields(doc.next, "next", "一项计划")}
      <button class="text-btn" type="button" data-act="add-line" data-field="next">添加计划</button>
    </fieldset>
  `;
  const actions = `<button class="ghost" type="button" data-act="transfer-report">将下周计划转入待办</button>`;
  return workspace(form, reportPreview(doc), actions, ui.mode);
}

function quoteEdit(ui, state) {
  const doc = state.quotes.find((item) => item.id === ui.id);
  if (!doc) return missing();
  const tpl = findTemplate(QUOTE_TEMPLATES, doc.templateId);
  const form = `
    <div class="page-head compact">
      <p class="eyebrow">${h(tpl.name)}</p>
      <h1>填写报价单</h1>
    </div>
    <div class="two">
      <label>客户
        <input data-field="client" value="${h(doc.client)}" placeholder="客户名称">
      </label>
      <label>项目
        <input data-field="project" value="${h(doc.project)}" placeholder="项目名称">
      </label>
    </div>
    <div class="two">
      <label>有效期
        <input type="date" data-field="validUntil" value="${h(doc.validUntil)}">
      </label>
      <label>币种
        <select data-field="currency" data-rerender="quote">
          <option value="CNY" ${doc.currency === "CNY" ? "selected" : ""}>人民币 ¥</option>
          <option value="USD" ${doc.currency === "USD" ? "selected" : ""}>美元 $</option>
        </select>
      </label>
    </div>
    <fieldset>
      <legend>明细</legend>
      <table class="edit-table">
        <thead>
          <tr><th>名称</th><th>数量</th><th>单价</th><th>小计</th><th></th></tr>
        </thead>
        <tbody>
          ${(doc.items || [])
            .map(
              (item, i) => `
            <tr>
              <td><input data-field="items.${i}.name" value="${h(item.name)}" placeholder="名称"></td>
              <td><input class="num" type="number" min="0" step="1" data-field="items.${i}.qty" value="${h(item.qty)}"></td>
              <td><input class="num" type="number" min="0" step="0.01" data-field="items.${i}.price" value="${h(item.price)}"></td>
              <td class="num subtotal" data-subtotal="${i}">${h(money(lineSubtotal(item), doc.currency))}</td>
              <td><button class="icon-btn" type="button" data-act="remove-item" data-index="${i}">删</button></td>
            </tr>`,
            )
            .join("")}
        </tbody>
      </table>
      <div class="total-line">
        <span>合计</span>
        <strong id="quote-total">${h(money(quoteTotal(doc), doc.currency))}</strong>
      </div>
      <button class="text-btn" type="button" data-act="add-item">添加一行</button>
    </fieldset>
    <label>备注
      <textarea data-field="notes" rows="4" placeholder="付款方式、交付说明等。不包含在线支付或电子签。">${h(doc.notes)}</textarea>
    </label>
    <p class="hint">报价单可导出 Markdown、纯文本或 CSV。不做在线支付，也不做电子签。</p>
  `;
  const actions = `<button class="ghost" type="button" data-act="export" data-format="csv">导出 CSV</button>`;
  return workspace(form, quotePreview(doc), actions, ui.mode);
}

function todoEdit(ui, state) {
  const doc = state.todos.find((item) => item.id === ui.id);
  if (!doc) return missing();
  const form = `
    <div class="page-head compact">
      <p class="eyebrow">来源 · ${h(sourceLabel(doc.source))}</p>
      <h1>填写待办</h1>
    </div>
    <label>标题
      <input data-field="title" value="${h(doc.title)}" placeholder="待办标题">
    </label>
    <div class="two">
      <label>截止日期
        <input type="date" data-field="due" value="${h(doc.due)}">
      </label>
      <label>状态
        <select data-field="status" data-rerender="todo">
          ${TODO_STATUS.map((item) => `<option value="${item.id}" ${doc.status === item.id ? "selected" : ""}>${h(item.label)}</option>`).join("")}
        </select>
      </label>
    </div>
    <p class="hint">待办用于跟进。不做甘特图，也不做复杂项目管理。</p>
  `;
  const actions = "";
  return workspace(form, todosPreview([doc], todoTitle(doc)), actions, ui.mode);
}

export function todosPreviewPage(ui, state) {
  const filter = ui.filter || "today";
  const label = FILTERS.find((item) => item.id === filter)?.label || "今天";
  const rows = filterTodos(state.todos, filter);
  return `
    <section class="page preview-only">
      ${pageHead(`待办预览 · ${label}`, `<button class="ghost" type="button" data-act="go" data-view="list" data-module="todos">返回列表</button>`)}
      <article class="doc wide">${todosPreview(rows, label)}</article>
      <div class="dock">
        <span class="dock-spacer"></span>
        <button class="ghost" type="button" data-act="copy">复制</button>
        <button class="ghost" type="button" data-act="export" data-format="md">导出 Markdown</button>
        <button class="ghost" type="button" data-act="export" data-format="txt">导出文本</button>
      </div>
    </section>
  `;
}

function missing() {
  return `
    <section class="page">
      <div class="empty">
        <p>找不到这份内容，可能已被删除。</p>
        <button class="solid" type="button" data-act="go" data-view="home">返回首页</button>
      </div>
    </section>
  `;
}

export { FILTERS };
