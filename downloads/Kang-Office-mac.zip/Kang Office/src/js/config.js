export const UPGRADE_URL = "https://kang998851.github.io/#pricing";
export const SITE_URL = "https://kang998851.github.io/";

export const PRICES = {
  cn: [
    { period: "月", value: "¥19.9" },
    { period: "季", value: "¥49.9" },
    { period: "年", value: "¥149.9" },
  ],
  int: [
    { period: "月", value: "$9.9" },
    { period: "季", value: "$29.9" },
    { period: "年", value: "$59.9" },
  ],
};

export const MEETING_TEMPLATES = [
  {
    id: "standard",
    name: "标准纪要",
    blurb: "会议名、日期、出席、议题、结论、待办归属。",
    labels: { agenda: "议题", conclusions: "结论", actions: "待办归属" },
  },
  {
    id: "project",
    name: "项目例会",
    blurb: "同一套空白结构，栏目偏向进展、阻塞与下一步。",
    labels: { agenda: "进展与议题", conclusions: "结论与阻塞", actions: "下一步归属" },
  },
  {
    id: "oneone",
    name: "一对一",
    blurb: "同一套空白结构，栏目偏向讨论、反馈与行动。",
    labels: { agenda: "讨论", conclusions: "反馈与结论", actions: "行动归属" },
  },
];

export const REPORT_TEMPLATES = [
  {
    id: "standard",
    name: "标准周报",
    blurb: "本周区间、完成、问题、下周计划。",
    lines: 3,
  },
  {
    id: "compact",
    name: "精简周报",
    blurb: "同一三项，行数更少，适合短更新。",
    lines: 1,
  },
];

export const QUOTE_TEMPLATES = [
  {
    id: "standard",
    name: "标准报价",
    blurb: "客户、项目、明细、备注、有效期。自动合计。",
    rows: 3,
    validDays: 14,
  },
  {
    id: "service",
    name: "服务报价",
    blurb: "同一套空白结构，明细按服务行填写。",
    rows: 2,
    validDays: 30,
  },
];

export const TODO_STATUS = [
  { id: "open", label: "未做" },
  { id: "doing", label: "进行中" },
  { id: "done", label: "完成" },
];

export const TODO_SOURCES = {
  manual: "手动",
  meeting: "纪要",
  report: "周报",
};

export const MODULES = [
  {
    id: "meetings",
    index: "01",
    name: "会议纪要",
    blurb: "固定结构，写完即可导出。勾选事项可转入待办。",
  },
  {
    id: "reports",
    index: "02",
    name: "周报",
    blurb: "选本周区间。可从上周或未完成待办带入条目。",
  },
  {
    id: "quotes",
    index: "03",
    name: "报价单",
    blurb: "填写明细后自动计算小计与合计。不做在线支付。",
  },
  {
    id: "todos",
    index: "04",
    name: "待办",
    blurb: "按今天、本周、已过期查看。用于跟进，不是项目管理。",
  },
];
