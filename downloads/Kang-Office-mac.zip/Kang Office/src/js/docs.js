import { MEETING_TEMPLATES, QUOTE_TEMPLATES, REPORT_TEMPLATES, TODO_SOURCES, TODO_STATUS } from "./config.js";
import {
  addDays,
  escapeHtml,
  filenamePart,
  filled,
  formatDate,
  formatRange,
  inWeek,
  isoDate,
  money,
  stamp,
  todayISO,
  uid,
  weekRangeFrom,
} from "./util.js";

function blanks(n) {
  return Array.from({ length: n }, () => "");
}

export function findTemplate(list, id) {
  return list.find((item) => item.id === id) || list[0];
}

export function createMeeting(templateId) {
  const tpl = findTemplate(MEETING_TEMPLATES, templateId);
  const now = stamp();
  return {
    id: uid("mt"),
    templateId: tpl.id,
    title: "",
    date: todayISO(),
    attendees: "",
    agenda: blanks(3),
    conclusions: blanks(2),
    actions: [emptyAction(), emptyAction()],
    createdAt: now,
    updatedAt: now,
  };
}

export function emptyAction() {
  return {
    id: uid("ac"),
    title: "",
    owner: "",
    due: "",
    selected: false,
    transferred: false,
  };
}

export function createReport(templateId, dateStr = todayISO()) {
  const tpl = findTemplate(REPORT_TEMPLATES, templateId);
  const week = weekRangeFrom(dateStr);
  const now = stamp();
  return {
    id: uid("rp"),
    templateId: tpl.id,
    weekStart: week.start,
    weekEnd: week.end,
    done: blanks(tpl.lines),
    issues: blanks(Math.max(1, tpl.lines - 1)),
    next: blanks(tpl.lines),
    createdAt: now,
    updatedAt: now,
  };
}

export function createQuote(templateId) {
  const tpl = findTemplate(QUOTE_TEMPLATES, templateId);
  const now = stamp();
  return {
    id: uid("qt"),
    templateId: tpl.id,
    client: "",
    project: "",
    notes: "",
    validUntil: isoDate(addDays(new Date(), tpl.validDays)),
    currency: "CNY",
    items: Array.from({ length: tpl.rows }, () => emptyItem()),
    createdAt: now,
    updatedAt: now,
  };
}

export function emptyItem() {
  return { name: "", qty: 1, price: 0 };
}

export function createTodo(partial = {}) {
  const now = stamp();
  return {
    id: uid("td"),
    title: "",
    due: todayISO(),
    source: "manual",
    sourceId: "",
    status: "open",
    createdAt: now,
    updatedAt: now,
    ...partial,
  };
}

export function lineSubtotal(item) {
  return (Number(item?.qty) || 0) * (Number(item?.price) || 0);
}

export function quoteTotal(quote) {
  return (quote.items || []).reduce((sum, item) => sum + lineSubtotal(item), 0);
}

export function statusLabel(id) {
  return TODO_STATUS.find((item) => item.id === id)?.label || "未做";
}

export function sourceLabel(id) {
  return TODO_SOURCES[id] || TODO_SOURCES.manual;
}

export function filterTodos(todos, filter, today = todayISO()) {
  const week = weekRangeFrom(today);
  return todos
    .filter((todo) => {
      if (filter === "today") return todo.due === today;
      if (filter === "week") return inWeek(todo.due, week.start, week.end);
      if (filter === "overdue") return Boolean(todo.due) && todo.due < today && todo.status !== "done";
      return true;
    })
    .sort((a, b) => String(a.due).localeCompare(String(b.due)) || String(a.title).localeCompare(String(b.title)));
}

export function nextStatus(status) {
  if (status === "open") return "doing";
  if (status === "doing") return "done";
  return "open";
}

export function lastReport(reports, current) {
  return reports
    .filter((item) => item.id !== current.id && item.weekStart < current.weekStart)
    .sort((a, b) => b.weekStart.localeCompare(a.weekStart))[0];
}

export function mergeUnique(list, incoming) {
  const have = new Set(filled(list).map((item) => item.trim()));
  const next = [...list];
  incoming.forEach((line) => {
    const text = String(line || "").trim();
    if (!text || have.has(text)) return;
    have.add(text);
    const emptyAt = next.findIndex((item) => !String(item || "").trim());
    if (emptyAt >= 0) next[emptyAt] = text;
    else next.push(text);
  });
  if (!next.length) next.push("");
  return next;
}

export function openTodos(todos) {
  return todos.filter((todo) => todo.status !== "done" && todo.title.trim());
}

export function selectedActions(meeting) {
  return (meeting.actions || []).filter((item) => item.selected && item.title.trim() && !item.transferred);
}

export function meetingTitle(meeting) {
  return meeting.title.trim() || "未命名会议";
}

export function reportTitle(report) {
  return `周报 ${report.weekStart} – ${report.weekEnd}`;
}

export function quoteTitle(quote) {
  const client = quote.client.trim() || "未填写客户";
  const project = quote.project.trim() || "未填写项目";
  return `${client} · ${project}`;
}

export function todoTitle(todo) {
  return todo.title.trim() || "未命名待办";
}

function bullet(list) {
  const items = filled(list);
  return items.length ? items.map((item) => `- ${item}`).join("\n") : "- （未填写）";
}

function numbered(list) {
  const items = filled(list);
  return items.length ? items.map((item, i) => `${i + 1}. ${item}`).join("\n") : "1. （未填写）";
}

export function meetingMarkdown(meeting) {
  const tpl = findTemplate(MEETING_TEMPLATES, meeting.templateId);
  const actions = (meeting.actions || []).filter((item) => item.title.trim());
  const actionLines = actions.length
    ? actions
        .map((item) => {
          const mark = item.transferred ? "[x]" : "[ ]";
          const owner = item.owner.trim() ? ` · ${item.owner.trim()}` : "";
          const due = item.due ? ` · ${item.due}` : "";
          return `- ${mark} ${item.title.trim()}${owner}${due}`;
        })
        .join("\n")
    : "- （未填写）";
  return [
    `# 会议纪要：${meetingTitle(meeting)}`,
    "",
    `- 日期：${meeting.date || "未填写"}`,
    `- 出席：${meeting.attendees.trim() || "未填写"}`,
    `- 模板：${tpl.name}`,
    "",
    `## ${tpl.labels.agenda}`,
    numbered(meeting.agenda),
    "",
    `## ${tpl.labels.conclusions}`,
    bullet(meeting.conclusions),
    "",
    `## ${tpl.labels.actions}`,
    actionLines,
    "",
    "— Kang Office",
  ].join("\n");
}

export function meetingPlain(meeting) {
  const tpl = findTemplate(MEETING_TEMPLATES, meeting.templateId);
  const actions = (meeting.actions || []).filter((item) => item.title.trim());
  return [
    `会议纪要：${meetingTitle(meeting)}`,
    `日期：${meeting.date || "未填写"}`,
    `出席：${meeting.attendees.trim() || "未填写"}`,
    `模板：${tpl.name}`,
    "",
    tpl.labels.agenda,
    numbered(meeting.agenda),
    "",
    tpl.labels.conclusions,
    bullet(meeting.conclusions),
    "",
    tpl.labels.actions,
    actions.length
      ? actions
          .map((item) => {
            const owner = item.owner.trim() ? `  归属 ${item.owner.trim()}` : "";
            const due = item.due ? `  截止 ${item.due}` : "";
            return `· ${item.title.trim()}${owner}${due}`;
          })
          .join("\n")
      : "· （未填写）",
    "",
    "Kang Office · KangStudio",
  ].join("\n");
}

export function reportMarkdown(report) {
  return [
    `# ${reportTitle(report)}`,
    "",
    "## 本周完成",
    bullet(report.done),
    "",
    "## 问题",
    bullet(report.issues),
    "",
    "## 下周计划",
    bullet(report.next),
    "",
    "— Kang Office",
  ].join("\n");
}

export function reportPlain(report) {
  return [
    reportTitle(report),
    "",
    "本周完成",
    bullet(report.done),
    "",
    "问题",
    bullet(report.issues),
    "",
    "下周计划",
    bullet(report.next),
    "",
    "Kang Office · KangStudio",
  ].join("\n");
}

export function quoteMarkdown(quote) {
  const items = (quote.items || []).filter((item) => item.name.trim());
  const rows = items.length
    ? items
        .map((item) => `| ${item.name.trim()} | ${item.qty || 0} | ${money(item.price, quote.currency)} | ${money(lineSubtotal(item), quote.currency)} |`)
        .join("\n")
    : `| （未填写） |  |  |  |`;
  return [
    `# 报价单`,
    "",
    `- 客户：${quote.client.trim() || "未填写"}`,
    `- 项目：${quote.project.trim() || "未填写"}`,
    `- 有效期：${quote.validUntil || "未填写"}`,
    "",
    "| 名称 | 数量 | 单价 | 小计 |",
    "| --- | --- | --- | --- |",
    rows,
    "",
    `**合计：${money(quoteTotal(quote), quote.currency)}**`,
    "",
    "## 备注",
    quote.notes.trim() || "（无）",
    "",
    "本文件仅为报价，不含在线支付与电子签。",
    "",
    "— Kang Office",
  ].join("\n");
}

export function quotePlain(quote) {
  const items = (quote.items || []).filter((item) => item.name.trim());
  const lines = items.length
    ? items.map((item) => `${item.name.trim()}  ×${item.qty || 0}  ${money(item.price, quote.currency)}  小计 ${money(lineSubtotal(item), quote.currency)}`)
    : "（未填写明细）";
  return [
    "报价单",
    `客户：${quote.client.trim() || "未填写"}`,
    `项目：${quote.project.trim() || "未填写"}`,
    `有效期：${quote.validUntil || "未填写"}`,
    "",
    Array.isArray(lines) ? lines.join("\n") : lines,
    "",
    `合计：${money(quoteTotal(quote), quote.currency)}`,
    "",
    "备注",
    quote.notes.trim() || "（无）",
    "",
    "本文件仅为报价，不含在线支付与电子签。",
    "Kang Office · KangStudio",
  ].join("\n");
}

export function quoteCsv(quote) {
  const esc = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
  const rows = [["名称", "数量", "单价", "小计"].map(esc).join(",")];
  (quote.items || [])
    .filter((item) => item.name.trim())
    .forEach((item) => {
      rows.push([item.name.trim(), item.qty || 0, Number(item.price) || 0, lineSubtotal(item)].map(esc).join(","));
    });
  rows.push(["合计", "", "", quoteTotal(quote)].map(esc).join(","));
  rows.push(["客户", quote.client, "", ""].map(esc).join(","));
  rows.push(["项目", quote.project, "", ""].map(esc).join(","));
  rows.push(["有效期", quote.validUntil, "", ""].map(esc).join(","));
  rows.push(["备注", quote.notes, "", ""].map(esc).join(","));
  rows.push(["币种", quote.currency, "", ""].map(esc).join(","));
  return `\uFEFF${rows.join("\n")}\n`;
}

export function todosMarkdown(todos, label) {
  const lines = todos.length
    ? todos.map((todo) => {
        const mark = todo.status === "done" ? "[x]" : "[ ]";
        const due = todo.due ? `  截止 ${todo.due}` : "";
        return `- ${mark} ${todoTitle(todo)}  ${statusLabel(todo.status)}  来源 ${sourceLabel(todo.source)}${due}`;
      })
    : "- （本组没有待办）";
  return [`# 待办 · ${label}`, "", lines, "", "— Kang Office"].join("\n");
}

export function todosPlain(todos, label) {
  const lines = todos.length
    ? todos.map((todo) => {
        const due = todo.due ? `  截止 ${todo.due}` : "";
        return `· ${todoTitle(todo)}  ${statusLabel(todo.status)}  来源 ${sourceLabel(todo.source)}${due}`;
      })
    : "· （本组没有待办）";
  return [`待办 · ${label}`, "", lines.join("\n"), "", "Kang Office · KangStudio"].join("\n");
}

export function exportName(kind, doc) {
  if (kind === "meeting") return `纪要-${filenamePart(doc.title, "未命名")}-${doc.date || todayISO()}`;
  if (kind === "report") return `周报-${doc.weekStart}-${doc.weekEnd}`;
  if (kind === "quote") return `报价-${filenamePart(doc.client, "客户")}-${filenamePart(doc.project, "项目")}`;
  return `待办-${filenamePart(doc, "列表")}-${todayISO()}`;
}

function docList(items, ordered) {
  const values = filled(items);
  if (!values.length) return `<p class="empty-line">未填写</p>`;
  const tag = ordered ? "ol" : "ul";
  return `<${tag}>${values.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</${tag}>`;
}

export function meetingPreview(meeting) {
  const tpl = findTemplate(MEETING_TEMPLATES, meeting.templateId);
  const actions = (meeting.actions || []).filter((item) => item.title.trim());
  const actionHtml = actions.length
    ? `<ul class="action-preview">${actions
        .map((item) => {
          const meta = [item.owner.trim() && `归属 ${item.owner.trim()}`, item.due && `截止 ${item.due}`, item.transferred && "已转入待办"]
            .filter(Boolean)
            .join(" · ");
          return `<li><span>${escapeHtml(item.title.trim())}</span>${meta ? `<small>${escapeHtml(meta)}</small>` : ""}</li>`;
        })
        .join("")}</ul>`
    : `<p class="empty-line">未填写</p>`;
  return `
    <p class="doc-kicker">Kang Office · ${escapeHtml(tpl.name)}</p>
    <h1>${escapeHtml(meetingTitle(meeting))}</h1>
    <dl class="meta">
      <div><dt>日期</dt><dd>${escapeHtml(formatDate(meeting.date))}</dd></div>
      <div><dt>出席</dt><dd>${escapeHtml(meeting.attendees.trim() || "未填写")}</dd></div>
    </dl>
    <h2>${escapeHtml(tpl.labels.agenda)}</h2>
    ${docList(meeting.agenda, true)}
    <h2>${escapeHtml(tpl.labels.conclusions)}</h2>
    ${docList(meeting.conclusions, false)}
    <h2>${escapeHtml(tpl.labels.actions)}</h2>
    ${actionHtml}
  `;
}

export function reportPreview(report) {
  return `
    <p class="doc-kicker">Kang Office · 周报</p>
    <h1>${escapeHtml(formatRange(report.weekStart, report.weekEnd))}</h1>
    <h2>本周完成</h2>
    ${docList(report.done, false)}
    <h2>问题</h2>
    ${docList(report.issues, false)}
    <h2>下周计划</h2>
    ${docList(report.next, false)}
  `;
}

export function quotePreview(quote) {
  const items = (quote.items || []).filter((item) => item.name.trim());
  const rows = items.length
    ? items
        .map(
          (item) => `<tr>
            <td>${escapeHtml(item.name.trim())}</td>
            <td class="num">${escapeHtml(String(item.qty || 0))}</td>
            <td class="num">${escapeHtml(money(item.price, quote.currency))}</td>
            <td class="num">${escapeHtml(money(lineSubtotal(item), quote.currency))}</td>
          </tr>`,
        )
        .join("")
    : `<tr><td colspan="4" class="empty-line">未填写明细</td></tr>`;
  return `
    <p class="doc-kicker">Kang Office · 报价单</p>
    <h1>${escapeHtml(quoteTitle(quote))}</h1>
    <dl class="meta">
      <div><dt>客户</dt><dd>${escapeHtml(quote.client.trim() || "未填写")}</dd></div>
      <div><dt>项目</dt><dd>${escapeHtml(quote.project.trim() || "未填写")}</dd></div>
      <div><dt>有效期</dt><dd>${escapeHtml(formatDate(quote.validUntil))}</dd></div>
    </dl>
    <table class="doc-table">
      <thead><tr><th>名称</th><th>数量</th><th>单价</th><th>小计</th></tr></thead>
      <tbody>${rows}</tbody>
      <tfoot><tr><td colspan="3">合计</td><td class="num">${escapeHtml(money(quoteTotal(quote), quote.currency))}</td></tr></tfoot>
    </table>
    <h2>备注</h2>
    <p>${escapeHtml(quote.notes.trim() || "无")}</p>
    <p class="doc-note">本页仅为报价，不含在线支付与电子签。</p>
  `;
}

export function todosPreview(todos, label) {
  const rows = todos.length
    ? `<ul class="action-preview">${todos
        .map((todo) => {
          const meta = [statusLabel(todo.status), `来源 ${sourceLabel(todo.source)}`, todo.due && `截止 ${todo.due}`]
            .filter(Boolean)
            .join(" · ");
          return `<li><span>${escapeHtml(todoTitle(todo))}</span><small>${escapeHtml(meta)}</small></li>`;
        })
        .join("")}</ul>`
    : `<p class="empty-line">本组没有待办</p>`;
  return `
    <p class="doc-kicker">Kang Office · 待办</p>
    <h1>${escapeHtml(label)}</h1>
    ${rows}
  `;
}

export function sortByUpdated(list) {
  return [...list].sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
}

export function parseNumberField(path, raw) {
  if (path.endsWith(".qty") || path.endsWith(".price")) return Number(raw) || 0;
  return raw;
}
