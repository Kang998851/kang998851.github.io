export function uid(prefix = "id") {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-3)}`;
}

export function pad(n) {
  return String(n).padStart(2, "0");
}

export function isoDate(d) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function todayISO() {
  return isoDate(new Date());
}

export function parseISO(value) {
  const [y, m, day] = String(value || "")
    .split("-")
    .map(Number);
  if (!y || !m || !day) return new Date();
  return new Date(y, m - 1, day);
}

export function addDays(date, n) {
  const next = new Date(date.getTime());
  next.setDate(next.getDate() + n);
  return next;
}

export function weekRangeFrom(dateStr) {
  const d = parseISO(dateStr);
  const day = d.getDay();
  const offset = day === 0 ? -6 : 1 - day;
  const start = addDays(d, offset);
  return { start: isoDate(start), end: isoDate(addDays(start, 6)) };
}

export function inWeek(dateStr, start, end) {
  return Boolean(dateStr) && dateStr >= start && dateStr <= end;
}

export function formatDate(value) {
  if (!value) return "未填写";
  const d = parseISO(value);
  return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
}

export function formatRange(start, end) {
  return `${formatDate(start)} – ${formatDate(end)}`;
}

export function money(n, currency = "CNY") {
  const v = Number(n) || 0;
  const formatted = v.toLocaleString(currency === "USD" ? "en-US" : "zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return currency === "USD" ? `$${formatted}` : `¥${formatted}`;
}

export function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function filled(list) {
  return (list || []).map((item) => String(item ?? "").trim()).filter(Boolean);
}

export function filenamePart(value, fallback) {
  const clean = String(value || "")
    .replace(/[\\/:*?"<>|]+/g, "")
    .replace(/\s+/g, "-")
    .slice(0, 40);
  return clean || fallback;
}

export function downloadText(filename, content, mime = "text/plain;charset=utf-8") {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 800);
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const area = document.createElement("textarea");
    area.value = text;
    document.body.appendChild(area);
    area.select();
    const ok = document.execCommand("copy");
    area.remove();
    return ok;
  }
}

export function setPath(obj, path, value) {
  const parts = String(path).split(".");
  let cur = obj;
  for (let i = 0; i < parts.length - 1; i += 1) {
    const key = parts[i];
    const nextKey = parts[i + 1];
    const index = Number(key);
    if (Number.isInteger(index) && String(index) === key) {
      if (!Array.isArray(cur)) return;
      if (!cur[index] || typeof cur[index] !== "object") cur[index] = /^\d+$/.test(nextKey) ? [] : {};
      cur = cur[index];
      continue;
    }
    if (cur[key] == null) cur[key] = /^\d+$/.test(nextKey) ? [] : {};
    cur = cur[key];
  }
  const last = parts[parts.length - 1];
  const lastIndex = Number(last);
  if (Number.isInteger(lastIndex) && String(lastIndex) === last && Array.isArray(cur)) {
    cur[lastIndex] = value;
    return;
  }
  cur[last] = value;
}

export function stamp() {
  return new Date().toISOString();
}
