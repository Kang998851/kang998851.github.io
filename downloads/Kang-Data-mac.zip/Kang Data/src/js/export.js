import { filenamePart } from "./util.js";
import { cloneTable, filterRows, toCsv, toMarkdown, toPlain, withCategoryNames } from "./table.js";

export function rowsForExport(session, { categoryId, includeCategoryColumn } = {}) {
  let table = cloneTable(session.current);
  if (categoryId === "none") table = filterRows(table, (row) => !row.categoryId);
  else if (categoryId && categoryId !== "all") table = filterRows(table, (row) => row.categoryId === categoryId);
  if (includeCategoryColumn && session.categories.length) table = withCategoryNames(table, session.categories);
  return table;
}

export function renderExport(table, format) {
  if (format === "md") return toMarkdown(table);
  if (format === "txt") return toPlain(table);
  return toCsv(table);
}

export function mimeFor(format) {
  if (format === "md") return "text/markdown;charset=utf-8";
  if (format === "txt") return "text/plain;charset=utf-8";
  return "text/csv;charset=utf-8";
}

export function extFor(format) {
  if (format === "md") return "md";
  if (format === "txt") return "txt";
  return "csv";
}

export function sourceSlug(session) {
  return filenamePart(session.sourceName, "kang-data");
}

export function filePlan(session, { format, split, filterCat, includeCategoryColumn }) {
  const ext = extFor(format);
  const base = sourceSlug(session);
  if (!split) {
    const table = rowsForExport(session, {
      categoryId: filterCat || "all",
      includeCategoryColumn,
    });
    return [
      {
        filename: `${base}.${ext}`,
        label: "当前结果",
        table,
        text: renderExport(table, format),
      },
    ];
  }
  const groups = [
    ...session.categories.map((cat) => ({ id: cat.id, name: cat.name })),
    { id: "none", name: "未分类" },
  ];
  const files = [];
  for (const group of groups) {
    const table = rowsForExport(session, { categoryId: group.id, includeCategoryColumn: false });
    if (!table.rows.length) continue;
    files.push({
      filename: `${base}-${filenamePart(group.name, "类别")}.${ext}`,
      label: group.name,
      table,
      text: renderExport(table, format),
    });
  }
  return files;
}
