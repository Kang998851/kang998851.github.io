import { SNAPSHOT_LIMIT } from "./config.js";
import { uid } from "./util.js";
import {
  cloneTable,
  columnCount,
  emptyColumnIndexes,
  findDuplicateHeaderGroups,
  headerLabel,
  isEmptyRow,
  makeRow,
  rowKey,
  stats,
} from "./table.js";

function noteDiff(before, after, title, notes, extra = {}) {
  const b = stats(before);
  const a = stats(after);
  return {
    title,
    notes,
    beforeRows: b.rows,
    afterRows: a.rows,
    beforeCols: b.cols,
    afterCols: a.cols,
    removed: Math.max(0, b.rows - a.rows),
    added: Math.max(0, a.rows - b.rows),
    ...extra,
  };
}

export function stripEmptyRows(table) {
  const next = cloneTable(table);
  const kept = [];
  let removed = 0;
  for (const row of next.rows) {
    if (isEmptyRow(row)) removed += 1;
    else kept.push(row);
  }
  next.rows = kept;
  return {
    table: next,
    diff: noteDiff(table, next, "去掉空行", removed ? [`将删除 ${removed} 行空记录。`] : ["没有空行。"], {
      changed: 0,
    }),
  };
}

export function stripDuplicateRows(table) {
  const next = cloneTable(table);
  const seen = new Set();
  const kept = [];
  let removed = 0;
  for (const row of next.rows) {
    const key = rowKey(row);
    if (seen.has(key)) {
      removed += 1;
      continue;
    }
    seen.add(key);
    kept.push(row);
  }
  next.rows = kept;
  return {
    table: next,
    diff: noteDiff(table, next, "去掉完全重复行", removed ? [`将删除 ${removed} 行完全相同的记录，保留首次出现。`] : ["没有完全重复的行。"]),
  };
}

export function normalizeWhitespace(table) {
  const next = cloneTable(table);
  let cells = 0;
  next.headers = next.headers.map((name) => {
    const cleaned = String(name).replace(/\u00a0/g, " ").trim().replace(/\s+/g, " ");
    if (cleaned !== String(name ?? "")) cells += 1;
    return cleaned;
  });
  for (const row of next.rows) {
    row.cells = row.cells.map((cell) => {
      const cleaned = String(cell ?? "")
        .replace(/\u00a0/g, " ")
        .trim()
        .replace(/\s+/g, " ");
      if (cleaned !== String(cell ?? "")) cells += 1;
      return cleaned;
    });
  }
  return {
    table: next,
    diff: noteDiff(
      table,
      next,
      "去掉首尾空格并统一空白",
      cells ? [`将改写 ${cells} 个单元格：去掉首尾空格，连续空白收成一个空格。`] : ["没有需要统一的空白。"],
      { changed: cells },
    ),
  };
}

export function splitColumn(table, colIndex, delimiter) {
  const delim = String(delimiter || "");
  if (!delim) {
    return { table: cloneTable(table), diff: noteDiff(table, table, "拆分一格多值", ["请指定分隔符。"]) };
  }
  const next = cloneTable(table);
  const rows = [];
  let extra = 0;
  for (const row of next.rows) {
    const raw = String(row.cells[colIndex] ?? "");
    const parts = raw
      .split(delim)
      .map((part) => part.trim())
      .filter((part, i, arr) => part !== "" || arr.length === 1);
    if (parts.length <= 1) {
      rows.push(row);
      continue;
    }
    parts.forEach((part, index) => {
      const cells = [...row.cells];
      cells[colIndex] = part;
      if (index === 0) {
        row.cells = cells;
        rows.push(row);
      } else {
        extra += 1;
        rows.push(makeRow(cells, row.categoryId));
      }
    });
  }
  next.rows = rows;
  const label = headerLabel(table, colIndex);
  return {
    table: next,
    diff: noteDiff(
      table,
      next,
      "拆分一格多值",
      extra
        ? [`按「${delim}」拆分「${label}」。将新增 ${extra} 行，其余列原样复制。`]
        : [`「${label}」中没有用「${delim}」隔开的多值。`],
    ),
  };
}

export function mergeDuplicateHeaders(table) {
  const groups = findDuplicateHeaderGroups(table);
  if (!groups.length) {
    return { table: cloneTable(table), diff: noteDiff(table, table, "合并重复列名", ["当前没有重复列名。"]) };
  }
  const drop = new Set();
  const next = cloneTable(table);
  const notes = [];
  for (const indexes of groups) {
    const keep = indexes[0];
    const rest = indexes.slice(1);
    notes.push(`「${headerLabel(table, keep)}」：第 ${indexes.map((i) => i + 1).join("、")} 列将合并为第 ${keep + 1} 列。同一行多个值用分号连接。`);
    for (const row of next.rows) {
      const values = indexes
        .map((i) => String(row.cells[i] ?? "").trim())
        .filter(Boolean);
      const unique = [...new Set(values)];
      row.cells[keep] = unique.join("; ");
    }
    rest.forEach((i) => drop.add(i));
  }
  next.headers = next.headers.filter((_, i) => !drop.has(i));
  next.rows = next.rows.map((row) => ({
    ...row,
    cells: row.cells.filter((_, i) => !drop.has(i)),
  }));
  return {
    table: next,
    diff: noteDiff(table, next, "合并重复列名", notes, { changed: groups.length }),
  };
}

export function fixMisaligned(table) {
  const next = cloneTable(table);
  let width = Math.max(next.headers.length, 1);
  let shifted = 0;
  let padded = 0;
  let joined = 0;
  for (const row of next.rows) {
    if (row.cells.length === width + 1 && String(row.cells[0]).trim() === "") {
      row.cells = row.cells.slice(1);
      shifted += 1;
    }
    if (row.cells.length < width) {
      padded += 1;
      while (row.cells.length < width) row.cells.push("");
    }
    if (row.cells.length > width) {
      joined += 1;
      const head = row.cells.slice(0, width - 1);
      const tail = row.cells.slice(width - 1).filter((cell) => String(cell).trim() !== "");
      row.cells = [...head, tail.join(", ")];
    }
  }
  while (next.headers.length < width) next.headers.push(`列${next.headers.length + 1}`);
  next.headers = next.headers.slice(0, width);

  const emptyCols = emptyColumnIndexes(next);
  if (emptyCols.length) {
    const drop = new Set(emptyCols);
    next.headers = next.headers.filter((_, i) => !drop.has(i));
    next.rows = next.rows.map((row) => ({
      ...row,
      cells: row.cells.filter((_, i) => !drop.has(i)),
    }));
  }

  const notes = [];
  if (shifted) notes.push(`将左移 ${shifted} 行：行首空单元格且多出一格，按错列处理。`);
  if (padded) notes.push(`将为 ${padded} 行补空，使列数与列名一致。`);
  if (joined) notes.push(`将把 ${joined} 行多出的单元格并入最后一列。`);
  if (emptyCols.length) notes.push(`将删除 ${emptyCols.length} 列完全空白的列。`);
  if (!notes.length) notes.push("未发现明显错列。单元格数量已与列名一致，也没有整列空白。");

  return {
    table: next,
    diff: noteDiff(table, next, "纠正明显错列", notes, { changed: shifted + padded + joined + emptyCols.length }),
  };
}

export function hasDiffChange(diff) {
  if (!diff) return false;
  return diff.removed > 0 || diff.added > 0 || (diff.changed || 0) > 0 || diff.beforeCols !== diff.afterCols;
}

export function pushSnapshot(session, label) {
  session.snapshots.push({ label, table: cloneTable(session.current) });
  if (session.snapshots.length > SNAPSHOT_LIMIT) session.snapshots.shift();
}

export function undoLast(session) {
  const last = session.snapshots.pop();
  if (!last) return false;
  session.current = last.table;
  session.lastDiff = {
    title: "撤销",
    notes: [`已回到「${last.label}」之前。`],
    beforeRows: 0,
    afterRows: session.current.rows.length,
    beforeCols: 0,
    afterCols: columnCount(session.current),
    removed: 0,
    added: 0,
  };
  return true;
}

export function resetToImport(session) {
  session.current = cloneTable(session.original);
  session.snapshots = [];
  session.categories = [];
  session.lastDiff = {
    title: "回到导入后的副本",
    notes: ["已丢弃清洗与分类改动。原文件未被改写。"],
    beforeRows: 0,
    afterRows: session.current.rows.length,
    beforeCols: 0,
    afterCols: columnCount(session.current),
    removed: 0,
    added: 0,
  };
}

export function applyPreview(session, preview, label) {
  pushSnapshot(session, label);
  session.current = preview.table;
  session.lastDiff = preview.diff;
}

export function addCategory(session, name) {
  const trimmed = String(name || "").trim();
  if (!trimmed) return null;
  const exists = session.categories.find((item) => item.name === trimmed);
  if (exists) return exists;
  const cat = { id: uid("c"), name: trimmed };
  session.categories.push(cat);
  return cat;
}

export function removeCategory(session, id) {
  session.categories = session.categories.filter((item) => item.id !== id);
  for (const row of session.current.rows) {
    if (row.categoryId === id) row.categoryId = null;
  }
}

export function assignRows(session, rowIds, categoryId) {
  const set = new Set(rowIds);
  const valid = categoryId && session.categories.some((item) => item.id === categoryId) ? categoryId : null;
  let count = 0;
  for (const row of session.current.rows) {
    if (!set.has(row.id)) continue;
    row.categoryId = valid;
    count += 1;
  }
  return count;
}

export function groupByColumn(session, colIndex) {
  pushSnapshot(session, "按列分组");
  const used = new Map(session.categories.map((item) => [item.name, item]));
  let assigned = 0;
  let created = 0;
  for (const row of session.current.rows) {
    const name = String(row.cells[colIndex] ?? "").trim();
    if (!name) {
      row.categoryId = null;
      continue;
    }
    let cat = used.get(name);
    if (!cat) {
      cat = { id: uid("c"), name };
      session.categories.push(cat);
      used.set(name, cat);
      created += 1;
    }
    row.categoryId = cat.id;
    assigned += 1;
  }
  session.lastDiff = {
    title: "按列分组",
    notes: [`按「${headerLabel(session.current, colIndex)}」的值归类。新建 ${created} 个类别，写入 ${assigned} 行。空值保持未分类。`],
    beforeRows: session.current.rows.length,
    afterRows: session.current.rows.length,
    beforeCols: columnCount(session.current),
    afterCols: columnCount(session.current),
    removed: 0,
    added: 0,
    changed: assigned,
  };
  return { created, assigned };
}
