import { uid } from "./util.js";

export function emptyTable() {
  return { headers: [], rows: [] };
}

export function cloneTable(table) {
  return {
    headers: [...(table?.headers || [])],
    rows: (table?.rows || []).map((row) => ({
      id: row.id,
      cells: [...row.cells],
      categoryId: row.categoryId || null,
    })),
  };
}

export function hasTable(table) {
  return Boolean(table && (table.headers.length || table.rows.length));
}

export function columnCount(table) {
  let max = table?.headers?.length || 0;
  for (const row of table?.rows || []) {
    if (row.cells.length > max) max = row.cells.length;
  }
  return max;
}

export function headerLabel(table, index) {
  const name = table.headers[index];
  if (name != null && String(name).trim()) return String(name);
  return `列${index + 1}`;
}

export function cellAt(row, index) {
  return String(row?.cells?.[index] ?? "");
}

export function makeRow(cells, categoryId = null) {
  return { id: uid("r"), cells: cells.map((cell) => String(cell ?? "")), categoryId };
}

export function tableFromMatrix(matrix, { firstRowIsHeader = true } = {}) {
  const lines = (matrix || []).map((row) => (Array.isArray(row) ? row.map((cell) => String(cell ?? "")) : []));
  if (!lines.length) return emptyTable();
  if (firstRowIsHeader) {
    const width = Math.max(...lines.map((row) => row.length), 1);
    const headers = Array.from({ length: width }, (_, i) => String(lines[0][i] ?? "").trim() || `列${i + 1}`);
    const rows = lines.slice(1).map((cells) => makeRow(cells));
    return { headers, rows };
  }
  return {
    headers: ["条目"],
    rows: lines.map((cells) => makeRow([cells.join(" ").trim()])),
  };
}

export function parseDelimited(text, delimiter) {
  const rows = [];
  let row = [];
  let cell = "";
  let i = 0;
  let inQuotes = false;
  const s = String(text || "").replace(/^\uFEFF/, "");
  while (i < s.length) {
    const ch = s[i];
    if (inQuotes) {
      if (ch === '"') {
        if (s[i + 1] === '"') {
          cell += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i += 1;
        continue;
      }
      cell += ch;
      i += 1;
      continue;
    }
    if (ch === '"') {
      inQuotes = true;
      i += 1;
      continue;
    }
    if (ch === delimiter) {
      row.push(cell);
      cell = "";
      i += 1;
      continue;
    }
    if (ch === "\r") {
      i += 1;
      continue;
    }
    if (ch === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
      i += 1;
      continue;
    }
    cell += ch;
    i += 1;
  }
  if (cell.length || row.length) {
    row.push(cell);
    rows.push(row);
  }
  while (rows.length && rows[rows.length - 1].every((item) => item === "")) rows.pop();
  return rows;
}

export function detectDelimiter(text) {
  const first = String(text || "")
    .replace(/^\uFEFF/, "")
    .split(/\r?\n/, 1)[0] || "";
  const tabs = (first.match(/\t/g) || []).length;
  const commas = (first.match(/,/g) || []).length;
  const semis = (first.match(/;/g) || []).length;
  if (tabs > 0 && tabs >= commas) return "\t";
  if (commas > 0 && commas >= semis) return ",";
  if (semis > 0) return ";";
  return null;
}

export function parseText(text, kind = "auto") {
  const raw = String(text || "").replace(/^\uFEFF/, "");
  if (!raw.trim()) return emptyTable();
  let delimiter = null;
  if (kind === "csv") delimiter = ",";
  else if (kind === "tsv") delimiter = "\t";
  else delimiter = detectDelimiter(raw);
  if (delimiter) return tableFromMatrix(parseDelimited(raw, delimiter));
  const lines = raw.split(/\r?\n/).map((line) => line.trimEnd());
  while (lines.length && lines[lines.length - 1] === "") lines.pop();
  return {
    headers: ["条目"],
    rows: lines.map((line) => makeRow([line])),
  };
}

export function tableFromFiles(files) {
  const rows = files.map((file) => {
    const name = file.name || "";
    const rel = file.relativePath || file.webkitRelativePath || name;
    const dot = name.lastIndexOf(".");
    const ext = dot > 0 ? name.slice(dot + 1) : "";
    return makeRow([name, rel, ext]);
  });
  return {
    headers: ["文件名", "路径", "扩展名"],
    rows,
  };
}

export function csvEscape(value) {
  const s = String(value ?? "");
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function toCsv(table) {
  const width = columnCount(table);
  const header = Array.from({ length: width }, (_, i) => csvEscape(headerLabel(table, i))).join(",");
  const lines = table.rows.map((row) =>
    Array.from({ length: width }, (_, i) => csvEscape(cellAt(row, i))).join(","),
  );
  return [header, ...lines].join("\n");
}

export function toTsvLines(table) {
  const width = columnCount(table);
  const header = Array.from({ length: width }, (_, i) => headerLabel(table, i)).join("\t");
  const lines = table.rows.map((row) => Array.from({ length: width }, (_, i) => cellAt(row, i)).join("\t"));
  return [header, ...lines];
}

export function toPlain(table) {
  const width = columnCount(table);
  if (width <= 1) return table.rows.map((row) => cellAt(row, 0)).join("\n");
  return toTsvLines(table).join("\n");
}

export function toMarkdown(table) {
  const width = columnCount(table);
  if (width <= 1) {
    return table.rows.map((row) => `- ${cellAt(row, 0) || "（空）"}`).join("\n");
  }
  const headers = Array.from({ length: width }, (_, i) => headerLabel(table, i));
  const sep = headers.map(() => "---");
  const body = table.rows.map((row) =>
    `| ${Array.from({ length: width }, (_, i) => escapeMd(cellAt(row, i))).join(" | ")} |`,
  );
  return [`| ${headers.map(escapeMd).join(" | ")} |`, `| ${sep.join(" | ")} |`, ...body].join("\n");
}

function escapeMd(value) {
  return String(value ?? "").replace(/\|/g, "\\|");
}

export function stats(table) {
  return {
    rows: table?.rows?.length || 0,
    cols: columnCount(table),
  };
}

export function isEmptyRow(row) {
  return (row?.cells || []).every((cell) => String(cell ?? "").trim() === "");
}

export function rowKey(row) {
  return (row?.cells || []).map((cell) => String(cell ?? "")).join("\u0000");
}

export function findDuplicateHeaderGroups(table) {
  const groups = new Map();
  table.headers.forEach((name, index) => {
    const key = String(name ?? "").trim();
    if (!key) return;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(index);
  });
  return [...groups.values()].filter((indexes) => indexes.length > 1);
}

export function emptyColumnIndexes(table) {
  const width = columnCount(table);
  const empty = [];
  for (let i = 0; i < width; i += 1) {
    const headerEmpty = String(table.headers[i] ?? "").trim() === "";
    const rowsEmpty = table.rows.every((row) => String(row.cells[i] ?? "").trim() === "");
    if (headerEmpty && rowsEmpty) empty.push(i);
  }
  return empty;
}

export function raggedRowCount(table) {
  const width = table.headers.length;
  if (!width) return table.rows.filter((row) => row.cells.length !== columnCount(table)).length;
  return table.rows.filter((row) => row.cells.length !== width).length;
}

export function filterRows(table, predicate) {
  return {
    headers: [...table.headers],
    rows: table.rows.filter(predicate),
  };
}

export function withCategoryNames(table, categories) {
  const map = new Map(categories.map((item) => [item.id, item.name]));
  return {
    headers: [...table.headers, "类别"],
    rows: table.rows.map((row) => ({
      ...row,
      cells: [...row.cells, row.categoryId ? map.get(row.categoryId) || "未分类" : "未分类"],
    })),
  };
}
