import { todayISO, uid } from "./util.js";
import { emptyTable } from "./table.js";
import { emptyAccount, normalizeAccount } from "./auth.js";

const KEY = "kang-data-v1";

export function emptySession() {
  return {
    id: "",
    sourceName: "",
    sourceKind: "",
    material: "",
    importedAt: "",
    original: emptyTable(),
    current: emptyTable(),
    snapshots: [],
    categories: [],
    lastDiff: null,
  };
}

export function emptyState() {
  return {
    trialStartedAt: todayISO(),
    region: "cn",
    account: emptyAccount(),
    session: emptySession(),
  };
}

export function loadState() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return emptyState();
    const parsed = JSON.parse(raw);
    const session = {
      ...emptySession(),
      ...(parsed.session || {}),
    };
    session.original = normalizeTable(session.original);
    session.current = normalizeTable(session.current);
    session.snapshots = Array.isArray(session.snapshots)
      ? session.snapshots
          .filter((item) => item && item.table)
          .map((item) => ({ label: String(item.label || "步骤"), table: normalizeTable(item.table) }))
      : [];
    session.categories = Array.isArray(session.categories)
      ? session.categories
          .filter((item) => item && item.id)
          .map((item) => ({ id: String(item.id), name: String(item.name || "未命名") }))
      : [];
    return {
      ...emptyState(),
      trialStartedAt: parsed.trialStartedAt || todayISO(),
      region: parsed.region === "int" ? "int" : "cn",
      account: normalizeAccount(parsed.account),
      session,
    };
  } catch {
    return emptyState();
  }
}

export function saveState(state) {
  try {
    localStorage.setItem(
      KEY,
      JSON.stringify({
        trialStartedAt: state.trialStartedAt,
        region: state.region === "int" ? "int" : "cn",
        account: normalizeAccount(state.account),
        session: state.session,
      }),
    );
  } catch {
    return false;
  }
  return true;
}

function normalizeTable(table) {
  if (!table || typeof table !== "object") return emptyTable();
  return {
    headers: Array.isArray(table.headers) ? table.headers.map((item) => String(item ?? "")) : [],
    rows: Array.isArray(table.rows)
      ? table.rows.map((row) => ({
          id: String(row?.id || uid("r")),
          cells: Array.isArray(row?.cells) ? row.cells.map((cell) => String(cell ?? "")) : [],
          categoryId: row?.categoryId ? String(row.categoryId) : null,
        }))
      : [],
  };
}
