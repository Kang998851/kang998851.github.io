import { STEPS, UPGRADE_URL } from "./config.js";
import {
  addCategory,
  applyPreview,
  fixMisaligned,
  groupByColumn,
  mergeDuplicateHeaders,
  normalizeWhitespace,
  removeCategory,
  resetToImport,
  splitColumn,
  stripDuplicateRows,
  stripEmptyRows,
  undoLast,
  assignRows,
  hasDiffChange,
} from "./clean.js";
import { extFor, filePlan, mimeFor } from "./export.js";
import { sampleTable } from "./samples.js";
import { emptySession, loadState, saveState } from "./storage.js";
import { cloneTable, hasTable, parseText, tableFromFiles } from "./table.js";
import { copyText, downloadText, extName, sleep, stamp, uid } from "./util.js";
import { createAccount, emptyAccount, hasPassword, shouldUnlock, startGuest, unlockAccount } from "./auth.js";
import { aboutView, chromeView, footView, homeView, loginView, workView } from "./views.js";

const ui = {
  view: "login",
  loginMode: "create",
  loginError: "",
  step: "import",
  page: 0,
  selected: [],
  filterCat: "all",
  splitCol: 0,
  splitDelim: ",",
  groupCol: 0,
  exportFormat: "csv",
  exportSplit: false,
  material: "",
  hint: "",
  pending: null,
};

const state = loadState();
if (!state.trialStartedAt) state.trialStartedAt = new Date().toISOString().slice(0, 10);
if (!state.session) state.session = emptySession();
if (!state.account) state.account = emptyAccount();

let sessionOpen = shouldUnlock(state.account);
ui.view = sessionOpen ? "home" : "login";
ui.loginMode = hasPassword(state.account) ? "enter" : "create";

const chromeEl = document.getElementById("chrome");
const viewEl = document.getElementById("view");
const footEl = document.getElementById("foot");
const toastEl = document.getElementById("toast");

document.body.classList.toggle("electron", Boolean(window.kangDesktop));

chromeEl.addEventListener("click", onClick);
viewEl.addEventListener("click", onClick);
viewEl.addEventListener("submit", onSubmit);
viewEl.addEventListener("change", onChange);
viewEl.addEventListener("dragover", onDragOver);
viewEl.addEventListener("dragleave", onDragLeave);
viewEl.addEventListener("drop", onDrop);
viewEl.addEventListener("dragstart", onDragStart);
document.addEventListener("keydown", onKey);

render();

function persist() {
  if (!saveState(state)) toast("资料较大，未能写入本机缓存。导出前请先另存。");
}

function render({ keepScroll = false } = {}) {
  const wrap = document.getElementById("grid-wrap");
  const scroll = keepScroll ? wrap?.scrollTop || 0 : 0;
  chromeEl.innerHTML = chromeView(ui, state);
  footEl.innerHTML = footView();
  document.body.classList.toggle("gate", ui.view === "login");
  viewEl.className = ui.view === "work" ? "work-mode" : ui.view === "login" ? "gate-mode" : "";
  if (ui.view === "login") viewEl.innerHTML = loginView(ui, state);
  else if (ui.view === "home") viewEl.innerHTML = homeView(state.session);
  else if (ui.view === "about") viewEl.innerHTML = aboutView(state);
  else viewEl.innerHTML = workView(ui, state.session);
  if (!keepScroll) viewEl.scrollTop = 0;
  const nextWrap = document.getElementById("grid-wrap");
  if (nextWrap && keepScroll) nextWrap.scrollTop = scroll;
}

function toast(message) {
  toastEl.textContent = message;
  toastEl.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => {
    toastEl.hidden = true;
  }, 1800);
}

function go(next) {
  if (!sessionOpen) {
    ui.view = "login";
    render();
    return;
  }
  ui.view = next.view || ui.view;
  if (next.step) ui.step = next.step;
  if (next.hint != null) ui.hint = next.hint;
  if (ui.view !== "work") {
    ui.pending = null;
    ui.hint = next.hint || "";
  }
  if (ui.view === "work" && !STEPS.some((item) => item.id === ui.step)) ui.step = "import";
  render();
}

function onClick(event) {
  const btn = event.target.closest("[data-act]");
  if (!btn) return;
  const act = btn.dataset.act;

  if (act === "login-mode") {
    ui.loginMode = btn.dataset.mode;
    ui.loginError = "";
    render();
    return;
  }
  if (act === "trial") {
    const form = document.querySelector("[data-form=login]");
    if (hasPassword(state.account)) {
      sessionOpen = true;
      ui.loginError = "";
      ui.view = "home";
      render();
      return;
    }
    enterApp(startGuest(form?.name?.value || "", form?.stay?.checked));
    return;
  }
  if (act === "logout") {
    sessionOpen = false;
    state.account = { ...state.account, stay: false };
    ui.view = "login";
    ui.loginMode = hasPassword(state.account) ? "enter" : "create";
    ui.loginError = "";
    persist();
    render();
    return;
  }
  if (act === "clear-account") {
    if (!window.confirm("清除本机账户后需重新创建。工作资料不会删除。确定？")) return;
    state.account = emptyAccount();
    sessionOpen = false;
    ui.view = "login";
    ui.loginMode = "create";
    ui.loginError = "";
    persist();
    render();
    return;
  }
  if (act === "go") {
    go({ view: btn.dataset.view, hint: "" });
    return;
  }
  if (act === "enter") {
    enterStep(btn.dataset.step);
    return;
  }
  if (act === "step") {
    enterStep(btn.dataset.step, { fromWork: true });
    return;
  }
  if (act === "region") {
    state.region = btn.dataset.region;
    persist();
    render();
    return;
  }
  if (act === "open-site") {
    openSite(btn.dataset.url || UPGRADE_URL);
    return;
  }
  if (act === "material") {
    ui.material = btn.dataset.material;
    if (hasTable(state.session.current)) {
      state.session.material = ui.material;
      persist();
    }
    render({ keepScroll: true });
    return;
  }
  if (act === "sample") {
    loadSample(btn.dataset.id);
    return;
  }
  if (act === "import-paste") {
    const box = document.getElementById("paste-box");
    importText(box?.value || "", { name: "粘贴.txt", kind: "paste" });
    return;
  }
  if (act === "preview-op") {
    previewOp(btn.dataset.op);
    return;
  }
  if (act === "apply-pending") {
    applyPending();
    return;
  }
  if (act === "cancel-pending") {
    ui.pending = null;
    render({ keepScroll: true });
    return;
  }
  if (act === "undo") {
    if (!undoLast(state.session)) {
      toast("没有可撤销的步骤");
      return;
    }
    ui.pending = null;
    persist();
    render();
    toast("已撤销");
    return;
  }
  if (act === "reset-import") {
    if (!hasTable(state.session.original)) return;
    resetToImport(state.session);
    ui.selected = [];
    ui.filterCat = "all";
    ui.pending = null;
    persist();
    render();
    toast("已回到导入后的副本");
    return;
  }
  if (act === "add-cat") {
    const input = document.getElementById("new-cat");
    const cat = addCategory(state.session, input?.value);
    if (!cat) {
      toast("请填写类别名称");
      return;
    }
    persist();
    render({ keepScroll: true });
    toast(`已添加「${cat.name}」`);
    return;
  }
  if (act === "delete-cat") {
    const cat = state.session.categories.find((item) => item.id === btn.dataset.id);
    if (!cat) return;
    if (!window.confirm(`删除类别「${cat.name}」后，其中的行变为未分类。确定删除？`)) return;
    removeCategory(state.session, cat.id);
    if (ui.filterCat === cat.id) ui.filterCat = "all";
    persist();
    render({ keepScroll: true });
    return;
  }
  if (act === "assign-cat") {
    if (!ui.selected.length) {
      toast("请先勾选要归入的行");
      return;
    }
    const n = assignRows(state.session, ui.selected, btn.dataset.id);
    ui.selected = [];
    persist();
    render({ keepScroll: true });
    toast(`已归入 ${n} 行`);
    return;
  }
  if (act === "filter-cat") {
    ui.filterCat = btn.dataset.id;
    ui.page = 0;
    render();
    return;
  }
  if (act === "group-by") {
    const col = Number(ui.groupCol) || 0;
    if (!window.confirm("将按所选列的值建立类别并写入每一行。空值保持未分类。确定？")) return;
    const result = groupByColumn(state.session, col);
    persist();
    render();
    toast(`已分组：新建 ${result.created} 类`);
    return;
  }
  if (act === "toggle-row") {
    toggleSelected(btn.dataset.id);
    persist();
    render({ keepScroll: true });
    return;
  }
  if (act === "toggle-page") {
    togglePage(btn.checked);
    render({ keepScroll: true });
    return;
  }
  if (act === "page") {
    ui.page = Math.max(0, ui.page + Number(btn.dataset.dir));
    render();
    return;
  }
  if (act === "export-format") {
    ui.exportFormat = btn.dataset.id;
    render();
    return;
  }
  if (act === "do-export") {
    doExport();
    return;
  }
  if (act === "copy-export") {
    copyExport();
    return;
  }
}

async function onSubmit(event) {
  const form = event.target.closest("[data-form=login]");
  if (!form) return;
  event.preventDefault();
  const name = form.name?.value || "";
  const password = form.password?.value || "";
  const confirm = form.confirm?.value || "";
  const stay = Boolean(form.stay?.checked);
  const creating = ui.loginMode === "create";
  if (!creating && !hasPassword(state.account)) {
    ui.loginError = "这台电脑还没有账户。请先创建，或先试用。";
    render();
    return;
  }
  if (creating) {
    if (password !== confirm) {
      ui.loginError = "两次密码不一致。";
      render();
      return;
    }
    const result = await createAccount(name, password, stay);
    if (!result.ok) {
      ui.loginError = result.error;
      render();
      return;
    }
    enterApp(result.account);
    return;
  }
  const result = await unlockAccount(state.account, password, stay);
  if (!result.ok) {
    ui.loginError = result.error;
    render();
    return;
  }
  enterApp(result.account);
}

function enterApp(account) {
  state.account = account;
  sessionOpen = true;
  ui.loginError = "";
  ui.view = "home";
  persist();
  render();
}

function onChange(event) {
  const el = event.target;
  if (el.id === "file-input" && el.files?.length) {
    importFiles([...el.files], { folder: false });
    el.value = "";
    return;
  }
  if (el.id === "folder-input" && el.files?.length) {
    importFiles([...el.files], { folder: true });
    el.value = "";
    return;
  }
  if (el.dataset.ui === "splitCol") {
    ui.splitCol = Number(el.value) || 0;
    return;
  }
  if (el.dataset.ui === "splitDelim") {
    ui.splitDelim = el.value;
    return;
  }
  if (el.dataset.ui === "groupCol") {
    ui.groupCol = Number(el.value) || 0;
    return;
  }
  if (el.dataset.ui === "exportSplit") {
    ui.exportSplit = el.checked;
    render();
  }
}

function onKey(event) {
  if (event.key === "Escape" && ui.view !== "home" && ui.view !== "login") {
    if (ui.pending) {
      ui.pending = null;
      render({ keepScroll: true });
      return;
    }
    if (ui.view === "work") go({ view: "home" });
    else go({ view: "home" });
  }
  if (event.key === "Enter" && event.target.id === "new-cat") {
    event.preventDefault();
    document.querySelector("[data-act=add-cat]")?.click();
  }
}

function onDragOver(event) {
  if (!event.target.closest("[data-drop], [data-drop-cat]")) return;
  event.preventDefault();
  event.dataTransfer.dropEffect = event.target.closest("[data-drop-cat]") ? "move" : "copy";
  event.target.closest(".dropzone, .cat-drop")?.classList.add("is-over");
}

function onDragLeave(event) {
  event.target.closest(".dropzone, .cat-drop")?.classList.remove("is-over");
}

function onDragStart(event) {
  const row = event.target.closest("tr[data-row]");
  if (!row) return;
  event.dataTransfer.setData("text/plain", row.dataset.row);
  event.dataTransfer.effectAllowed = "move";
}

async function onDrop(event) {
  const catBtn = event.target.closest("[data-drop-cat]");
  const zone = event.target.closest("[data-drop]");
  if (catBtn) {
    event.preventDefault();
    catBtn.classList.remove("is-over");
    const id = event.dataTransfer.getData("text/plain");
    const ids = ui.selected.includes(id) ? ui.selected : id ? [id] : [];
    if (!ids.length) return;
    const n = assignRows(state.session, ids, catBtn.dataset.dropCat || null);
    ui.selected = [];
    persist();
    render({ keepScroll: true });
    toast(`已归入 ${n} 行`);
    return;
  }
  if (!zone) return;
  event.preventDefault();
  zone.classList.remove("is-over");
  const files = [...(event.dataTransfer.files || [])];
  if (!files.length) return;
  await importFiles(files, { folder: files.length > 1 && files.every((file) => file.webkitRelativePath) });
}

function enterStep(step, { fromWork = false } = {}) {
  const loaded = hasTable(state.session.current);
  if (!loaded && step !== "import") {
    go({
      view: "work",
      step: "import",
      hint: "请先导入一份资料，再进入清洗、分类或导出。",
    });
    return;
  }
  ui.pending = null;
  ui.page = 0;
  if (step === "import" && loaded && !fromWork) {
    go({ view: "work", step: "clean", hint: "" });
    return;
  }
  go({ view: "work", step, hint: "" });
}

function previewOp(op) {
  const table = state.session.current;
  let preview;
  if (op === "empty") preview = stripEmptyRows(table);
  else if (op === "dups") preview = stripDuplicateRows(table);
  else if (op === "space") preview = normalizeWhitespace(table);
  else if (op === "split") preview = splitColumn(table, Number(ui.splitCol) || 0, ui.splitDelim);
  else if (op === "merge") preview = mergeDuplicateHeaders(table);
  else if (op === "align") preview = fixMisaligned(table);
  else return;
  ui.pending = { ...preview, op };
  render({ keepScroll: true });
  if (!hasDiffChange(preview.diff)) toast("没有可应用的改动");
}

function applyPending() {
  if (!ui.pending) return;
  if (!hasDiffChange(ui.pending.diff)) {
    ui.pending = null;
    render({ keepScroll: true });
    return;
  }
  applyPreview(state.session, ui.pending, ui.pending.diff.title);
  ui.pending = null;
  persist();
  render();
  toast("已写入工作副本");
}

function toggleSelected(id) {
  const set = new Set(ui.selected);
  if (set.has(id)) set.delete(id);
  else set.add(id);
  ui.selected = [...set];
}

function togglePage(checked) {
  const boxes = [...viewEl.querySelectorAll("[data-act=toggle-row]")];
  const set = new Set(ui.selected);
  boxes.forEach((box) => {
    if (checked) set.add(box.dataset.id);
    else set.delete(box.dataset.id);
  });
  ui.selected = [...set];
}

function loadSample(id) {
  const packed = sampleTable(id);
  if (!packed) return;
  if (!installTable(packed.table, {
    name: packed.sample.filename,
    kind: "sample",
    material: packed.sample.material,
  })) return;
  ui.material = packed.sample.material;
  go({ view: "work", step: "clean", hint: "这是样本库中的示例，不是真实业务数据。" });
}

async function importFiles(files, { folder }) {
  if (!files.length) return;
  if (folder || files.length > 1) {
    const named = files.map((file) => ({
      name: file.name,
      relativePath: file.webkitRelativePath || file.name,
    }));
    if (!installTable(tableFromFiles(named), {
      name: folder ? "文件夹文件名.csv" : "多文件列表.csv",
      kind: "folder",
      material: ui.material || "archive",
    })) return;
    go({ view: "work", step: "clean", hint: "已导入文件名列表，未读取文件内容。" });
    return;
  }
  const file = files[0];
  const ext = extName(file.name);
  if (["csv", "tsv", "txt", "md"].includes(ext) || (file.type || "").startsWith("text/")) {
    const text = await readFile(file);
    const kind = ext === "tsv" ? "tsv" : ext === "csv" ? "csv" : "auto";
    importText(text, { name: file.name, kind: kind === "auto" ? "txt" : kind });
    return;
  }
  if (!installTable(tableFromFiles([{ name: file.name, relativePath: file.name }]), {
    name: file.name,
    kind: "file",
    material: ui.material || "archive",
  })) return;
  go({ view: "work", step: "clean", hint: "该格式按文件名列入表。复杂表格请先另存为 CSV。" });
}

function importText(text, meta) {
  if (!String(text || "").trim()) {
    toast("没有可导入的内容");
    return;
  }
  const kind = meta.kind === "csv" || meta.kind === "tsv" ? meta.kind : "auto";
  if (!installTable(parseText(text, kind), {
    name: meta.name,
    kind: meta.kind,
    material: ui.material,
  })) return;
  go({ view: "work", step: "clean", hint: "" });
}

function installTable(table, meta) {
  if (hasTable(state.session.current) && !window.confirm("导入会替换当前工作副本。原文件不会被改写。确定？")) return false;
  const copy = cloneTable(table);
  state.session = {
    ...emptySession(),
    id: uid("s"),
    sourceName: meta.name,
    sourceKind: meta.kind,
    material: meta.material || ui.material || "",
    importedAt: stamp(),
    original: cloneTable(copy),
    current: copy,
  };
  ui.selected = [];
  ui.filterCat = "all";
  ui.page = 0;
  ui.pending = null;
  ui.splitCol = 0;
  ui.groupCol = 0;
  persist();
  return true;
}

function readFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(reader.error);
    reader.readAsText(file, "UTF-8");
  });
}

async function doExport() {
  if (!hasTable(state.session.current)) {
    toast("没有可导出的资料");
    return;
  }
  const files = filePlan(state.session, {
    format: ui.exportFormat,
    split: ui.exportSplit,
    filterCat: "all",
    includeCategoryColumn: !ui.exportSplit && state.session.categories.length > 0,
  });
  if (!files.length) {
    toast("没有可导出的行");
    return;
  }
  const format = ui.exportFormat;
  for (let i = 0; i < files.length; i += 1) {
    downloadText(files[i].filename, files[i].text, mimeFor(format));
    if (i < files.length - 1) await sleep(280);
  }
  toast(files.length > 1 ? `已导出 ${files.length} 个文件` : `已导出 ${extFor(format).toUpperCase()}`);
}

async function copyExport() {
  const files = filePlan(state.session, {
    format: ui.exportFormat,
    split: ui.exportSplit,
    filterCat: "all",
    includeCategoryColumn: !ui.exportSplit && state.session.categories.length > 0,
  });
  const text = files.map((file) => (files.length > 1 ? `## ${file.filename}\n${file.text}` : file.text)).join("\n\n");
  const ok = await copyText(text || "");
  toast(ok ? "已复制预览" : "复制失败");
}

async function openSite(url) {
  if (window.kangDesktop?.openSite) {
    const ok = await window.kangDesktop.openSite(url);
    if (!ok) toast("无法打开该地址");
    return;
  }
  window.open(url, "_blank", "noopener");
}
