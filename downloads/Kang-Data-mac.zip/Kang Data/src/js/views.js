import { DELIMS, EXPORT_FORMATS, HOME_ENTRIES, MATERIALS, PAGE_SIZE, PRICES, SITE_URL, STEPS, UPGRADE_URL } from "./config.js";
import { filePlan } from "./export.js";
import { SAMPLES } from "./samples.js";
import { displayName, hasPassword } from "./auth.js";
import { cellAt, columnCount, emptyColumnIndexes, findDuplicateHeaderGroups, hasTable, headerLabel, raggedRowCount } from "./table.js";
import { escapeHtml as h, formatDate } from "./util.js";

function alignNeed(table) {
  return raggedRowCount(table) + emptyColumnIndexes(table).length;
}

export function chromeView(ui, state) {
  if (ui.view === "login") {
    return `<span class="brand">Kang Data</span>`;
  }
  const step = STEPS.find((item) => item.id === ui.step);
  const crumb = ui.view === "work" && step ? `<span class="crumb">${h(step.name)}</span>` : "";
  const who = displayName(state?.account);
  return `
    <button class="brand" type="button" data-act="go" data-view="home">Kang Data</button>
    ${crumb}
    <div class="title-actions">
      <span class="pill">${h(who ? `${who} · 已试用` : "已试用")}</span>
      <button class="text-btn" type="button" data-act="go" data-view="about">需回官网升级</button>
      <button class="text-btn" type="button" data-act="logout">退出</button>
    </div>
  `;
}

export function footView() {
  return `<p>Kang Data 属于 <span class="brand-inline">KangStudio</span></p>`;
}

export function loginView(ui, state) {
  const locked = hasPassword(state.account);
  const mode = ui.loginMode || (locked ? "enter" : "create");
  const creating = mode === "create";
  return `
    <section class="gate-screen">
      <div class="gate-card">
        <p class="eyebrow">KangStudio</p>
        <h1>Kang Data</h1>
        <p class="lede">电脑端资料清洗。账户只存在这台电脑，不上传、不联网登录。打开软件后在此进入，不是网站。</p>
        <div class="segment" role="tablist" aria-label="进入方式">
          <button type="button" class="${creating ? "" : "is-on"}" data-act="login-mode" data-mode="enter">进入</button>
          <button type="button" class="${creating ? "is-on" : ""}" data-act="login-mode" data-mode="create">创建本机账户</button>
        </div>
        <form class="gate-form" data-form="login">
          <label>显示名
            <input name="name" type="text" maxlength="40" autocomplete="username" value="${h(state.account?.name || "")}" placeholder="例如 王敏" ${!creating && locked ? "readonly" : ""}>
          </label>
          <label>${creating ? "设置密码" : "密码"}
            <input name="password" type="password" maxlength="64" autocomplete="${creating ? "new-password" : "current-password"}" placeholder="${creating ? "至少 4 位，只保存在本机" : "本机密码"}">
          </label>
          ${
            creating
              ? `<label>确认密码
                  <input name="confirm" type="password" maxlength="64" autocomplete="new-password">
                </label>`
              : ""
          }
          <label class="check">
            <input name="stay" type="checkbox" ${state.account?.stay !== false ? "checked" : ""}>
            在这台电脑保持进入
          </label>
          ${ui.loginError ? `<p class="gate-error">${h(ui.loginError)}</p>` : ""}
          <button class="solid" type="submit">${creating ? "创建并进入" : "进入 Kang Data"}</button>
        </form>
        <button class="ghost" type="button" data-act="trial">先试用，不设密码</button>
        ${locked ? `<button class="text-btn" type="button" data-act="clear-account">清除本机账户</button>` : ""}
        <p class="hint">软件内不收款。升级请回官网，未成年须由监护人代付。密码无法远程找回。</p>
      </div>
    </section>
  `;
}

export function homeView(session) {
  const loaded = hasTable(session.current);
  const n = session.current.rows.length;
  return `
    <section class="home">
      <p class="eyebrow">KangStudio · 资料清洗</p>
      <h1>把表格和零散资料清洗、分类后导出。</h1>
      <p class="lede">适合整理名单、账单与归档文件，减少手工复制粘贴的时间。资料由你导入；原文件只读，结果另存到本机。不是在线数据库，也不代替 Excel。</p>
      <div class="modules three">
        ${HOME_ENTRIES.map(
          (entry) => `
          <button class="mod" type="button" data-act="enter" data-step="${entry.step}">
            <span class="mod-kicker">${entry.index}</span>
            <h2>${h(entry.name)}</h2>
            <p>${h(entry.blurb)}</p>
            <span class="mod-count">${loaded ? `当前 ${n} 行` : "尚未导入"}</span>
          </button>
        `,
        ).join("")}
      </div>
      <p class="wizard-line">
        或按向导进行
        <button class="text-btn" type="button" data-act="enter" data-step="import">导入 → 清洗 → 分类 → 导出</button>
      </p>
    </section>
  `;
}

export function aboutView(state) {
  const prices = PRICES[state.region] || PRICES.cn;
  return `
    <section class="page about">
      <button class="ghost" type="button" data-act="go" data-view="home">返回首页</button>
      <p class="eyebrow">关于</p>
      <h1>已试用 · 需回官网升级</h1>
      <div class="about-grid">
        <article class="panel">
          <h2>试用状态</h2>
          <p>自 ${h(formatDate(state.trialStartedAt))} 起可完整走完导入、清洗、分类、导出。本软件不登录、不收款、不在软件内放置支付表单。</p>
          <p>升级请到 KangStudio 官网完成付款。未成年用户须由监护人代付，请勿瞒着家长付款。</p>
          <p class="mono site-url">${h(SITE_URL)}</p>
          <div class="row-actions">
            <button class="solid" type="button" data-act="open-site" data-url="${h(UPGRADE_URL)}">打开官网定价页</button>
          </div>
        </article>
        <article class="panel">
          <h2>定价</h2>
          <p class="hint">与官网同一档。此处只展示，不收款。</p>
          <div class="segment" role="group" aria-label="计价地区">
            <button type="button" class="${state.region === "cn" ? "is-on" : ""}" data-act="region" data-region="cn">国内</button>
            <button type="button" class="${state.region === "int" ? "is-on" : ""}" data-act="region" data-region="int">国际</button>
          </div>
          <ul class="price-list">
            ${prices.map((item) => `<li><span>${h(item.period)}</span><strong>${h(item.value)}</strong></li>`).join("")}
          </ul>
        </article>
      </div>
    </section>
  `;
}

export function workView(ui, session) {
  const loaded = hasTable(session.current);
  return `
    <section class="workspace-root">
      <nav class="steps" aria-label="整理步骤">
        ${STEPS.map((step, index) => {
          const on = ui.step === step.id ? "is-on" : "";
          const done = STEPS.findIndex((item) => item.id === ui.step) > index ? "is-done" : "";
          return `<button type="button" class="step ${on} ${done}" data-act="step" data-step="${step.id}"><span>${step.index}</span>${h(step.name)}</button>`;
        }).join("")}
      </nav>
      ${ui.hint ? `<p class="work-hint">${h(ui.hint)}</p>` : ""}
      <div class="work">
        <div class="grid-panel">${mainPanel(ui, session, loaded)}</div>
        <aside class="side-pane">${sidePanel(ui, session, loaded)}</aside>
      </div>
      ${dock(ui, session, loaded)}
    </section>
  `;
}

function mainPanel(ui, session, loaded) {
  if (ui.step === "import" && !loaded) return importMain(ui);
  if (ui.step === "export" && loaded) return exportMain(ui, session);
  if (!loaded) {
    return `
      <div class="empty tall">
        <p>这一步需要先有一份资料。请先导入表格、文本，或从示例开始。</p>
        <button class="solid" type="button" data-act="step" data-step="import">去导入</button>
      </div>
    `;
  }
  return tablePanel(ui, session);
}

function importMain(ui) {
  return `
    <div class="dropzone" id="dropzone" data-drop="1">
      <p class="pane-label">导入</p>
      <h2>把资料放到这里</h2>
      <p>支持 CSV、TSV、纯文本（一行一条）。也可导入文件夹中的文件名列表。单次处理一份资料，不改写原文件。</p>
      <div class="row-actions wrap">
        <label class="solid file-btn">选择文件
          <input id="file-input" type="file" accept=".csv,.tsv,.txt,.md,text/csv,text/plain,text/tab-separated-values">
        </label>
        <label class="ghost file-btn">导入文件夹文件名
          <input id="folder-input" type="file" webkitdirectory directory multiple>
        </label>
      </div>
    </div>
    <label class="paste-box">
      或粘贴表格 / 一行一条的名单
      <textarea id="paste-box" rows="8" placeholder="姓名,部门&#10;张三,销售"></textarea>
    </label>
    <button class="ghost" type="button" data-act="import-paste">导入这段文字</button>
  `;
}

function tablePanel(ui, session) {
  const table = session.current;
  const width = columnCount(table);
  const filter = ui.filterCat || "all";
  let rows = table.rows;
  if (ui.step === "classify" && filter !== "all") {
    rows = filter === "none" ? rows.filter((row) => !row.categoryId) : rows.filter((row) => row.categoryId === filter);
  }
  const total = rows.length;
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const page = Math.min(ui.page, pages - 1);
  const slice = rows.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE);
  const selected = new Set(ui.selected);
  const catMap = new Map(session.categories.map((item) => [item.id, item.name]));
  const start = total ? page * PAGE_SIZE + 1 : 0;
  const end = Math.min(total, page * PAGE_SIZE + slice.length);
  const showCheck = ui.step === "classify";
  const pageIds = slice.map((row) => row.id);
  const allPageOn = pageIds.length > 0 && pageIds.every((id) => selected.has(id));

  return `
    <div class="grid-meta">
      <div>
        <p class="pane-label">${h(session.sourceName || "未命名资料")}</p>
        <p class="hint">${table.rows.length} 行 · ${width} 列${session.material ? ` · ${h(materialName(session.material))}` : ""} · 原文件只读</p>
      </div>
      <div class="pager">
        <span class="mono">${start}–${end} / ${total}</span>
        <button class="icon-btn" type="button" data-act="page" data-dir="-1" ${page <= 0 ? "disabled" : ""}>上一页</button>
        <button class="icon-btn" type="button" data-act="page" data-dir="1" ${page >= pages - 1 ? "disabled" : ""}>下一页</button>
      </div>
    </div>
    ${session.lastDiff && ui.step === "clean" ? diffBanner(session.lastDiff) : ""}
    <div class="grid-wrap" id="grid-wrap">
      <table class="grid">
        <thead>
          <tr>
            ${showCheck ? `<th class="check-col"><input type="checkbox" data-act="toggle-page" ${allPageOn ? "checked" : ""} aria-label="勾选本页"></th>` : ""}
            <th class="num-col">#</th>
            ${Array.from({ length: width }, (_, i) => `<th>${h(headerLabel(table, i))}</th>`).join("")}
            ${ui.step === "classify" ? "<th>类别</th>" : ""}
          </tr>
        </thead>
        <tbody>
          ${
            slice.length
              ? slice
                  .map((row, i) => {
                    const n = page * PAGE_SIZE + i + 1;
                    const on = selected.has(row.id);
                    const cat = row.categoryId ? catMap.get(row.categoryId) : "";
                    return `
                    <tr class="${on ? "is-selected" : ""}" draggable="${showCheck ? "true" : "false"}" data-row="${h(row.id)}">
                      ${showCheck ? `<td class="check-col"><input type="checkbox" data-act="toggle-row" data-id="${h(row.id)}" ${on ? "checked" : ""}></td>` : ""}
                      <td class="num-col">${n}</td>
                      ${Array.from({ length: width }, (_, c) => `<td>${h(cellAt(row, c))}</td>`).join("")}
                      ${ui.step === "classify" ? `<td class="cat-cell">${h(cat || "未分类")}</td>` : ""}
                    </tr>`;
                  })
                  .join("")
              : `<tr><td colspan="${width + (showCheck ? 2 : 1) + (ui.step === "classify" ? 1 : 0)}" class="empty-line">没有可显示的行</td></tr>`
          }
        </tbody>
      </table>
    </div>
  `;
}

function exportMain(ui, session) {
  const files = filePlan(session, {
    format: ui.exportFormat,
    split: ui.exportSplit,
    filterCat: "all",
    includeCategoryColumn: !ui.exportSplit && session.categories.length > 0,
  });
  const first = files[0];
  return `
    <div class="grid-meta">
      <div>
        <p class="pane-label">导出预览</p>
        <p class="hint">${files.length} 个文件 · 下载到本机 · 不上传</p>
      </div>
    </div>
    <ul class="file-plan">
      ${files
        .map(
          (file) =>
            `<li><span>${h(file.filename)}</span><span class="mono">${file.table.rows.length} 行</span></li>`,
        )
        .join("")}
    </ul>
    <pre class="export-pre" id="export-pre">${h(first ? first.text : "没有可导出的行")}</pre>
  `;
}

function sidePanel(ui, session, loaded) {
  if (ui.step === "import") return importPane(ui, session, loaded);
  if (ui.step === "clean") return cleanPane(ui, session, loaded);
  if (ui.step === "classify") return classifyPane(ui, session, loaded);
  return exportPane(ui, session, loaded);
}

function importPane(ui, session, loaded) {
  return `
    <p class="pane-label">来源</p>
    <h2>用户自备资料</h2>
    <p class="hint">软件不提供样本库以外的业务数据，不内置他人名单或账单。</p>
    ${
      loaded
        ? `<p class="hint">当前已有「${h(session.sourceName)}」。再次导入会替换工作副本，不会改写原文件。</p>
           <div class="dropzone compact" id="dropzone" data-drop="1">
             <p>拖入文件以替换</p>
             <div class="row-actions wrap">
               <label class="ghost file-btn">选择文件<input id="file-input" type="file" accept=".csv,.tsv,.txt,.md,text/csv,text/plain,text/tab-separated-values"></label>
               <label class="ghost file-btn">文件夹文件名<input id="folder-input" type="file" webkitdirectory directory multiple></label>
             </div>
           </div>
           <label class="paste-box">粘贴替换<textarea id="paste-box" rows="5"></textarea></label>
           <button class="ghost" type="button" data-act="import-paste">导入这段文字</button>`
        : ""
    }
    <p class="pane-label spaced">这份资料是（可选）</p>
    <div class="chips">
      ${MATERIALS.map(
        (item) =>
          `<button type="button" class="chip ${ui.material === item.id ? "is-on" : ""}" data-act="material" data-material="${item.id}">${h(item.name)}</button>`,
      ).join("")}
    </div>
    <p class="pane-label spaced">样本库</p>
    <div class="sample-list">
      ${SAMPLES.map(
        (item) => `
        <button class="sample" type="button" data-act="sample" data-id="${item.id}">
          <strong>${h(item.name)}</strong>
          <span>${h(item.blurb)}</span>
        </button>
      `,
      ).join("")}
    </div>
  `;
}

function cleanPane(ui, session, loaded) {
  if (!loaded) return `<p class="hint">导入资料后再清洗。清洗只处理已导入内容，不会替你编造数据。</p>`;
  if (ui.pending) return pendingPane(ui.pending);
  const dups = findDuplicateHeaderGroups(session.current);
  const align = alignNeed(session.current);
  return `
    <p class="pane-label">清洗</p>
    <h2>去掉脏数据</h2>
    <p class="hint">先预览差异，确认后再写入工作副本。不自动覆盖原文件。</p>
    <div class="op-list">
      <button type="button" data-act="preview-op" data-op="empty">去掉空行</button>
      <button type="button" data-act="preview-op" data-op="dups">去掉完全重复行</button>
      <button type="button" data-act="preview-op" data-op="space">去掉首尾空格、统一空白</button>
    </div>
    <p class="pane-label spaced">拆分一格多值</p>
    <div class="two tight">
      <label>列
        <select data-ui="splitCol">${columnOptions(session.current, ui.splitCol)}</select>
      </label>
      <label>分隔符
        <select data-ui="splitDelim">${DELIMS.map((item) => `<option value="${h(item.id)}" ${ui.splitDelim === item.id ? "selected" : ""}>${h(item.name)}</option>`).join("")}</select>
      </label>
    </div>
    <button class="ghost" type="button" data-act="preview-op" data-op="split">预览拆分</button>
    <p class="pane-label spaced">需确认的改动</p>
    <button type="button" data-act="preview-op" data-op="merge">合并重复列名${dups.length ? ` · ${dups.length} 组` : ""}</button>
    <button type="button" data-act="preview-op" data-op="align">纠正明显错列${align ? ` · ${align} 处` : ""}</button>
    <p class="hint">合并与纠列只会在你确认后改写当前副本。</p>
  `;
}

function pendingPane(pending) {
  const diff = pending.diff;
  const changed = diff.removed || diff.added || diff.changed || diff.beforeCols !== diff.afterCols;
  return `
    <p class="pane-label">清洗预览</p>
    <h2>${h(diff.title)}</h2>
    <p class="stat-line mono">${diff.beforeRows} → ${diff.afterRows} 行 · ${diff.beforeCols} → ${diff.afterCols} 列</p>
    <ul class="notes">
      ${diff.notes.map((note) => `<li>${h(note)}</li>`).join("")}
    </ul>
    ${
      changed
        ? `<div class="row-actions wrap">
            <button class="solid" type="button" data-act="apply-pending">应用清洗</button>
            <button class="ghost" type="button" data-act="cancel-pending">取消</button>
          </div>`
        : `<button class="ghost" type="button" data-act="cancel-pending">返回</button>`
    }
  `;
}

function classifyPane(ui, session, loaded) {
  if (!loaded) return `<p class="hint">导入并清洗后再分类。类别由你指定。</p>`;
  const filter = ui.filterCat || "all";
  const counts = categoryCounts(session);
  return `
    <p class="pane-label">分类</p>
    <h2>把行归到类别</h2>
    <p class="hint">适合名单、账单、归档文件名列表。不擅自猜测业务含义。</p>
    <p class="pane-label spaced">按某一列的值分组</p>
    <label>列
      <select data-ui="groupCol">${columnOptions(session.current, ui.groupCol)}</select>
    </label>
    <button class="ghost" type="button" data-act="group-by">按此列分组</button>
    <p class="pane-label spaced">自建类别</p>
    <div class="add-cat">
      <input id="new-cat" type="text" maxlength="40" placeholder="例如 华东客户">
      <button class="solid" type="button" data-act="add-cat">添加</button>
    </div>
    <ul class="cat-list">
      <li>
        <button class="cat-drop ${filter === "all" ? "is-on" : ""}" type="button" data-act="filter-cat" data-id="all">全部 <span>${session.current.rows.length}</span></button>
      </li>
      <li>
        <button class="cat-drop ${filter === "none" ? "is-on" : ""}" type="button" data-act="filter-cat" data-id="none" data-drop-cat="">未分类 <span>${counts.none}</span></button>
      </li>
      ${session.categories
        .map(
          (cat) => `
        <li class="cat-row">
          <button class="cat-drop ${filter === cat.id ? "is-on" : ""}" type="button" data-act="filter-cat" data-id="${h(cat.id)}" data-drop-cat="${h(cat.id)}">${h(cat.name)} <span>${counts[cat.id] || 0}</span></button>
          <button class="icon-btn" type="button" data-act="assign-cat" data-id="${h(cat.id)}">归入</button>
          <button class="icon-btn danger" type="button" data-act="delete-cat" data-id="${h(cat.id)}">删除</button>
        </li>
      `,
        )
        .join("")}
    </ul>
    <p class="hint">勾选行后点「归入」，或把行拖到类别上。已勾选 ${ui.selected.length} 行。</p>
  `;
}

function exportPane(ui, session, loaded) {
  if (!loaded) return `<p class="hint">有结果后再导出到本机。</p>`;
  return `
    <p class="pane-label">导出</p>
    <h2>另存干净文件</h2>
    <p class="hint">导出前可在左侧预览。不做云上传，不直接发邮件。</p>
    <div class="segment" role="group" aria-label="格式">
      ${EXPORT_FORMATS.map(
        (item) =>
          `<button type="button" class="${ui.exportFormat === item.id ? "is-on" : ""}" data-act="export-format" data-id="${item.id}">${h(item.name)}</button>`,
      ).join("")}
    </div>
    <label class="check">
      <input type="checkbox" data-ui="exportSplit" ${ui.exportSplit ? "checked" : ""}>
      按类别分文件（一类一个文件）
    </label>
    <div class="row-actions wrap">
      <button class="solid" type="button" data-act="do-export">导出到本机</button>
      <button class="ghost" type="button" data-act="copy-export">复制预览</button>
    </div>
  `;
}

function dock(ui, session, loaded) {
  const index = STEPS.findIndex((item) => item.id === ui.step);
  const prev = STEPS[index - 1];
  const next = STEPS[index + 1];
  return `
    <div class="dock">
      ${prev ? `<button class="ghost" type="button" data-act="step" data-step="${prev.id}">上一步 · ${h(prev.name)}</button>` : `<button class="ghost" type="button" data-act="go" data-view="home">首页</button>`}
      ${loaded ? `<button class="text-btn" type="button" data-act="reset-import">回到导入后的副本</button>` : ""}
      ${session.snapshots.length ? `<button class="text-btn" type="button" data-act="undo">撤销上一步</button>` : ""}
      <span class="dock-spacer"></span>
      ${next ? `<button class="solid" type="button" data-act="step" data-step="${next.id}">下一步 · ${h(next.name)}</button>` : loaded ? `<button class="solid" type="button" data-act="do-export">导出到本机</button>` : ""}
    </div>
  `;
}

function diffBanner(diff) {
  return `<p class="diff-banner">上次：${h(diff.title)} · ${diff.beforeRows}→${diff.afterRows} 行</p>`;
}

function columnOptions(table, selected) {
  const width = columnCount(table);
  return Array.from(
    { length: width },
    (_, i) => `<option value="${i}" ${Number(selected) === i ? "selected" : ""}>${h(headerLabel(table, i))}</option>`,
  ).join("");
}

function categoryCounts(session) {
  const counts = { none: 0 };
  for (const cat of session.categories) counts[cat.id] = 0;
  for (const row of session.current.rows) {
    if (!row.categoryId || counts[row.categoryId] == null) counts.none += 1;
    else counts[row.categoryId] += 1;
  }
  return counts;
}

function materialName(id) {
  return MATERIALS.find((item) => item.id === id)?.name || "";
}
