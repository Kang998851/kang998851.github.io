export const UPGRADE_URL = "https://kang998851.github.io/#pricing";
export const SITE_URL = "https://kang998851.github.io/";

export const PRICES = {
  cn: [
    { period: "月", value: "¥19.9" },
    { period: "季", value: "¥49.9" },
    { period: "年", value: "¥149.9" },
  ],
  int: [
    { period: "月", value: "$9.9" },
    { period: "季", value: "$29.9" },
    { period: "年", value: "$59.9" },
  ],
};

export const PAGE_SIZE = 80;
export const SNAPSHOT_LIMIT = 20;

export const STEPS = [
  { id: "import", index: "01", name: "导入" },
  { id: "clean", index: "02", name: "清洗" },
  { id: "classify", index: "03", name: "分类" },
  { id: "export", index: "04", name: "导出" },
];

export const HOME_ENTRIES = [
  {
    id: "clean",
    step: "import",
    index: "01",
    name: "导入并清洗",
    blurb: "导入表格或文本，去掉空行、重复行和多余空白。原文件只读，结果另存。",
  },
  {
    id: "classify",
    step: "classify",
    index: "02",
    name: "分类",
    blurb: "按某一列分组，或自建类别后勾选、拖入。规则由你指定，软件不擅自猜测。",
  },
  {
    id: "export",
    step: "export",
    index: "03",
    name: "导出",
    blurb: "导出 CSV、纯文本或 Markdown。也可按类别各生成一个文件。不上传、不发邮件。",
  },
];

export const MATERIALS = [
  { id: "list", name: "名单" },
  { id: "bill", name: "账单" },
  { id: "archive", name: "归档文件" },
];

export const DELIMS = [
  { id: ",", name: "逗号" },
  { id: ";", name: "分号" },
  { id: "、", name: "顿号" },
  { id: "|", name: "竖线" },
];

export const EXPORT_FORMATS = [
  { id: "csv", name: "CSV" },
  { id: "txt", name: "纯文本" },
  { id: "md", name: "Markdown" },
];
