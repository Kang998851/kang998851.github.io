const http = require("http");
const fs = require("fs");
const path = require("path");

const SRC = path.join(__dirname, "src");
const PORT = Number(process.env.PORT || 5175);

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".json": "application/json; charset=utf-8",
  ".ico": "image/x-icon",
};

function send(res, status, body, headers = {}) {
  res.writeHead(status, headers);
  res.end(body);
}

const server = http.createServer((req, res) => {
  if (req.method !== "GET" && req.method !== "HEAD") {
    send(res, 405, "Method Not Allowed");
    return;
  }

  let rel = decodeURIComponent(new URL(req.url, "http://127.0.0.1").pathname);
  if (rel === "/") rel = "/index.html";
  const file = path.normalize(path.join(SRC, rel));
  if (!file.startsWith(SRC)) {
    send(res, 403, "Forbidden");
    return;
  }

  fs.readFile(file, (err, data) => {
    if (err) {
      send(res, 404, "Not Found");
      return;
    }
    send(res, 200, data, { "Content-Type": TYPES[path.extname(file)] || "application/octet-stream" });
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`Kang Data  http://127.0.0.1:${PORT}/`);
});
