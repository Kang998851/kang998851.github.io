const fs = require("fs");
const path = require("path");

const MAX_CHARS = 24000;
const MAX_WORDS = 500;
const MAX_SENTENCES = 40;
const WORDS_PER_DAY = 8;
const MAX_DAYS = 60;
const MAX_FILE_BYTES = 8 * 1024 * 1024;
const API_URL = "https://api.deepseek.com/chat/completions";

function loadEnv(rootDir) {
  const file = path.join(rootDir, ".env");
  if (!fs.existsSync(file)) return;
  const text = fs.readFileSync(file, "utf8");
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const i = trimmed.indexOf("=");
    if (i < 1) continue;
    const key = trimmed.slice(0, i).trim();
    let value = trimmed.slice(i + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    if (key && process.env[key] == null) process.env[key] = value;
  }
}

function apiKey() {
  return String(process.env.DEEPSEEK_API_KEY || "").trim();
}

function modelId() {
  return String(process.env.DEEPSEEK_MODEL || "deepseek-v4-flash").trim();
}

function decodeText(buffer) {
  const bytes = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);
  if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe) {
    return bytes.toString("utf16le");
  }
  if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) {
    return new TextDecoder("utf-16be").decode(bytes);
  }
  const utf8 = bytes.toString("utf8");
  if (!/[\uFFFD]/.test(utf8) || utf8.replace(/\uFFFD/g, "").trim().length > 20) {
    return utf8;
  }
  try {
    return new TextDecoder("gbk").decode(bytes);
  } catch {
    return utf8;
  }
}

async function extractText(filename, buffer) {
  const name = String(filename || "material.txt");
  const ext = path.extname(name).toLowerCase();
  const buf = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);

  if (ext === ".xlsx" || ext === ".xls") {
    const XLSX = require("xlsx");
    const wb = XLSX.read(buf, { type: "buffer" });
    return wb.SheetNames.map((sheet) => XLSX.utils.sheet_to_csv(wb.Sheets[sheet]))
      .filter(Boolean)
      .join("\n");
  }
  if (ext === ".docx") {
    const mammoth = require("mammoth");
    const result = await mammoth.extractRawText({ buffer: buf });
    return String(result.value || "");
  }
  if (ext === ".pdf") {
    const pdfParse = require("pdf-parse");
    const result = await pdfParse(buf);
    return String(result.text || "");
  }
  if (ext === ".doc") {
    throw new Error("old-doc");
  }
  return decodeText(buf);
}

function tidyTerm(value) {
  return String(value || "")
    .replace(/^[（(]\d+[）)]\s*/, "")
    .replace(/^\d+[\.、．]\s*/, "")
    .replace(/^[一二三四五六七八九十]+[、.]\s*/, "")
    .replace(/\s+/g, " ")
    .trim();
}

function isJunkItem(word, meaning) {
  const w = String(word || "").trim();
  const m = String(meaning || "").trim();
  if (w.length < 2 || w.length > 80) return true;
  if (/^\d+$/.test(w) || /^\d+$/.test(m)) return true;
  if (/^第?\s*\d+\s*页$/.test(w) || /^第?\s*\d+\s*页$/.test(m)) return true;
  if (/^[\s\-–—_.=:：()（）]+$/.test(w) || /^[\s\-–—_.=:：()（）]+$/.test(m)) return true;
  if (/^\(\d+\)$/.test(w)) return true;
  if (m && /[\u4e00-\u9fff]/.test(m) && m.length < 8 && !/[；。=∩∪∈]/.test(m)) return true;
  if (m && m.length < 4 && !/[+\-=≠≈≤≥×÷√∑∫°π∞∩∪∈⊂∅φ]/.test(m)) return true;
  if (m && /^[\d\s\-–—_.]+$/.test(m)) return true;
  if (/^https?:/i.test(m) || /^https?:/i.test(w)) return true;
  if (/^(若|当|则|即|故)[\u4e00-\u9fff]{0,4}$/.test(w)) return true;
  if (/Axx|[A-Z]xx[a-z]|xxf|\[\s*\]|\(\s*\d+\s*\/\s*\d+/.test(w + m)) return true;
  if (/^(叫做|显然|因此|所以|于是|从而|这两个|都分别)/.test(w) || /^(叫做|显然)/.test(m)) return true;
  if (/^[∪∩∈⊂⊃∅Uun]+$/iu.test(w)) return true;
  if (/^U+$/i.test(w) || /^n+$/i.test(w) || /^x+$/i.test(w)) return true;
  if (/^[A-Za-z]{1,3}$/.test(w) && !/^(sin|cos|tan|log|ln|lim|max|min|gcd|lcm|mod|abs)$/i.test(w)) return true;
  if (/^[A-Za-z]{2,4}$/.test(w) && w === w.toUpperCase() && !/^(sin|cos|tan|max|min|log|ln|lim)$/i.test(w)) return true;
  return false;
}

function isScrapOption(value) {
  const s = String(value || "").replace(/\s+/g, " ").trim();
  if (!s) return true;
  if (/^第?\s*\d+\s*页$/.test(s)) return true;
  if (/^\d{4,}$/.test(s)) return true;
  if (/^[∪∩∈⊂⊃∅Uun]+$/iu.test(s) && !/[∪∩∈∅]/.test(s)) return true;
  if (/^U+$/i.test(s) || /^n+$/i.test(s) || /^x+$/i.test(s)) return true;
  if (/^[A-Za-z]{1,3}$/.test(s) && !/^(sin|cos|tan|log|ln|lim|max|min|gcd|lcm|mod|abs)$/i.test(s)) return true;
  if (/^[A-Za-z]{2,4}$/.test(s) && s === s.toUpperCase() && !/^(sin|cos|tan|max|min|log|ln|lim)$/i.test(s)) return true;
  return false;
}

function uniqueOptions(list) {
  const seen = new Set();
  return list
    .map((s) => String(s || "").replace(/\s+/g, " ").trim())
    .filter((s) => {
      if (!s || s.length > 80 || seen.has(s) || isScrapOption(s)) return false;
      seen.add(s);
      return true;
    });
}

function normalizeQuestion(raw) {
  if (!raw) return null;
  const type = String(raw.type || "").trim();
  const prompt = String(raw.prompt || raw.stem || raw.question || "")
    .replace(/\s+/g, " ")
    .trim();
  const hint = String(raw.hint || "").replace(/\s+/g, " ").trim().slice(0, 40);
  if (prompt.length < 6 || isScrapOption(prompt)) return null;

  if (type === "choice" || type === "mcq") {
    const options = uniqueOptions(raw.options || raw.choices || []);
    let answer = String(raw.answer || raw.correct || "").replace(/\s+/g, " ").trim();
    if (answer && !options.includes(answer)) {
      const letter = answer.match(/^([A-Da-d])(?:[\.、．]\s*(.*))?$/);
      if (letter) {
        const idx = letter[1].toUpperCase().charCodeAt(0) - 65;
        if (letter[2] && options.includes(letter[2].trim())) answer = letter[2].trim();
        else if (options[idx]) answer = options[idx];
      }
    }
    if (!answer || !options.includes(answer) || options.length < 3) return null;
    return {
      type: "choice",
      prompt: prompt.slice(0, 320),
      hint,
      options: options.slice(0, 4),
      answer,
    };
  }

  if (type === "spell" || type === "fill" || type === "cloze") {
    const answer = String(raw.answer || "").replace(/\s+/g, " ").trim();
    if (!answer || answer.length > 40 || isScrapOption(answer)) return null;
    return {
      type: type === "fill" ? "spell" : type === "spell" ? "spell" : "cloze",
      prompt: prompt.slice(0, 320),
      hint,
      answer,
    };
  }

  if (type === "match") {
    const pairs = (raw.pairs || [])
      .map((p) => ({
        word: tidyTerm(p.word || p.left || ""),
        meaning: String(p.meaning || p.right || "").replace(/\s+/g, " ").trim(),
      }))
      .filter((p) => p.word.length >= 2 && p.meaning.length >= 6 && !isJunkItem(p.word, p.meaning));
    if (pairs.length < 3) return null;
    return { type: "match", prompt: prompt.slice(0, 80), hint, pairs: pairs.slice(0, 4) };
  }

  return null;
}

function cleanExtracted(text) {
  return String(text || "")
    .replace(/\r/g, "\n")
    .replace(/([\u4e00-\u9fff])\s+(?=[\u4e00-\u9fff])/g, "$1")
    .split("\n")
    .map((line) => line.replace(/[^\S\n]{2,}/g, " ").trim())
    .filter((line) => {
      if (!line || line.length < 2) return false;
      if (/^\d+$/.test(line)) return false;
      if (/^第?\s*\d+\s*页$/.test(line)) return false;
      if (/^[\s\-–—_.=]+$/.test(line)) return false;
      if (/Axx|[A-Z]xx[a-z]|xxf|\[\s*\]|\(\s*\d+\s*\/\s*\d+/.test(line)) return false;
      if (/^(叫做|显然|因此|所以|于是|从而)\S{0,12}$/.test(line)) return false;
      return true;
    })
    .join("\n");
}

function normalizeResult(data, fallbackName) {
  const seen = new Set();
  const words = [];
  const pushWord = (raw) => {
    if (!raw) return;
    const word = tidyTerm(
      String(raw.word || raw.term || raw.en || "")
        .replace(/\s+/g, " ")
        .trim(),
    );
    const meaning = String(raw.meaning || raw.zh || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 80);
    if (isJunkItem(word, meaning)) return;
    const key = word.toLowerCase();
    if (seen.has(key)) return;
    seen.add(key);
    words.push({ word, meaning });
  };

  const groups = [];
  if (Array.isArray(data.days) && data.days.length) {
    for (const day of data.days.slice(0, MAX_DAYS)) {
      const dayWords = [];
      const start = words.length;
      (day.words || []).forEach(pushWord);
      dayWords.push(...words.slice(start));
      const sentences = (day.sentences || [])
        .map((s) => String(s || "").replace(/\s+/g, " ").trim())
        .filter((s) => s.split(/\s+/).length >= 4 || /[\u4e00-\u9fff]{6,}/.test(s))
        .slice(0, 4);
      const questions = (day.questions || []).map(normalizeQuestion).filter(Boolean).slice(0, 10);
      const title = String(day.title || day.section || "").replace(/\s+/g, " ").trim().slice(0, 24);
      if (dayWords.length || sentences.length || questions.length) {
        groups.push({ title, words: dayWords, sentences, questions });
      }
    }
  } else {
    (data.words || []).forEach(pushWord);
  }

  const sentences = (data.sentences || [])
    .map((s) => String(s || "").replace(/\s+/g, " ").trim())
    .filter((s) => s.split(/\s+/).length >= 4 || /[\u4e00-\u9fff]{6,}/.test(s))
    .slice(0, MAX_SENTENCES);

  const clipped = words.slice(0, MAX_WORDS);
  if (!groups.length && clipped.length) {
    const dayCount = Math.min(MAX_DAYS, Math.max(1, Math.ceil(clipped.length / WORDS_PER_DAY)));
    const size = Math.ceil(clipped.length / dayCount);
    for (let i = 0; i < clipped.length; i += size) {
      groups.push({
        words: clipped.slice(i, i + size),
        sentences: i === 0 ? sentences.slice(0, 4) : sentences.slice(4, 8),
        questions: [],
      });
    }
  }

  return {
    ok: true,
    subject: normalizeSubject(data.subject),
    scope: String(data.scope || fallbackName || "我的资料").trim().slice(0, 80),
    words: clipped,
    sentences,
    groups,
  };
}

function normalizeSubject(raw) {
  const s = String(raw || "").trim();
  const map = {
    english: "英语",
    math: "数学",
    mathematics: "数学",
    chinese: "语文",
    physics: "物理",
    chemistry: "化学",
    biology: "生物",
    history: "历史",
    geography: "地理",
    politics: "道德与法治",
  };
  if (map[s.toLowerCase()]) return map[s.toLowerCase()];
  if (/语文|数学|英语|物理|化学|生物|历史|地理|政治|道德/.test(s)) return s.slice(0, 12);
  return s || "综合";
}

function parseJson(raw) {
  const text = String(raw || "").trim();
  const fenced = text.match(/\{[\s\S]*\}/);
  return JSON.parse(fenced ? fenced[0] : text);
}

function looksLikeVocab(words) {
  if (!words?.length) return false;
  const latin = words.filter((w) => /^[A-Za-z]/.test(String(w.word || "")) && w.meaning).length;
  return latin >= 4 && latin / words.length > 0.6;
}

function quizCount(result) {
  return (result.groups || []).reduce((n, g) => n + (g.questions?.length || 0), 0);
}

const AUTHOR_PROMPT =
  'You are a teacher writing a daily quiz from a student-imported document. Return JSON only. Schema: {"subject":"数学","scope":"short title","days":[{"title":"集合","questions":[{"type":"choice","prompt":"设全集 U={1,2,3,4,5}，A={1,2,3}，B={3,4}，则 ∁_U(A∪B)=","options":["{5}","{4,5}","{1,2}","∅"],"answer":"{5}","hint":"选择正确答案"}]}]}. Subjects: 语文, 数学, 英语, 物理, 化学, 生物, 历史, 地理, 道德与法治, or 综合. Write COMPLETE exam stems, never leftover PDF fragments such as 叫做…显然 or 这两个函数才相同. For choice, answer MUST be the exact option string. Four options of the SAME kind; plausible mistakes from THIS section only. Never use OCR scraps (UU, Axxfy, page numbers). Use Unicode ∪ ∩ ∁ ∈ ∅. Mostly choice. Stay inside this document; do not recreate a publisher textbook.';

async function callDeepSeek(text, filename) {
  const key = apiKey();
  if (!key) return { ok: false, error: "no-key" };

  const runs = [
    { text: text.slice(0, MAX_CHARS), extra: "Write 6–8 questions per day, at most 8 days, one section per day." },
    { text: text.slice(0, 12000), extra: "Compact JSON. At most 5 days, 6 questions each." },
  ];

  let lastError = "network";
  for (const run of runs) {
    const body = {
      model: modelId(),
      temperature: 0.35,
      max_tokens: 8192,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: AUTHOR_PROMPT },
        {
          role: "user",
          content: `Filename: ${filename}\n${run.extra}\n\nDocument:\n${run.text}`,
        },
      ],
    };
    for (let attempt = 0; attempt < 2; attempt++) {
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(), 120000);
      try {
        const res = await fetch(API_URL, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(body),
          signal: ac.signal,
        });
        if (!res.ok) {
          lastError =
            res.status === 401
              ? "bad-key"
              : res.status === 402
                ? "quota"
                : res.status === 429 || res.status >= 500
                  ? "busy"
                  : "upstream";
          if ((res.status === 429 || res.status >= 500) && attempt === 0) {
            await new Promise((r) => setTimeout(r, 1200));
            continue;
          }
          break;
        }
        const payload = await res.json();
        const content =
          payload?.choices?.[0]?.message?.content || payload?.choices?.[0]?.message?.reasoning_content || "";
        let data;
        try {
          data = parseJson(content);
        } catch {
          lastError = "empty";
          break;
        }
        const result = normalizeResult(data, path.basename(filename, path.extname(filename)));
        if (quizCount(result) >= 3 || looksLikeVocab(result.words)) return result;
        lastError = "empty";
        break;
      } catch (err) {
        if (err?.name === "AbortError") return { ok: false, error: "timeout" };
        lastError = "network";
      } finally {
        clearTimeout(timer);
      }
    }
  }
  return { ok: false, error: lastError };
}

async function analyzeDocument({ filename, buffer, text }) {
  const name = String(filename || "material.txt");
  let raw = String(text || "").trim();
  const buf = buffer
    ? Buffer.isBuffer(buffer)
      ? buffer
      : Buffer.from(buffer)
    : null;
  if (buf && buf.length > MAX_FILE_BYTES) return { ok: false, error: "too-large" };
  if (!raw && buf && buf.length) {
    try {
      raw = await extractText(name, buf);
    } catch (err) {
      if (String(err?.message) === "old-doc") return { ok: false, error: "old-doc" };
      return { ok: false, error: "extract" };
    }
  }
  raw = cleanExtracted(String(raw || "").replace(/\u0000/g, ""));
  if (!raw) return { ok: false, error: "empty" };
  if (raw.length > MAX_CHARS) raw = raw.slice(0, MAX_CHARS);
  const result = await callDeepSeek(raw, name);
  return { ...result, extracted: raw };
}

module.exports = { loadEnv, analyzeDocument, apiKey };
