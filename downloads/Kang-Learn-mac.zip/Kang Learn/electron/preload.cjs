const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("kangDesktop", {
  openSite: (url) => ipcRenderer.invoke("open-site", url),
  analyzeFile: (payload) => ipcRenderer.invoke("analyze-file", payload),
});
