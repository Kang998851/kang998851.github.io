const http = require("http");
const fs = require("fs");
const path = require("path");
const { loadEnv, analyzeDocument } = require("./electron/analyze.cjs");

const root = __dirname;
loadEnv(root);

const SRC = path.join(root, "src");
const PORT = Number(process.env.PORT || 5173);

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".json": "application/json; charset=utf-8",
  ".ico": "image/x-icon",
};

function send(res, status, body, headers = {}) {
  res.writeHead(status, {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, x-filename",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    ...headers,
  });
  res.end(body);
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error("too-large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://127.0.0.1");

  if (req.method === "OPTIONS") {
    send(res, 204, "");
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/health") {
    send(res, 200, JSON.stringify({ ok: true }), { "Content-Type": "application/json; charset=utf-8" });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/analyze") {
    try {
      const buf = await readBody(req, 8 * 1024 * 1024);
      const filename = decodeURIComponent(req.headers["x-filename"] || "material.txt");
      const ctype = String(req.headers["content-type"] || "");
      let result;
      if (ctype.includes("application/json")) {
        const payload = JSON.parse(buf.toString("utf8") || "{}");
        result = await analyzeDocument({
          filename: payload.filename || filename,
          text: payload.text || "",
          buffer: payload.base64 ? Buffer.from(payload.base64, "base64") : undefined,
        });
      } else {
        result = await analyzeDocument({ filename, buffer: buf });
      }
      send(res, 200, JSON.stringify(result), { "Content-Type": "application/json; charset=utf-8" });
    } catch {
      send(res, 400, JSON.stringify({ ok: false, error: "network" }), {
        "Content-Type": "application/json; charset=utf-8",
      });
    }
    return;
  }

  if (req.method !== "GET" && req.method !== "HEAD") {
    send(res, 405, "Method Not Allowed");
    return;
  }

  let rel = decodeURIComponent(url.pathname);
  if (rel === "/") rel = "/index.html";
  const file = path.normalize(path.join(SRC, rel));
  if (!file.startsWith(SRC)) {
    send(res, 403, "Forbidden");
    return;
  }
  fs.readFile(file, (err, data) => {
    if (err) {
      send(res, 404, "Not Found");
      return;
    }
    send(res, 200, data, { "Content-Type": TYPES[path.extname(file)] || "application/octet-stream" });
  });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`Kang Learn  http://127.0.0.1:${PORT}/`);
});
