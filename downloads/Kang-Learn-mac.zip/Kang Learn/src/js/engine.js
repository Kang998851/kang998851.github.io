import { FREE_LEVELS, PASS_TEST } from "./config.js";
import {
  isFragment,
  isLatinScrap,
  normalizeAuthoredQuestion,
  sameKind,
  tidyItem,
  usableAuthoredQuestion,
  usableItem,
} from "./quality.js";

export function buildPlan({ scope, days, words, sentences, requestedDays, groups, subject }) {
  if (Array.isArray(groups) && groups.length) {
    return buildGroupedPlan({ scope, groups, requestedDays, subject });
  }

  const items = words.map((w, i) => ({
    id: `w${i + 1}`,
    word: w.word,
    meaning: w.meaning || "",
  }));
  const sents = sentences.map((text, i) => ({
    id: `s${i + 1}`,
    text,
  }));

  const usableDays = Math.max(
    1,
    Math.min(days, Math.max(items.length, sents.length, 1)),
  );

  const wordChunks = chunk(items, usableDays);
  const sentChunks = chunk(sents, usableDays);

  const levels = [];
  let id = 1;
  for (let d = 1; d <= usableDays; d++) {
    const dayWords = wordChunks[d - 1] || [];
    const daySents = sentChunks[d - 1] || [];
    if (!dayWords.length && !daySents.length) continue;

    levels.push(makeLevel(id++, d, dayWords, daySents, []));
  }

  if (levels[0]) levels[0].status = "available";

  return {
    scope: String(scope || "").trim() || "我的资料",
    subject: inferSubject(subject, scope, items),
    requestedDays,
    days: usableDays,
    createdAt: Date.now(),
    words: items,
    sentences: sents,
    levels,
    wrongQueue: [],
  };
}

function buildGroupedPlan({ scope, groups, requestedDays, subject }) {
  const items = [];
  const sents = [];
  const levels = [];
  const seen = new Set();
  let id = 1;
  let day = 1;
  for (const group of groups) {
    const dayWords = [];
    for (const raw of group.words || []) {
      const word = String(raw.word || "").trim();
      const key = word.toLowerCase();
      if (!word || seen.has(key)) continue;
      seen.add(key);
      const item = { id: `w${items.length + 1}`, word, meaning: String(raw.meaning || "") };
      items.push(item);
      dayWords.push(item);
    }
    const daySents = [];
    for (const text of group.sentences || []) {
      const line = String(text || "").trim();
      if (!line) continue;
      const sent = { id: `s${sents.length + 1}`, text: line };
      sents.push(sent);
      daySents.push(sent);
    }
    const dayQuestions = (group.questions || [])
      .map((raw, i) => normalizeAuthoredQuestion({ ...raw, id: raw.id || `q-d${day}-${i + 1}` }))
      .filter(Boolean);
    if (!dayWords.length && !daySents.length && !dayQuestions.length) continue;
    const title = String(group.title || "").replace(/\s+/g, " ").trim();
    levels.push(makeLevel(id++, day++, dayWords, daySents, dayQuestions, title));
  }
  if (levels[0]) levels[0].status = "available";
  return {
    scope: String(scope || "").trim() || "我的资料",
    subject: inferSubject(subject, scope, items),
    requestedDays: requestedDays || levels.length,
    days: levels.length,
    createdAt: Date.now(),
    words: items,
    sentences: sents,
    levels,
    wrongQueue: [],
  };
}

function inferSubject(raw, scope, items = []) {
  const given = String(raw || "").trim();
  const mapped = {
    english: "英语",
    math: "数学",
    chinese: "语文",
    physics: "物理",
    chemistry: "化学",
    biology: "生物",
    history: "历史",
    geography: "地理",
  }[given.toLowerCase()];
  if (mapped) return mapped;
  if (given) return given.slice(0, 12);
  const blob = `${scope || ""} ${items.slice(0, 8).map((w) => w.word).join(" ")}`;
  if (/英语|english|vocab/i.test(blob)) return "英语";
  if (/数学|函数|方程|几何/.test(blob)) return "数学";
  if (/物理|力学|电路|牛顿/.test(blob)) return "物理";
  if (/化学|分子|离子|化合/.test(blob)) return "化学";
  if (/生物|细胞|光合/.test(blob)) return "生物";
  if (/历史|朝代|战争/.test(blob)) return "历史";
  if (/地理|气候|地形/.test(blob)) return "地理";
  if (/政治|法治|道德/.test(blob)) return "道德与法治";
  if (/语文|古诗|文言|作文/.test(blob)) return "语文";
  const latin = items.filter((w) => /^[A-Za-z]/.test(w.word || "")).length;
  if (items.length && latin / items.length > 0.7) return "英语";
  return "综合";
}

function makeLevel(id, day, dayWords, daySents, questions = [], section = "") {
  const label = String(section || "").trim();
  return {
    id,
    day,
    kind: "day",
    title: label ? `第 ${day} 天 · ${label}` : `第 ${day} 天`,
    wordIds: dayWords.map((w) => w.id),
    sentenceIds: daySents.map((s) => s.id),
    questions,
    status: "locked",
    lastScore: null,
  };
}

export function makeSession(plan, level, subscribed) {
  if (!canEnter(level, subscribed)) {
    return { blocked: level.status === "gated" ? "gated" : "locked" };
  }

  const byId = Object.fromEntries((plan.words || []).map((w) => [w.id, w]));
  const sentById = Object.fromEntries((plan.sentences || []).map((s) => [s.id, s]));
  const newWords = (level.wordIds || []).map((id) => byId[id]).filter(Boolean);
  const reviews = takeReviews(plan, level, byId, newWords);
  const focus = uniqueWords([...newWords, ...reviews]);
  const daySents = (level.sentenceIds || []).map((id) => sentById[id]).filter(Boolean);
  const copy = quizCopy(plan.subject);
  const authored = (level.questions || [])
    .filter(usableAuthoredQuestion)
    .map((q, i) => hydrateAuthored(q, `${level.id}-${i}`, copy))
    .filter(Boolean);
  const generated = copy.english
    ? buildQuestions(focus, plan.words, daySents, level.kind, plan.subject)
    : [];
  const questions = (authored.length >= 3 ? authored : generated.length ? generated : authored)
    .filter(Boolean)
    .slice(0, 10);
  if (!questions.length) return { blocked: "empty" };

  return {
    blocked: null,
    levelId: level.id,
    title: level.title,
    kind: level.kind,
    source: "level",
    index: 0,
    questions,
    answers: [],
  };
}

export function listWrongBook(plan) {
  if (!plan) return [];
  const byId = Object.fromEntries((plan.words || []).map((w) => [w.id, w]));
  return (plan.wrongQueue || [])
    .map((entry) => {
      const word = byId[entry.itemId];
      if (word) {
        return {
          itemId: entry.itemId,
          word: word.word,
          meaning: word.meaning || "",
          misses: entry.misses || 1,
          dueDay: entry.dueDay,
          lastGiven: entry.lastGiven || "",
        };
      }
      const authored = findAuthored(plan, entry.itemId);
      if (!authored) return null;
      return {
        itemId: entry.itemId,
        word: authored.answer || "错题",
        meaning: authored.prompt || "",
        misses: entry.misses || 1,
        dueDay: entry.dueDay,
        lastGiven: entry.lastGiven || "",
        authored,
      };
    })
    .filter(Boolean);
}

export function makeWrongSession(plan, mode) {
  const items = listWrongBook(plan);
  if (!items.length) return { blocked: "empty" };

  const copy = quizCopy(plan.subject);
  const authored = items
    .map((item) => item.authored)
    .filter(usableAuthoredQuestion)
    .map((q, i) => hydrateAuthored(q, `wrong-${i}`, copy))
    .filter(Boolean);

  if (mode !== "match" && authored.length >= 2) {
    return {
      blocked: null,
      levelId: null,
      title: "错题本 · 测试",
      kind: "wrong-test",
      source: "notebook",
      index: 0,
      questions: authored.slice(0, 10),
      answers: [],
    };
  }

  const words = items.map((item) => ({
    id: item.itemId,
    word: item.word,
    meaning: item.meaning,
  }));

  if (mode === "match") {
    const withMeaning = words.filter((w) => w.meaning);
    if (withMeaning.length < 2) {
      return { blocked: "need-meaning" };
    }
    const questions = chunk(withMeaning, Math.ceil(withMeaning.length / 4))
      .map((group, i) => matchQuestion(group, `wrong-${i}`, copy))
      .filter(Boolean);
    if (!questions.length) return { blocked: "need-meaning" };
    return {
      blocked: null,
      levelId: null,
      title: "错题本 · 连线测试",
      kind: "wrong-match",
      source: "notebook",
      index: 0,
      questions,
      answers: [],
    };
  }

  const questions = buildQuestions(words, plan.words, [], "test", plan.subject);
  if (!questions.length) return { blocked: "empty" };
  return {
    blocked: null,
    levelId: null,
    title: "错题本 · 测试",
    kind: "wrong-test",
    source: "notebook",
    index: 0,
    questions,
    answers: [],
  };
}

export function canEnter(level, subscribed) {
  if (!level) return false;
  if (level.status === "available" || level.status === "passed") return true;
  if (level.status === "gated") return Boolean(subscribed);
  return false;
}

export function gradeQuestion(question, response) {
  if (question.type === "match") {
    return question.pairs.every(
      (pair) => normalize(response?.[pair.word]) === normalize(pair.meaning),
    );
  }
  const given = normalize(response);
  return given === normalize(question.answer);
}

export function applyResult(plan, session, subscribed) {
  const notebook = session.source === "notebook";
  const level = plan.levels.find((l) => l.id === session.levelId);
  const day = level?.day || currentDay(plan);
  const correct = session.answers.filter((a) => a.correct).length;
  const total = session.answers.length || 1;
  const ratio = correct / total;
  const line = PASS_TEST;
  const passed = ratio >= line;

  updateWrongQueue(plan, session, day);

  if (!notebook && level) {
    level.lastScore = Math.round(ratio * 100);
    if (passed) {
      level.status = "passed";
      unlockNext(plan, level.id, subscribed);
    }
  }

  return {
    passed,
    ratio,
    line,
    correct,
    total,
    notebook,
    remaining: (plan.wrongQueue || []).length,
  };
}

export function applySubscription(plan, subscribed) {
  if (!plan) return;
  if (!subscribed) return;
  plan.levels.forEach((level, i) => {
    if (level.status !== "gated") return;
    const prev = plan.levels[i - 1];
    if (!prev || prev.status === "passed") level.status = "available";
  });
}

export function gatedCount(plan) {
  return plan.levels.filter((l) => l.status === "gated").length;
}

export function sanitizePlan(plan) {
  if (!plan) return plan;
  const english = !plan.subject || plan.subject === "英语" || plan.subject === "english";
  plan.words = (plan.words || []).map(tidyItem).filter((item) => usableItem(item, english));
  const keep = new Set(plan.words.map((w) => w.id));
  (plan.levels || []).forEach((level) => {
    level.wordIds = (level.wordIds || []).filter((id) => keep.has(id));
    level.sentenceIds = level.sentenceIds || [];
    level.questions = (level.questions || []).map(normalizeAuthoredQuestion).filter(Boolean);
  });
  plan.wrongQueue = (plan.wrongQueue || []).filter((entry) => {
    if (keep.has(entry.itemId)) return true;
    return Boolean(findAuthored(plan, entry.itemId));
  });
  return plan;
}

export function mergeSplitPlan(plan) {
  if (!plan?.levels?.some((l) => l.kind === "practice" || l.kind === "test")) return plan;
  const groups = [];
  for (const level of plan.levels) {
    const last = groups[groups.length - 1];
    if (!last || last.day !== level.day) groups.push({ day: level.day, levels: [level] });
    else last.levels.push(level);
  }
  plan.levels = groups.map((group, i) => {
    const practice = group.levels.find((l) => l.kind === "practice");
    const test = group.levels.find((l) => l.kind === "test");
    const src = practice || test || group.levels[0];
    const statuses = group.levels.map((l) => l.status);
    let status = "locked";
    if (statuses.includes("passed") && (!test || test.status === "passed")) status = "passed";
    else if (statuses.includes("available") || practice?.status === "passed") status = "available";
    else if (statuses.includes("gated")) status = "gated";
    return {
      ...src,
      id: i + 1,
      day: group.day,
      kind: "day",
      title: src.title || `第 ${group.day} 天`,
      wordIds: src.wordIds,
      sentenceIds: src.sentenceIds,
      questions: src.questions || [],
      status,
    };
  });
  if (plan.levels[0] && plan.levels[0].status === "locked") plan.levels[0].status = "available";
  return plan;
}

function unlockNext(plan, levelId, subscribed) {
  const idx = plan.levels.findIndex((l) => l.id === levelId);
  const next = plan.levels[idx + 1];
  if (!next || next.status === "passed" || next.status === "available") return;
  const nextIndex = idx + 1;
  if (subscribed || nextIndex < FREE_LEVELS) {
    next.status = "available";
  } else {
    next.status = "gated";
  }
}

function updateWrongQueue(plan, session, day) {
  const byItem = new Map();
  for (const ans of session.answers) {
    if (!ans.itemId) continue;
    const prev = byItem.get(ans.itemId) || { anyWrong: false, anyCorrect: false, lastGiven: "" };
    if (ans.correct) prev.anyCorrect = true;
    else {
      prev.anyWrong = true;
      prev.lastGiven = String(ans.given || "");
    }
    byItem.set(ans.itemId, prev);
  }

  for (const [itemId, flags] of byItem) {
    if (flags.anyWrong) {
      const existing = plan.wrongQueue.find((w) => w.itemId === itemId);
      if (existing) {
        existing.misses += 1;
        existing.dueDay = day + Math.min(8, 2 ** Math.min(existing.misses, 3));
        existing.lastGiven = flags.lastGiven || existing.lastGiven || "";
      } else {
        plan.wrongQueue.push({
          itemId,
          misses: 1,
          dueDay: day + 1,
          lastGiven: flags.lastGiven,
        });
      }
      continue;
    }
    if (flags.anyCorrect) {
      plan.wrongQueue = plan.wrongQueue.filter((w) => w.itemId !== itemId);
    }
  }
}

function currentDay(plan) {
  const passed = plan.levels.filter((l) => l.status === "passed");
  return passed.length ? passed[passed.length - 1].day : 1;
}

function findAuthored(plan, itemId) {
  if (!plan || !itemId) return null;
  for (const level of plan.levels || []) {
    const hit = (level.questions || []).find((q) => q.id === itemId || q.itemId === itemId);
    if (hit) return hit;
  }
  return null;
}

function hydrateAuthored(raw, suffix, copy) {
  const q = normalizeAuthoredQuestion(raw);
  if (!q) return null;
  const id = q.id || `q-a-${suffix}`;
  const itemId = raw.itemId || id;
  if (q.type === "choice") {
    return {
      id,
      type: "choice",
      itemId,
      prompt: q.prompt,
      hint: q.hint || (copy.english ? "Choose the correct answer" : "选择正确答案"),
      options: shuffle(q.options.slice()),
      answer: q.answer,
    };
  }
  if (q.type === "spell" || q.type === "cloze") {
    return {
      id,
      type: q.type,
      itemId,
      prompt: q.prompt,
      hint: q.hint || (q.type === "cloze" ? copy.clozeHint : copy.spellHint),
      answer: q.answer,
    };
  }
  const pairs = q.pairs.map((p, i) => ({
    word: p.word,
    meaning: p.meaning,
    itemId: `${itemId}-${i}`,
  }));
  return {
    id,
    type: "match",
    hint: q.hint || copy.matchHint,
    prompt: q.prompt || copy.matchPrompt,
    pairs,
    left: pairs.map((p) => ({ key: p.word, label: p.word })),
    right: shuffle(pairs.map((p) => ({ key: p.meaning, label: p.meaning }))),
    answer: Object.fromEntries(pairs.map((p) => [p.word, p.meaning])),
  };
}

function takeReviews(plan, level, byId, newWords) {
  const used = new Set(newWords.map((w) => w.id));
  const due = plan.wrongQueue
    .filter((w) => w.dueDay <= level.day && !used.has(w.itemId))
    .map((w) => byId[w.itemId])
    .filter(Boolean)
    .slice(0, 3);
  return due;
}

function uniqueWords(list) {
  const seen = new Set();
  return list.filter((w) => {
    if (!w || seen.has(w.id)) return false;
    seen.add(w.id);
    return true;
  });
}

function quizCopy(subject) {
  const english = !subject || subject === "英语" || subject === "english";
  return {
    english,
    meaningHint: english ? "选择中文意思" : "选择对应释义",
    termHint: english ? "选择对应单词" : "选择对应术语",
    termPrompt: english ? "选出对应单词" : "选出对应术语",
    matchHint: english ? "先点左边单词，再点右边意思" : "先点左边术语，再点右边释义",
    matchPrompt: english ? "把单词和意思连起来" : "把术语和释义连起来",
    spellHint: english ? "根据中文默写英文" : "根据释义写出答案",
    spellPrompt: english ? "默写这个单词" : "写出对应内容",
    clozeHint: english ? "填入缺去的单词" : "填入缺少的内容",
  };
}

function buildQuestions(focus, allWords, sentences, kind, subject) {
  const copy = quizCopy(subject);
  const items = uniqueWords(
    focus.map(tidyItem).filter((item) => usableItem(item, copy.english)),
  );
  const qs = [];

  const matchable = items.filter((w) => w.meaning && w.meaning.length >= 8);
  if (matchable.length >= 3) {
    const match = matchQuestion(matchable.slice(0, 4), kind === "wrong-test" ? "wrong" : "level", copy);
    if (match) qs.push(match);
  }

  items.forEach((word, i) => {
    if (!word.meaning) {
      if (copy.english || !isLatinScrap(word.word)) qs.push(spellQuestion(word, copy));
      return;
    }
    const shortTerm = word.word.length <= 18 && !/[、，,]/.test(word.word);
    const pickTerm = copy.english ? i % 2 === 1 : shortTerm && i % 2 === 1;
    const choice = pickTerm ? wordChoice(word, items, copy) : meaningChoice(word, items, copy);
    qs.push(choice || meaningChoice(word, items, copy) || spellQuestion(word, copy));
  });

  for (const sentence of sentences.slice(0, 2)) {
    const cloze = clozeQuestion(sentence, items, copy);
    if (cloze) qs.push(cloze);
  }

  return qs.filter(Boolean).slice(0, 10);
}

function meaningChoice(word, nearby, copy) {
  const options = distractors(
    nearby.filter((w) => w.meaning),
    word,
    "meaning",
    3,
  ).map((w) => w.meaning);
  options.push(word.meaning);
  const unique = shuffle(uniqueStrings(options)).slice(0, 4);
  if (unique.length < 3) return null;
  return {
    id: `q-${word.id}-m`,
    type: "choice",
    itemId: word.id,
    prompt: `${word.word}`,
    hint: copy.meaningHint,
    options: unique,
    answer: word.meaning,
  };
}

function wordChoice(word, nearby, copy) {
  const pool = nearby.filter((w) => !isLatinScrap(w.word) || copy.english);
  const options = distractors(pool, word, "word", 3).map((w) => w.word);
  options.push(word.word);
  const unique = shuffle(uniqueStrings(options)).slice(0, 4);
  if (unique.length < 3) return null;
  return {
    id: `q-${word.id}-w`,
    type: "choice",
    itemId: word.id,
    prompt: word.meaning || copy.termPrompt,
    hint: copy.termHint,
    options: unique,
    answer: word.word,
  };
}

function matchQuestion(words, tag, copy = quizCopy()) {
  const pairs = uniqueWords(
    words.filter((w) => w.meaning && w.meaning.length >= 8 && !isLatinScrap(w.word)),
  ).slice(0, 4);
  if (pairs.length < 3) return null;
  return {
    id: `q-match-${tag}-${pairs.map((w) => w.id).join("-")}`,
    type: "match",
    hint: copy.matchHint,
    prompt: copy.matchPrompt,
    pairs: pairs.map((w) => ({ word: w.word, meaning: w.meaning, itemId: w.id })),
    left: pairs.map((w) => ({ key: w.word, label: w.word })),
    right: shuffle(pairs.map((w) => ({ key: w.meaning, label: w.meaning }))),
    answer: Object.fromEntries(pairs.map((w) => [w.word, w.meaning])),
  };
}

function spellQuestion(word, copy = quizCopy()) {
  return {
    id: `q-${word.id}-s`,
    type: "spell",
    itemId: word.id,
    prompt: word.meaning || copy.spellPrompt,
    hint: word.meaning ? copy.spellHint : copy.spellPrompt,
    answer: word.word,
  };
}

function clozeQuestion(sentence, focus, copy = quizCopy()) {
  const text = String(sentence.text || "");
  if (isFragment(text) || text.length > 140 || text.length < 12) return null;
  const terms = focus
    .filter((w) => w.word && w.word.length > 1)
    .sort((a, b) => b.word.length - a.word.length);
  for (const item of terms) {
    const idx = text.toLowerCase().indexOf(item.word.toLowerCase());
    if (idx >= 0) {
      return {
        id: `q-${sentence.id}-c`,
        type: "cloze",
        itemId: item.id,
        prompt: text.slice(0, idx) + "______" + text.slice(idx + item.word.length),
        hint: copy.clozeHint,
        answer: text.slice(idx, idx + item.word.length),
      };
    }
  }
  const tokens = text.split(/(\s+)/);
  const words = focus.map((w) => w.word.toLowerCase());
  let hit = -1;
  let answer = "";
  tokens.forEach((tok, i) => {
    const clean = tok.replace(/[^A-Za-z'-]/g, "").toLowerCase();
    if (hit === -1 && clean.length > 2 && words.includes(clean)) {
      hit = i;
      answer = tok.replace(/[^A-Za-z'-]/g, "");
    }
  });
  if (hit === -1 || !answer) return null;
  const display = tokens.map((tok, i) => (i === hit ? "______" : tok)).join("");
  const item = focus.find((w) => w.word.toLowerCase() === answer.toLowerCase());
  return {
    id: `q-${sentence.id}-c`,
    type: "cloze",
    itemId: item ? item.id : null,
    prompt: display,
    hint: copy.clozeHint,
    answer,
  };
}

function distractors(pool, current, field, n) {
  const seed = String(current[field] || "");
  return shuffle(
    pool.filter(
      (w) =>
        w.id !== current.id &&
        w[field] &&
        w[field] !== current[field] &&
        usableItem(w) &&
        sameKind(seed, w[field]) &&
        String(w[field]).trim().length >= 2,
    ),
  ).slice(0, n);
}

function uniqueStrings(list) {
  const seen = new Set();
  return list.filter((s) => {
    const key = normalize(s);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function chunk(items, days) {
  const out = Array.from({ length: days }, () => []);
  if (!items.length) return out;
  const base = Math.floor(items.length / days);
  const extra = items.length % days;
  let i = 0;
  for (let d = 0; d < days; d++) {
    const size = base + (d < extra ? 1 : 0);
    out[d] = items.slice(i, i + size);
    i += size;
  }
  return out;
}

function shuffle(list) {
  const a = list.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function normalize(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[’]/g, "'")
    .replace(/\s+/g, " ");
}
