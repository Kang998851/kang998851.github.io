const MATH_SHORT = /^(sin|cos|tan|cot|sec|csc|log|ln|lim|max|min|gcd|lcm|mod|abs|int|dim)$/i;

export function tidyTerm(value) {
  return String(value || "")
    .replace(/^[（(]\d+[）)]\s*/, "")
    .replace(/^\d+[\.、．]\s*/, "")
    .replace(/^[一二三四五六七八九十]+[、.]\s*/, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function isLatinScrap(word) {
  const w = String(word || "").trim();
  if (!w) return true;
  if (/[∪∩∈⊂⊃∅]/.test(w) && !/[A-Za-z]/.test(w)) return false;
  if (/^[∪∩∈⊂⊃∅Uun]+$/iu.test(w)) return true;
  if (/^U+$/i.test(w) || /^n+$/i.test(w) || /^x+$/i.test(w)) return true;
  if (/^[A-Za-z]{1,3}$/.test(w) && !MATH_SHORT.test(w)) return true;
  if (/^[A-Za-z]{2,4}$/.test(w) && w === w.toUpperCase() && !MATH_SHORT.test(w)) return true;
  return false;
}

export function isFragment(value) {
  const s = String(value || "").replace(/\s+/g, " ").trim();
  if (!s) return false;
  if (/Axx|[A-Z]xx[a-z]|xxf|xxfy|\[\s*\]|\(\s*\d+\s*\/\s*\d+/.test(s)) return true;
  if (/^(叫做|显然|因此|所以|于是|从而|也就是|即有|故有|才相同|才成立)/.test(s)) return true;
  if (/^(这两个|都分别)/.test(s) && !/[？?=]/.test(s) && s.length < 28) return true;
  if (/(显然|叫做)$/.test(s.replace(/[。．.]+$/, ""))) return true;
  if (/^[，、；;]/.test(s)) return true;
  return false;
}

export function isJunkItem(word, meaning, english = false) {
  const w = tidyTerm(word);
  const m = String(meaning || "").replace(/\s+/g, " ").trim();
  if (w.length < 2 || w.length > 80) return true;
  if (isFragment(w) || isFragment(m)) return true;
  if (/^\d+$/.test(w) || /^\d+$/.test(m)) return true;
  if (/^第?\s*\d+\s*页$/.test(w) || /^第?\s*\d+\s*页$/.test(m)) return true;
  if (/^[\s\-–—_.=:：()（）]+$/.test(w) || /^[\s\-–—_.=:：()（）]+$/.test(m)) return true;
  if (/^\(\d+\)$/.test(w)) return true;
  if (/^https?:/i.test(m) || /^https?:/i.test(w)) return true;
  if (m && /^[\d\s\-–—_.]+$/.test(m)) return true;
  if (/^(若|当|则|即|故)[\u4e00-\u9fff]{0,4}$/.test(w)) return true;
  if (!english && isLatinScrap(w)) return true;
  if (english && isLatinScrap(w) && w.length <= 3 && !MATH_SHORT.test(w)) return true;
  if (m && /[\u4e00-\u9fff]/.test(m) && m.length < 8 && !/[；。=∩∪∈]/.test(m)) return true;
  if (m && m.length < 4 && !/[+\-=≠≈≤≥×÷√∩∪∈]/.test(m)) return true;
  return false;
}

export function sameKind(a, b) {
  const x = String(a || "").trim();
  const y = String(b || "").trim();
  if (!x || !y) return false;
  if (isLatinScrap(y)) return false;
  const cjkX = /[\u4e00-\u9fff]/.test(x);
  const cjkY = /[\u4e00-\u9fff]/.test(y);
  if (cjkX !== cjkY) return false;
  if (cjkX && (y.length < 2 || y.length > 48)) return false;
  return true;
}

export function usableItem(item, english = false) {
  if (!item) return false;
  return !isJunkItem(item.word, item.meaning, english);
}

export function tidyItem(item) {
  if (!item) return item;
  return {
    ...item,
    word: tidyTerm(item.word),
    meaning: String(item.meaning || "").replace(/\s+/g, " ").trim(),
  };
}

export function isScrapText(value) {
  const s = String(value || "").replace(/\s+/g, " ").trim();
  if (!s) return true;
  if (/^第?\s*\d+\s*页$/.test(s)) return true;
  if (/^[\s\-–—_.=:：()（）]+$/.test(s)) return true;
  if (/^\d{4,}$/.test(s)) return true;
  if (isLatinScrap(s) && !MATH_SHORT.test(s)) return true;
  if (/^(若|当|则|即|故)[\u4e00-\u9fff]{0,4}$/.test(s)) return true;
  if (isFragment(s)) return true;
  return false;
}

function uniqueTrimmed(list) {
  const seen = new Set();
  return list
    .map((s) => String(s || "").replace(/\s+/g, " ").trim())
    .filter((s) => {
      if (!s || seen.has(s)) return false;
      seen.add(s);
      return true;
    });
}

function resolvedChoice(raw) {
  const options = uniqueTrimmed(raw.options || []).filter((opt) => !isScrapText(opt) && opt.length <= 80);
  let answer = String(raw.answer || "").replace(/\s+/g, " ").trim();
  if (answer && !options.includes(answer)) {
    const letter = answer.match(/^([A-Da-d])(?:[\.、．]\s*(.*))?$/);
    if (letter) {
      const idx = letter[1].toUpperCase().charCodeAt(0) - 65;
      if (letter[2] && options.includes(letter[2].trim())) answer = letter[2].trim();
      else if (options[idx]) answer = options[idx];
    }
  }
  return { options, answer };
}

export function usableAuthoredQuestion(q) {
  if (!q) return false;
  const type = String(q.type || "").trim();
  const prompt = String(q.prompt || "").replace(/\s+/g, " ").trim();
  if (prompt.length < 6 || isScrapText(prompt) || isFragment(prompt)) return false;

  if (type === "choice") {
    const { options, answer } = resolvedChoice(q);
    if (!answer || isScrapText(answer)) return false;
    if (options.length < 3 || options.length > 6) return false;
    if (!options.includes(answer)) return false;
    const kin = options.filter((opt) => opt === answer || sameKind(answer, opt));
    return kin.length >= 3;
  }

  if (type === "spell" || type === "cloze") {
    const answer = String(q.answer || "").replace(/\s+/g, " ").trim();
    if (!answer || answer.length > 40 || isScrapText(answer)) return false;
    if (type === "cloze" && !/_{2,}|（\s*）|\(\s*\)/.test(prompt) && !prompt.includes("______")) {
      return prompt.length >= 8;
    }
    return true;
  }

  if (type === "match") {
    const pairs = (q.pairs || [])
      .map((p) => ({
        word: tidyTerm(p.word || p.left || ""),
        meaning: String(p.meaning || p.right || "").replace(/\s+/g, " ").trim(),
      }))
      .filter((p) => p.word.length >= 2 && p.meaning.length >= 6 && !isLatinScrap(p.word) && !isScrapText(p.meaning));
    return pairs.length >= 3;
  }

  return false;
}

export function normalizeAuthoredQuestion(raw) {
  if (!usableAuthoredQuestion(raw)) return null;
  const type = String(raw.type || "").trim();
  const prompt = String(raw.prompt || "").replace(/\s+/g, " ").trim();
  const hint = String(raw.hint || "").replace(/\s+/g, " ").trim();
  const id = String(raw.id || "").trim();

  if (type === "choice") {
    const { options, answer } = resolvedChoice(raw);
    const kin = options
      .filter((opt) => opt === answer || sameKind(answer, opt))
      .slice(0, 4);
    if (!kin.includes(answer) || kin.length < 3) return null;
    return { id, type, prompt, hint, options: kin, answer };
  }

  if (type === "spell" || type === "cloze") {
    return {
      id,
      type,
      prompt,
      hint,
      answer: String(raw.answer || "").replace(/\s+/g, " ").trim(),
    };
  }

  const pairs = (raw.pairs || [])
    .map((p) => ({
      word: tidyTerm(p.word || p.left || ""),
      meaning: String(p.meaning || p.right || "").replace(/\s+/g, " ").trim(),
    }))
    .filter((p) => p.word.length >= 2 && p.meaning.length >= 6 && !isLatinScrap(p.word) && !isScrapText(p.meaning))
    .slice(0, 4);
  if (pairs.length < 3) return null;
  return { id, type: "match", prompt, hint, pairs };
}
