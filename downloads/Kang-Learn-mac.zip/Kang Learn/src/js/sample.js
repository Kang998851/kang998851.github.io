/** Original KangStudio sample — not copied from any publisher textbook. */
export const SAMPLE_SCOPE = "高中英语示例词表（自编，非教材）";
export const SAMPLE_DAYS = 20;

export const SAMPLE_TEXT = `ambition  抱负；雄心
analyze  分析
approach  方法；靠近
assume  假定；认为
benefit  益处
capable  有能力的
challenge  挑战
circumstance  情况；环境
commit  承诺；投入
conflict  冲突
consequence  后果
contribute  贡献
convince  说服
critic  评论家；批评者
decline  下降；拒绝
demonstrate  证明；演示
determine  决定；决心
distinct  明显不同的
economy  经济
efficient  高效的
emphasize  强调
enable  使能够
encounter  遭遇；遇到
essential  必要的
evaluate  评估
evidence  证据
expand  扩展
expose  暴露；使接触
factor  因素
feature  特征
flexible  灵活的
focus  专注；焦点
generate  产生
identify  识别
impact  影响
imply  暗示
indicate  表明
individual  个人；个别的
interpret  解释
involve  涉及
issue  问题；议题
maintain  维持
major  主要的
method  方法
obtain  获得
occur  发生
outcome  结果
perceive  察觉；理解
perspective  视角
potential  潜力；潜在的
previous  先前的
process  过程
require  需要
resource  资源
significant  显著的
source  来源
strategy  策略
structure  结构
theory  理论
vary  变化

Learning a language takes patience. Students who analyze new words and review mistakes usually improve faster. A clear strategy, used every day, is more useful than a long list that nobody reads. When you encounter a difficult sentence, try to identify the key idea first, then evaluate the details.`;
