import { emptyAccount, normalizeAccount } from "./auth.js";

const KEY = "kang-learn-v1";

export function loadState() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return emptyState();
    const parsed = JSON.parse(raw);
    const next = { ...emptyState(), ...parsed };
    if (!next.ink && parsed.xp) next.ink = parsed.xp;
    if (!next.planTier) next.planTier = parsed.subscribed ? "pro" : "free";
    next.account = normalizeAccount(parsed.account);
    return next;
  } catch {
    return emptyState();
  }
}

export function saveState(state) {
  localStorage.setItem(
    KEY,
    JSON.stringify({
      plan: state.plan,
      subscribed: Boolean(state.subscribed),
      planTier: state.planTier || "free",
      ink: Number(state.ink) || 0,
      orders: state.orders || [],
      account: normalizeAccount(state.account),
    }),
  );
}

export function clearState() {
  localStorage.removeItem(KEY);
}

export function emptyState() {
  return {
    plan: null,
    subscribed: false,
    planTier: "free",
    ink: 0,
    orders: [],
    account: emptyAccount(),
  };
}
