export function emptyAccount() {
  return {
    name: "",
    salt: "",
    hash: "",
    stay: false,
    guest: false,
    createdAt: "",
  };
}

export function normalizeAccount(raw) {
  const base = emptyAccount();
  if (!raw || typeof raw !== "object") return base;
  return {
    name: String(raw.name || ""),
    salt: String(raw.salt || ""),
    hash: String(raw.hash || ""),
    stay: Boolean(raw.stay),
    guest: Boolean(raw.guest),
    createdAt: String(raw.createdAt || ""),
  };
}

export function hasPassword(account) {
  return Boolean(account?.hash && account?.salt);
}

export function shouldUnlock(account) {
  return Boolean(account?.stay && (hasPassword(account) || account?.guest));
}

export function displayName(account) {
  const name = String(account?.name || "").trim();
  if (name) return name;
  if (account?.guest) return "试用";
  return "";
}

export async function createAccount(name, password, stay) {
  const trimmed = String(name || "").trim();
  if (!trimmed) return { ok: false, error: "请填写显示名。" };
  if (String(password || "").length < 4) return { ok: false, error: "密码至少 4 位。只存在这台电脑。" };
  const salt = hex(crypto.getRandomValues(new Uint8Array(16)));
  const hash = await digest(password, salt);
  return {
    ok: true,
    account: {
      name: trimmed,
      salt,
      hash,
      stay: Boolean(stay),
      guest: false,
      createdAt: new Date().toISOString(),
    },
  };
}

export async function unlockAccount(account, password, stay) {
  if (!hasPassword(account)) return { ok: false, error: "这台电脑还没有账户。请先创建，或先试用。" };
  if (!password) return { ok: false, error: "请输入密码。" };
  const hash = await digest(password, account.salt);
  if (hash !== account.hash) return { ok: false, error: "密码不对。" };
  return {
    ok: true,
    account: { ...account, stay: Boolean(stay), guest: false },
  };
}

export function startGuest(name, stay) {
  return {
    name: String(name || "").trim() || "试用",
    salt: "",
    hash: "",
    stay: Boolean(stay),
    guest: true,
    createdAt: new Date().toISOString(),
  };
}

async function digest(password, salt) {
  const data = new TextEncoder().encode(`${salt}:${password}`);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return hex(new Uint8Array(buf));
}

function hex(bytes) {
  return [...bytes].map((item) => item.toString(16).padStart(2, "0")).join("");
}
