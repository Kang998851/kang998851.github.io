import { FREE_LEVELS, INK_CORRECT, INK_PASS_BONUS, MAX_DAYS, MIN_DAYS, UPGRADE_URL, WORDS_PER_DAY } from "./config.js";
import { parseMaterials, previewStats, looksLikeVocab } from "./parser.js";
import { SAMPLE_SCOPE, SAMPLE_TEXT } from "./sample.js";
import { CATALOG, orderCount, redeem } from "./shop.js";
import { clearState, loadState, saveState } from "./storage.js";
import { applyResult, applySubscription, buildPlan, gradeQuestion, listWrongBook, makeSession, makeWrongSession, mergeSplitPlan, sanitizePlan } from "./engine.js";
import { createAccount, emptyAccount, hasPassword, shouldUnlock, startGuest, unlockAccount } from "./auth.js";

const ui = {
  view: "login",
  loginMode: "create",
  loginError: "",
  draft: { scope: "", days: 20, text: "" },
  session: null,
  picked: null,
  phase: "ask",
  match: null,
  notice: "",
  busy: false,
};

const saved = loadState();
const state = {
  plan: saved.plan,
  subscribed: saved.subscribed,
  planTier: saved.planTier || "free",
  ink: saved.ink || 0,
  orders: saved.orders || [],
  account: saved.account || emptyAccount(),
};

const viewEl = document.getElementById("view");
const chromeEl = document.getElementById("chrome");
const overlayEl = document.getElementById("pass-overlay");
const modalEl = document.getElementById("modal");

document.body.classList.toggle("electron", Boolean(window.kangDesktop));
if (state.plan) {
  mergeSplitPlan(state.plan);
  sanitizePlan(state.plan);
  persist();
}

let sessionOpen = shouldUnlock(state.account);
ui.view = sessionOpen ? (state.plan ? "map" : "import") : "login";
ui.loginMode = hasPassword(state.account) ? "enter" : "create";

chromeEl.addEventListener("click", onClick);
viewEl.addEventListener("click", onClick);
viewEl.addEventListener("submit", onSubmit);
viewEl.addEventListener("change", onChange);
viewEl.addEventListener("input", onInput);
viewEl.addEventListener("dragover", onDragOver);
viewEl.addEventListener("drop", onDrop);
modalEl.addEventListener("click", onClick);
document.addEventListener("keydown", onKey);

render();

function persist() {
  saveState(state);
}

function render() {
  const lesson = ui.view === "play";
  document.body.classList.toggle("lesson", lesson);
  document.body.classList.toggle("gate", ui.view === "login");
  chromeEl.innerHTML = lesson ? lessonChrome() : homeChrome();
  if (ui.view === "login") viewEl.innerHTML = loginView();
  else if (ui.view === "import" || ui.view === "setup") viewEl.innerHTML = importView();
  else if (ui.view === "map") viewEl.innerHTML = mapView();
  else if (ui.view === "notebook") viewEl.innerHTML = notebookView();
  else if (ui.view === "shop") viewEl.innerHTML = shopView();
  else if (ui.view === "play") viewEl.innerHTML = playView();
  else if (ui.view === "result") viewEl.innerHTML = resultView();
  else viewEl.innerHTML = settingsView();
}

function homeChrome() {
  if (ui.view === "login") {
    return `
      <span class="brand">
        ${logoSvg()}
        <span class="brand-studio">KangStudio</span>
        <span class="brand-dot"></span>
        <span>Kang Learn</span>
      </span>
    `;
  }
  const wrong = state.plan?.wrongQueue?.length || 0;
  return `
    <a class="brand" href="#" data-act="home" aria-label="Kang Learn 首页">
      ${logoSvg()}
      <span class="brand-studio">KangStudio</span>
      <span class="brand-dot"></span>
      <span>Kang Learn</span>
    </a>
    <nav class="title-actions">
      <span class="ink-pill" title="墨点"><span class="ink-dot"></span><span class="ink-count">${state.ink}</span></span>
      <button type="button" class="text-btn" data-act="shop">文具柜</button>
      <button type="button" class="text-btn" data-act="notebook">错题本${wrong ? ` ${wrong}` : ""}</button>
      <button type="button" class="text-btn" data-act="settings">设置</button>
      <button type="button" class="text-btn" data-act="logout">退出</button>
    </nav>
  `;
}

function loginView() {
  const locked = hasPassword(state.account);
  const creating = ui.loginMode === "create";
  return `
    <section class="gate-screen">
      <div class="gate-card">
        <p class="eyebrow">KangStudio</p>
        <h1>Kang Learn</h1>
        <p class="lede">电脑端学习软件。账户只存在这台电脑，不上传、不联网登录。打开软件后在此进入，不是网站。</p>
        <div class="segment" role="tablist" aria-label="进入方式">
          <button type="button" class="${creating ? "" : "is-on"}" data-act="login-mode" data-mode="enter">进入</button>
          <button type="button" class="${creating ? "is-on" : ""}" data-act="login-mode" data-mode="create">创建本机账户</button>
        </div>
        <form class="form gate-form" data-form="login">
          <label>显示名
            <input name="name" type="text" maxlength="40" autocomplete="username" value="${esc(state.account?.name || "")}" placeholder="例如 王敏" ${!creating && locked ? "readonly" : ""}>
          </label>
          <label>${creating ? "设置密码" : "密码"}
            <input name="password" type="password" maxlength="64" autocomplete="${creating ? "new-password" : "current-password"}" placeholder="${creating ? "至少 4 位，只保存在本机" : "本机密码"}">
          </label>
          ${
            creating
              ? `<label>确认密码
                  <input name="confirm" type="password" maxlength="64" autocomplete="new-password">
                </label>`
              : ""
          }
          <label class="check">
            <input name="stay" type="checkbox" ${state.account?.stay !== false ? "checked" : ""}>
            在这台电脑保持进入
          </label>
          ${ui.loginError ? `<p class="notice is-bad">${esc(ui.loginError)}</p>` : ""}
          <button class="btn" type="submit">${creating ? "创建并进入" : "进入 Kang Learn"}</button>
        </form>
        <button class="btn btn-ghost" type="button" data-act="trial">先试用，不设密码</button>
        ${locked ? `<button class="text-btn" type="button" data-act="clear-account">清除本机账户</button>` : ""}
        <p class="lede">软件内不向未成年人收款。升级请监护人回官网。密码无法远程找回。</p>
      </div>
    </section>
  `;
}

function lessonChrome() {
  const session = ui.session;
  const total = session?.questions.length || 1;
  const now = (session?.index || 0) + 1;
  return `
    <div class="lesson-hud">
      <button type="button" class="text-btn" data-act="quit-lesson">退出</button>
      <span class="folio">${String(now).padStart(2, "0")} · ${String(total).padStart(2, "0")}</span>
    </div>
  `;
}

function importView() {
  const parsed = parseMaterials(ui.draft.text);
  const stats = previewStats(parsed);
  const ready = stats.wordCount >= 1 || stats.sentenceCount >= 1;
  return `
    <section class="screen">
      <p class="eyebrow">KangStudio · Kang Learn</p>
      <h1>导入文档就开始</h1>
      <p class="lede">导入 txt、csv、Word、Excel 或 PDF。DeepSeek 会识别科目、抽出知识点并按天排关。语文、数学、英语、理化生、史地政都可以。请只导入你有权使用的内容。</p>
      ${ui.notice ? `<p class="notice ${/没通|没开|失败|无效|打不开|超时|没有识别/.test(ui.notice) ? "is-bad" : ""}">${esc(ui.notice)}</p>` : ""}
      <button type="button" class="dropzone" data-act="pick-file" ${ui.busy ? "disabled" : ""}>
        <strong>${ui.busy ? "正在分析…" : "导入文件"}</strong>
        <span>txt / csv / Word / Excel / PDF，点击或拖到这里</span>
      </button>
      <input id="file" type="file" accept=".txt,.csv,.tsv,.md,.xlsx,.xls,.docx,.pdf,text/plain" hidden ${ui.busy ? "disabled" : ""}>
      <form class="form" data-form="import">
        <label>也可以粘贴
          <textarea name="text" placeholder="光合作用  绿色植物利用光能把二氧化碳和水转化成有机物" ${ui.busy ? "disabled" : ""}>${esc(ui.draft.text)}</textarea>
        </label>
        <p class="lede">${stats.wordCount} 个知识点 · ${stats.meaningCount} 条释义 · ${stats.sentenceCount} 句材料。约 ${suggestDays(parsed)} 天。</p>
        <div class="row">
          <button class="btn" type="submit" ${ready && !ui.busy ? "" : "disabled"}>${ui.busy ? "正在分析…" : "开始学习"}</button>
          <button class="btn btn-ghost" type="button" data-act="sample" ${ui.busy ? "disabled" : ""}>使用自编示例</button>
        </div>
      </form>
    </section>
  `;
}

function mapView() {
  const plan = state.plan;
  if (!plan) return importView();
  const passed = plan.levels.filter((l) => l.status === "passed").length;
  const note =
    plan.days !== plan.requestedDays
      ? `<p class="notice">资料不足以排满 ${esc(plan.requestedDays)} 天，已改为 ${esc(plan.days)} 天。</p>`
      : "";
  const review = plan.wrongQueue.length ? ` · ${plan.wrongQueue.length} 道错题` : "";
  return `
    <section class="screen screen-wide">
      <div class="map-head">
        <div>
          <p class="eyebrow">${esc(plan.subject || "闯关")}闯关</p>
          <h1>${esc(plan.scope)}</h1>
          <p class="lede">${esc(plan.days)} 天 · 已过 ${passed} / ${plan.levels.length} 关${review}</p>
        </div>
        <div class="row">
          <button class="btn" type="button" data-act="shop">文具柜</button>
          <button class="btn btn-ghost" type="button" data-act="import-again">更换资料</button>
        </div>
      </div>
      ${note}
      <div class="journal">
        ${groupByDay(plan.levels).map(dayBlock).join("")}
      </div>
      ${
        state.planTier === "free"
          ? `<p class="notice">未订阅可学前 ${FREE_LEVELS} 关。升级请监护人到官网选 Pro 或 Max。Max 贵 20%，可第一时间得到免费周边。</p>`
          : ""
      }
    </section>
  `;
}

function groupByDay(levels) {
  const groups = [];
  for (const level of levels) {
    const last = groups[groups.length - 1];
    if (!last || last.day !== level.day) groups.push({ day: level.day, levels: [level] });
    else last.levels.push(level);
  }
  return groups;
}

function dayBlock(group) {
  return `
    <article class="day-block">
      <span class="day-num">${String(group.day).padStart(2, "0")}</span>
      <div class="day-levels">${group.levels.map(levelCard).join("")}</div>
    </article>
  `;
}

function levelCard(level) {
  const n = level.questions?.length || level.wordIds.length;
  const unit = level.questions?.length ? "题" : level.wordIds.length ? "条" : "材料";
  const words = n ? `${n} ${unit}` : "材料";
  const score = level.lastScore == null ? "" : ` · ${level.lastScore}%`;
  const mark =
    level.status === "passed"
      ? `<span class="stamp"><span class="stamp-ribbons" aria-hidden="true"></span>过关</span>`
      : level.status === "available"
        ? `<span class="pill pill-on">可开始</span>`
        : lockIcon(level.status === "gated");
  return `
    <button type="button" class="level is-${level.status}" data-act="enter" data-id="${level.id}" aria-label="${esc(level.title)}${level.status === "locked" || level.status === "gated" ? "，未解锁" : ""}">
      <span><h2>${esc(level.title)}</h2><p>${words}${score}</p></span>
      ${mark}
    </button>
  `;
}

function lockIcon(gated) {
  return `<svg class="lock ${gated ? "is-gated" : ""}" viewBox="0 0 24 24" width="22" height="22" aria-hidden="true">
    <path d="M8.2 10.4V7.8a3.8 3.8 0 0 1 7.6 0v2.6" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
    <rect x="5.2" y="10.4" width="13.6" height="10.2" rx="3.2" fill="none" stroke="currentColor" stroke-width="1.5"/>
    <circle cx="12" cy="15.2" r="1.15" fill="currentColor"/>
    <path d="M12 16.3v1.8" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>
  </svg>`;
}

function notebookView() {
  if (!state.plan) {
    return `
      <section class="screen">
        <p class="eyebrow">错题本</p>
        <h1>还没有错题</h1>
        <p class="lede">闯关答错的知识点会记在这里，可开一场含连线的错题测试。</p>
        <button class="btn" type="button" data-act="import">开始学习</button>
      </section>
    `;
  }
  const items = listWrongBook(state.plan);
  if (!items.length) {
    return `
      <section class="screen">
        <p class="eyebrow">错题本</p>
        <h1>错题已清空</h1>
        <p class="lede">答对的词会从这里移出。</p>
        <button class="btn" type="button" data-act="map">回到日程</button>
      </section>
    `;
  }
  return `
    <section class="screen screen-wide">
      <div class="map-head">
        <div>
          <p class="eyebrow">错题本</p>
          <h1>${items.length} 个待复习</h1>
          <p class="lede">一场测试里含选择、默写和连线。答对即移出。</p>
        </div>
        <div class="row">
          <button class="btn" type="button" data-act="wrong-test">错题测试</button>
        </div>
      </div>
      ${ui.notice ? `<p class="notice">${esc(ui.notice)}</p>` : ""}
      <div class="wrong-list">
        ${items
          .map(
            (item) => `
          <article class="wrong-card">
            <div>
              <h2 class="wrong-word">${esc(item.word)}</h2>
              <p>${esc(item.meaning || "无释义")}</p>
            </div>
            <p class="lede">错 ${item.misses} 次</p>
          </article>`,
          )
          .join("")}
      </div>
    </section>
  `;
}

function shopView() {
  const isMax = state.planTier === "max";
  return `
    <section class="screen screen-wide">
      <div class="map-head">
        <div>
          <p class="eyebrow">文具柜</p>
          <h1>用墨点兑换周边</h1>
          <p class="lede">笔、本、明信片。软件内不收款。Max 用户优先发货，并可先领一封免费明信片。实物寄送开通后由监护人在官网确认地址。</p>
        </div>
        <span class="ink-pill"><span class="ink-dot"></span> ${state.ink} 墨点</span>
      </div>
      ${ui.notice ? `<p class="notice">${esc(ui.notice)}</p>` : ""}
      <div class="shop-grid">
        ${CATALOG.map((item) => goodsCard(item, isMax)).join("")}
      </div>
      ${
        (state.orders || []).length
          ? `<p class="notice">已兑换 ${(state.orders || []).length} 件。${isMax ? "你的订单会优先处理。" : ""}</p>`
          : ""
      }
    </section>
  `;
}

function goodsCard(item, isMax) {
  const owned = orderCount(state, item.id);
  const freeReady = isMax && item.maxFirst && !(state.orders || []).some((o) => o.itemId === item.id && o.free);
  const cost = freeReady ? 0 : item.cost;
  return `
    <article class="goods">
      <div class="goods-art">${goodsArt(item.kind)}</div>
      <h2>${esc(item.name)}</h2>
      <p>${esc(item.blurb)}</p>
      <div class="goods-meta">
        <span>${cost ? `${cost} 墨点` : "Max 免费先领"}</span>
        <span>${owned ? `已兑 ${owned}` : ""}</span>
      </div>
      ${isMax ? `<p class="priority">优先发货</p>` : ""}
      <button class="btn" type="button" data-act="redeem" data-id="${item.id}" ${state.ink < cost ? "disabled" : ""}>兑换</button>
    </article>
  `;
}

function playView() {
  const session = ui.session;
  if (!session) return mapView();
  const q = session.questions[session.index];
  if (!q) return resultView();
  ensureMatchState(q);
  let body = "";
  if (q.type === "match") body = matchBoard(q);
  else if (q.type === "choice") {
    const keys = ["A", "B", "C", "D", "E", "F"];
    body = `<div class="choices">${q.options
      .map((opt, i) => {
        let cls = "choice";
        if (ui.picked === opt) cls += " is-picked";
        if (ui.phase === "feedback") {
          if (opt === q.answer) cls += " is-correct";
          else if (ui.picked === opt) cls += " is-wrong";
        }
        return `<button type="button" class="${cls}" data-act="pick" data-value="${esc(opt)}" ${ui.phase === "feedback" ? "disabled" : ""}><span class="choice-key">${keys[i]}</span><span class="choice-text">${esc(opt)}</span></button>`;
      })
      .join("")}</div>`;
  } else {
    body = `<input class="spell-input" name="answer" type="text" autocomplete="off" ${ui.phase === "feedback" ? "disabled" : ""} value="${esc(ui.picked || "")}" placeholder="输入答案">`;
  }
  const longStem = (q.type === "choice" || q.type === "spell") && String(q.prompt || "").length > 22;
  const promptClass = q.type === "cloze" || q.type === "match" ? "prompt is-cloze" : longStem ? "prompt is-stem" : "prompt";
  return `
    <section class="lesson-screen">
      <div class="lesson-body">
        <p class="hint">${esc(q.hint)}</p>
        <p class="${promptClass}">${esc(q.prompt)}</p>
        ${body}
      </div>
      ${lessonFooter(q)}
    </section>
  `;
}

function lessonFooter(q) {
  if (ui.phase === "feedback") {
    const good = ui.feedbackKind === "good";
    return `
      <div class="lesson-foot">
        <aside class="note-slip ${good ? "is-good" : "is-bad"}">
          <strong>${good ? "过" : "再看一眼"}</strong>
          <p>${esc(ui.feedback)}</p>
        </aside>
        <button class="btn ${good ? "" : "btn-seal"}" type="button" data-act="continue">继续</button>
      </div>
    `;
  }
  if (q.type === "match") {
    const remain = (q.pairs?.length || 0) - Object.keys(ui.match?.links || {}).length;
    return `<div class="lesson-foot"><p class="lede">${remain ? `再连 ${remain} 组` : "已全部连上"}</p></div>`;
  }
  const canCheck = q.type === "choice" ? Boolean(ui.picked) : false;
  return `<div class="lesson-foot"><button class="btn" type="button" data-act="check" ${canCheck ? "" : "disabled"}>核对</button></div>`;
}

function matchBoard(q) {
  const match = ui.match || { links: {}, picked: null };
  const used = new Set(Object.values(match.links));
  const left = q.left
    .map((item) => {
      const paired = Boolean(match.links[item.key]);
      const cls = [
        "match-item",
        "is-left",
        match.picked === item.key ? "is-selected" : "",
        paired ? "is-paired" : "",
        match.flash?.left === item.key ? `is-${match.flash.kind}` : "",
      ]
        .filter(Boolean)
        .join(" ");
      return `<button type="button" class="${cls}" data-act="match-left" data-key="${esc(item.key)}" ${paired ? "disabled" : ""}>${esc(item.label)}</button>`;
    })
    .join("");
  const right = q.right
    .map((item) => {
      const paired = used.has(item.key);
      const cls = ["match-item", paired ? "is-paired" : "", match.flash?.right === item.key ? `is-${match.flash.kind}` : ""]
        .filter(Boolean)
        .join(" ");
      return `<button type="button" class="${cls}" data-act="match-right" data-key="${esc(item.key)}" ${paired ? "disabled" : ""}>${esc(item.label)}</button>`;
    })
    .join("");
  return `<div class="match-board"><div class="match-col">${left}</div><div class="match-col">${right}</div></div>`;
}

function ensureMatchState(q) {
  if (q.type !== "match") {
    ui.match = null;
    return;
  }
  if (ui.match?.questionId === q.id) return;
  ui.match = { questionId: q.id, picked: null, links: {}, flash: null, busy: false };
}

function resultView() {
  const r = ui.session?.result;
  if (!r) return mapView();
  if (r.notebook) {
    return `
      <section class="screen center-card">
        <h1>${r.remaining === 0 ? "错题已清完" : `还剩 ${r.remaining} 词`}</h1>
        <p class="lede">正确 ${r.correct} / ${r.total}。${r.ink ? `获得 ${r.ink} 墨点。` : ""}</p>
        <div class="row" style="justify-content:center">
          ${r.remaining ? `<button class="btn" type="button" data-act="wrong-test">再测一次</button>` : ""}
          <button class="btn btn-ghost" type="button" data-act="${r.remaining ? "notebook" : "map"}">${r.remaining ? "返回错题本" : "回到日程"}</button>
        </div>
      </section>
    `;
  }
  const next = nextLevel();
  if (r.passed && next?.status === "gated") {
    return `
      <section class="screen center-card">
        <h1>试用关已结束</h1>
        <p class="lede">正确 ${r.correct} / ${r.total}。请监护人到官网选择 Pro 或 Max。Max 贵 20%，可第一时间得到免费周边。</p>
        <div class="row" style="justify-content:center">
          <button class="btn" type="button" data-act="upgrade">打开官网定价</button>
          <button class="btn btn-ghost" type="button" data-act="map">返回</button>
        </div>
      </section>
    `;
  }
  return `
    <section class="screen center-card">
      <h1>${r.passed ? (next ? "已解锁下一关" : "全部完成") : "还差一点"}</h1>
      <p class="lede">正确 ${r.correct} / ${r.total}${r.passed ? "" : `，未到 ${Math.round(r.line * 100)}%`}。${r.ink ? `获得 ${r.ink} 墨点。` : ""}错题已记入错题本。</p>
      <div class="row" style="justify-content:center">
        ${r.passed ? `<button class="btn" type="button" data-act="map">回到日程</button>` : `<button class="btn" type="button" data-act="retry">再练一次</button>`}
        <button class="btn btn-ghost" type="button" data-act="${r.passed ? "shop" : "notebook"}">${r.passed ? "去文具柜" : "错题本"}</button>
      </div>
    </section>
  `;
}

function settingsView() {
  return `
    <section class="screen">
      <p class="eyebrow">Kang Learn</p>
      <h1>设置</h1>
      <p class="lede">软件内不向未成年人收款。请监护人到官网付款后，在此确认档位。</p>
      <div class="form">
        <div class="tier-pick">
          ${tierRow("free", "未订阅", "学前 3 关")}
          ${tierRow("pro", "Pro", "解锁全部关卡")}
          ${tierRow("max", "Max", "贵 20%，优先得到免费周边")}
        </div>
        <div class="row">
          <button class="btn" type="button" data-act="upgrade">打开官网定价</button>
          <button class="btn btn-ghost" type="button" data-act="map-or-home">返回</button>
          <button class="btn btn-ghost" type="button" data-act="reset">清除本地计划</button>
        </div>
        <p class="notice">KangStudio · Kang Learn 0.1.0 · 全科目。文具柜兑换周边，不是题库商城。</p>
      </div>
    </section>
  `;
}

function tierRow(id, title, note) {
  return `
    <label>
      <span><strong>${title}</strong> · ${note}</span>
      <input type="radio" name="tier" data-act="tier" value="${id}" ${state.planTier === id ? "checked" : ""}>
    </label>
  `;
}

function upgradeSheet() {
  modalEl.hidden = false;
  modalEl.innerHTML = `
    <div class="sheet">
      <h2>继续学习需要升级</h2>
      <p class="lede">未订阅可学前 ${FREE_LEVELS} 关。请监护人到官网选择 Pro 或 Max。Max 贵 20%，可第一时间得到免费周边。软件内不收款。</p>
      <div class="row">
        <button class="btn" type="button" data-act="upgrade">打开官网</button>
        <button class="btn btn-ghost" type="button" data-act="close-modal">返回</button>
      </div>
    </div>
  `;
}

function onClick(event) {
  const btn = event.target.closest("[data-act]");
  if (!btn) {
    if (event.currentTarget === modalEl && event.target === modalEl) closeModal();
    return;
  }
  const act = btn.dataset.act;
  if (act === "login-mode") {
    ui.loginMode = btn.dataset.mode;
    ui.loginError = "";
    render();
    return;
  }
  if (act === "trial") {
    const form = document.querySelector("[data-form=login]");
    if (hasPassword(state.account)) {
      sessionOpen = true;
      ui.loginError = "";
      ui.view = state.plan ? "map" : "import";
      render();
      return;
    }
    enterApp(startGuest(form?.name?.value || "", form?.stay?.checked));
    return;
  }
  if (act === "logout") {
    sessionOpen = false;
    state.account = { ...state.account, stay: false };
    ui.view = "login";
    ui.loginMode = hasPassword(state.account) ? "enter" : "create";
    ui.loginError = "";
    persist();
    render();
    return;
  }
  if (act === "clear-account") {
    if (!window.confirm("清除本机账户后需重新创建。学习计划不会删除。确定？")) return;
    state.account = emptyAccount();
    sessionOpen = false;
    ui.view = "login";
    ui.loginMode = "create";
    ui.loginError = "";
    persist();
    render();
    return;
  }
  if (!sessionOpen) return;
  if (act === "home") {
    event.preventDefault();
    ui.view = state.plan ? "map" : "import";
    render();
  } else if (act === "settings") {
    ui.view = "settings";
    render();
  } else if (act === "notebook") {
    ui.notice = "";
    ui.session = null;
    ui.view = "notebook";
    render();
  } else if (act === "shop") {
    ui.notice = "";
    ui.view = "shop";
    render();
  } else if (act === "redeem") doRedeem(btn.dataset.id);
  else if (act === "wrong-test") startWrong("test");
  else if (act === "wrong-match") startWrong("match");
  else if (act === "match-left") pickMatchLeft(btn.dataset.key);
  else if (act === "match-right") pickMatchRight(btn.dataset.key);
  else if (act === "setup" || act === "import") {
    ui.notice = "";
    ui.view = "import";
    render();
  } else if (act === "sample") {
    beginFromParsed(parseMaterials(SAMPLE_TEXT), SAMPLE_SCOPE);
  } else if (act === "pick-file") document.getElementById("file")?.click();
  else if (act === "import-again") {
    ui.notice = "";
    ui.view = "import";
    render();
  } else if (act === "enter") startLevel(Number(btn.dataset.id));
  else if (act === "pick") {
    if (ui.phase !== "ask") return;
    pickChoice(btn.dataset.value);
  } else if (act === "check") checkCurrent();
  else if (act === "continue") advance();
  else if (act === "quit-lesson") {
    ui.session = null;
    ui.view = state.plan ? "map" : "import";
    render();
  } else if (act === "map" || act === "map-or-home") {
    ui.view = state.plan ? "map" : "import";
    ui.session = null;
    render();
  } else if (act === "retry") {
    if (ui.session?.source === "notebook") {
      startWrong(ui.session.kind === "wrong-match" ? "match" : "test");
      return;
    }
    if (ui.session?.levelId) startLevel(ui.session.levelId);
  } else if (act === "upgrade") openUpgrade();
  else if (act === "close-modal") closeModal();
  else if (act === "reset") {
    if (window.confirm("清除本机学习计划？不会影响官网订单。")) {
      const account = state.account;
      clearState();
      Object.assign(state, { plan: null, subscribed: false, planTier: "free", ink: 0, orders: [], account });
      persist();
      ui.view = "import";
      ui.session = null;
      ui.draft = { scope: "", days: 20, text: "" };
      render();
    }
  }
}

function onInput(event) {
  if (!event.target.classList.contains("spell-input")) return;
  const btn = document.querySelector("[data-act='check']");
  if (btn) btn.disabled = !event.target.value.trim();
}

function onChange(event) {
  const t = event.target;
  if (t.id === "file" && t.files?.[0]) ingestFile(t.files[0]);
  if (t.dataset.act === "tier") {
    state.planTier = t.value;
    state.subscribed = t.value === "pro" || t.value === "max";
    applySubscription(state.plan, state.subscribed);
    persist();
    render();
  }
  if (t.name === "text") ui.draft.text = t.value;
}

function onSubmit(event) {
  event.preventDefault();
  const form = event.target.closest("[data-form]");
  if (!form) return;
  if (form.dataset.form === "login") {
    submitLogin(form);
    return;
  }
  if (form.dataset.form === "import") {
    if (ui.busy) return;
    const data = new FormData(form);
    ui.draft.text = String(data.get("text") || "");
    startFromAiOrLocal({
      filename: "paste.txt",
      text: ui.draft.text,
      fallbackScope: ui.draft.scope || "我的资料",
    });
  }
}

async function submitLogin(form) {
  const name = form.name?.value || "";
  const password = form.password?.value || "";
  const confirm = form.confirm?.value || "";
  const stay = Boolean(form.stay?.checked);
  const creating = ui.loginMode === "create";
  if (!creating && !hasPassword(state.account)) {
    ui.loginError = "这台电脑还没有账户。请先创建，或先试用。";
    render();
    return;
  }
  if (creating) {
    if (password !== confirm) {
      ui.loginError = "两次密码不一致。";
      render();
      return;
    }
    const result = await createAccount(name, password, stay);
    if (!result.ok) {
      ui.loginError = result.error;
      render();
      return;
    }
    enterApp(result.account);
    return;
  }
  const result = await unlockAccount(state.account, password, stay);
  if (!result.ok) {
    ui.loginError = result.error;
    render();
    return;
  }
  enterApp(result.account);
}

function enterApp(account) {
  state.account = account;
  sessionOpen = true;
  ui.loginError = "";
  ui.view = state.plan ? "map" : "import";
  persist();
  render();
}

function onKey(event) {
  if (ui.view !== "play" || !ui.session) return;
  const q = ui.session.questions[ui.session.index];
  if (event.key === "Enter") {
    event.preventDefault();
    if (ui.phase === "feedback") advance();
    else checkCurrent();
    return;
  }
  if (ui.phase !== "ask" || q?.type !== "choice") return;
  const n = Number(event.key);
  if (n >= 1 && n <= q.options.length) {
    pickChoice(q.options[n - 1]);
  }
}

function startLevel(id) {
  const level = state.plan?.levels.find((l) => l.id === id);
  if (!level) return;
  if (level.status === "gated" && !state.subscribed) {
    upgradeSheet();
    return;
  }
  if (level.status === "locked") return;
  const session = makeSession(state.plan, level, state.subscribed);
  if (session.blocked === "gated") {
    upgradeSheet();
    return;
  }
  if (session.blocked === "empty" || !session.questions?.length) {
    ui.notice = "这一关还没有完整试题。请重新导入资料，让系统按小节出题。";
    render();
    return;
  }
  if (session.blocked) return;
  beginSession(session);
}

function startWrong(mode) {
  if (!state.plan) {
    ui.view = "import";
    render();
    return;
  }
  const session = makeWrongSession(state.plan, mode);
  if (session.blocked === "empty") {
    ui.view = "notebook";
    render();
    return;
  }
  if (session.blocked === "need-meaning") {
    ui.notice = "连线测试需要至少两个带释义的错词。";
    ui.view = "notebook";
    render();
    return;
  }
  ui.notice = "";
  beginSession(session);
}

function beginSession(session) {
  ui.session = session;
  ui.picked = null;
  ui.phase = "ask";
  ui.match = null;
  ui.view = "play";
  render();
  window.setTimeout(() => document.querySelector(".spell-input")?.focus(), 30);
}

function checkCurrent() {
  const session = ui.session;
  if (!session || ui.phase !== "ask") return;
  const q = session.questions[session.index];
  if (!q || q.type === "match") return;
  const value =
    q.type === "choice" ? ui.picked : String(document.querySelector(".spell-input")?.value || "").trim();
  if (!value) return;
  const correct = gradeQuestion(q, value);
  session.answers.push({ itemId: q.itemId, correct, given: value });
  ui.picked = value;
  ui.phase = "feedback";
  ui.feedbackKind = correct ? "good" : "bad";
  ui.feedback = correct ? "可以进入下一题" : `正确答案：${q.answer}`;
  render();
}

function pickChoice(value) {
  if (ui.phase !== "ask") return;
  ui.picked = value;
  viewEl.querySelectorAll(".choice").forEach((el) => {
    const on = el.dataset.value === value;
    const was = el.classList.contains("is-picked");
    el.classList.toggle("is-picked", on);
    el.classList.remove("is-picking");
    if (on && !was) {
      void el.offsetWidth;
      el.classList.add("is-picking");
    }
  });
  const check = viewEl.querySelector("[data-act='check']");
  if (check) check.disabled = false;
}

function pickMatchLeft(key) {
  if (!ui.match || ui.match.busy || ui.phase !== "ask") return;
  if (ui.match.links[key]) return;
  ui.match.picked = ui.match.picked === key ? null : key;
  viewEl.querySelectorAll(".match-item.is-left").forEach((el) => {
    const on = el.dataset.key === ui.match.picked;
    const was = el.classList.contains("is-selected");
    el.classList.toggle("is-selected", on);
    el.classList.remove("is-picking");
    if (on && !was) {
      void el.offsetWidth;
      el.classList.add("is-picking");
    }
  });
}

function pickMatchRight(meaning) {
  const session = ui.session;
  const q = session?.questions[session.index];
  if (!q || q.type !== "match" || !ui.match || ui.match.busy || ui.phase !== "ask") return;
  const word = ui.match.picked;
  if (!word) {
    ui.notice = "";
    return;
  }
  const correct = q.answer[word] === meaning;
  ui.match.busy = true;
  ui.match.links[word] = meaning;
  ui.match.picked = null;
  ui.match.flash = { left: word, right: meaning, kind: correct ? "correct" : "wrong" };
  session.answers.push({
    itemId: q.pairs.find((p) => p.word === word)?.itemId,
    correct,
    given: meaning,
  });
  render();
  const done = correct && Object.keys(ui.match.links).length >= q.pairs.length;
  window.setTimeout(() => {
    if (!ui.match) return;
    ui.match.busy = false;
    if (!correct) delete ui.match.links[word];
    ui.match.flash = null;
    if (done) {
      ui.phase = "feedback";
      ui.feedbackKind = "good";
      ui.feedback = "全部连上了";
    }
    render();
  }, 380);
}

function advance() {
  const session = ui.session;
  if (!session) return;
  ui.picked = null;
  ui.phase = "ask";
  session.index += 1;
  if (session.index < session.questions.length) {
    render();
    window.setTimeout(() => document.querySelector(".spell-input")?.focus(), 30);
    return;
  }
  const result = applyResult(state.plan, session, state.subscribed);
  const ink = (result.correct || 0) * INK_CORRECT + (result.passed ? INK_PASS_BONUS : 0);
  result.ink = ink;
  state.ink += ink;
  session.result = result;
  persist();
  ui.view = "result";
  render();
  if (result.passed && session.source !== "notebook") showPass();
}

function doRedeem(itemId) {
  const result = redeem(state, itemId);
  if (!result.ok) {
    ui.notice = "墨点不够。过关可以积累墨点。";
    render();
    return;
  }
  persist();
  ui.notice = result.free
    ? `已为 Max 登记免费「${result.item.name}」，将优先发货。`
    : `已登记「${result.item.name}」。${result.priority ? "Max 订单优先发货。" : "开通寄送后由监护人在官网确认地址。"}`;
  render();
}

function showPass() {
  const colors = ["#9b3a2f", "#c4a36a", "#1f5a40", "#e8d9c4", "#1c1915", "#9b3a2f"];
  const ribbons = Array.from({ length: 32 }, (_, i) => {
    const left = Math.round((i * 17 + (i % 5) * 11) % 100);
    const delay = ((i % 8) * 0.03).toFixed(2);
    const dur = (0.9 + (i % 5) * 0.08).toFixed(2);
    const rot = -70 + ((i * 23) % 140);
    const w = 5 + (i % 5);
    const h = 26 + (i % 7) * 6;
    return `<span class="pass-ribbon" style="--x:${left}%;--d:${delay}s;--t:${dur}s;--r:${rot}deg;--w:${w}px;--h:${h}px;background:${colors[i % colors.length]}"></span>`;
  }).join("");
  overlayEl.hidden = false;
  overlayEl.classList.remove("is-out");
  overlayEl.innerHTML = `<div class="pass-burst">${ribbons}<p class="pass-word">过关</p></div>`;
  overlayEl.classList.add("is-in");
  window.setTimeout(() => overlayEl.classList.add("is-out"), 980);
  window.setTimeout(() => {
    overlayEl.hidden = true;
    overlayEl.classList.remove("is-in", "is-out");
    overlayEl.innerHTML = "";
  }, 1280);
}

function closeModal() {
  modalEl.hidden = true;
  modalEl.innerHTML = "";
}

async function openUpgrade() {
  closeModal();
  if (window.kangDesktop?.openSite) {
    await window.kangDesktop.openSite(UPGRADE_URL);
    return;
  }
  window.open(UPGRADE_URL, "_blank", "noopener");
}

function nextLevel() {
  if (!state.plan || !ui.session) return null;
  const idx = state.plan.levels.findIndex((l) => l.id === ui.session.levelId);
  if (idx < 0) return null;
  return state.plan.levels[idx + 1] || null;
}

function suggestDays(parsed) {
  const words = parsed.words?.length || 0;
  const sents = parsed.sentences?.length || 0;
  if (words >= 1) return clampDays(Math.ceil(words / WORDS_PER_DAY));
  if (sents >= 1) return clampDays(Math.ceil(sents / 3));
  return MIN_DAYS;
}

function scopeFromFile(name) {
  return String(name || "")
    .replace(/\.[^.]+$/, "")
    .replace(/[_]+/g, " ")
    .trim() || "我的资料";
}

function beginFromParsed(parsed, scope) {
  const words = parsed.words || [];
  const sentences = parsed.sentences || [];
  const hasQuestions = (parsed.groups || []).some((g) => g.questions?.length);
  if (!words.length && !sentences.length && !hasQuestions) {
    ui.busy = false;
    ui.notice = "没有识别到可练习的内容。每行一条「术语  释义」，或导入笔记、词表、课文。";
    ui.view = "import";
    render();
    return false;
  }
  const days = parsed.groups?.length || suggestDays(parsed);
  state.plan = buildPlan({
    scope: String(scope || "").trim() || "我的资料",
    days,
    requestedDays: days,
    words: words,
    sentences: sentences,
    groups: parsed.groups,
    subject: parsed.subject,
  });
  sanitizePlan(state.plan);
  applySubscription(state.plan, state.subscribed);
  persist();
  ui.notice = "";
  ui.busy = false;
  ui.draft.text = "";
  ui.session = null;
  ui.view = "map";
  render();
  return true;
}

function analyzeError(code) {
  return (
    {
      "no-key": "还没有配置 DeepSeek 密钥。",
      "bad-key": "DeepSeek 密钥无效。",
      network: "连不上 DeepSeek，请检查网络。",
      timeout: "分析超时，请换一份短一点的资料。",
      empty: "没能根据这份资料出题。",
      extract: "这个文件打不开。",
      "too-large": "文件超过 8MB。",
      "old-doc": "旧版 .doc 请另存为 .docx。",
      "no-proxy": "分析服务没开。请用 npm run web 打开本页。",
      quota: "DeepSeek 额度不足。",
      busy: "DeepSeek 正忙，请稍后再试。",
      upstream: "DeepSeek 没能处理这份文档。",
    }[code] || "分析失败。"
  );
}

async function arrangeRemote({ filename, text, bytes }) {
  if (window.kangDesktop?.analyzeFile) {
    return window.kangDesktop.analyzeFile({
      name: filename,
      text,
      bytes: bytes ? Array.from(bytes) : undefined,
    });
  }
  const payload = {
    filename: filename || "material.txt",
    text: text || "",
    base64: bytes && bytes.length ? bytesToBase64(bytes) : undefined,
  };
  const urls = ["/api/analyze"];
  if (location.hostname === "localhost" || location.hostname === "127.0.0.1") {
    urls.push("http://127.0.0.1:5173/api/analyze", "http://127.0.0.1:5180/api/analyze");
  }
  let last = null;
  for (const url of [...new Set(urls)]) {
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok) throw new Error(data?.error || `http-${res.status}`);
      if (data) return data;
    } catch (err) {
      last = err;
    }
  }
  throw last || new Error("no-proxy");
}

function bytesToBase64(bytes) {
  const chunk = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

async function startFromAiOrLocal({ filename, text, bytes, fallbackScope }) {
  if (ui.busy) return false;
  ui.busy = true;
  ui.notice = "正在根据资料出题并排关…";
  ui.view = "import";
  render();
  let local = parseMaterials(text || "");
  try {
    const ai = await arrangeRemote({ filename, text, bytes });
    const quizCount = (ai?.groups || []).reduce((n, g) => n + (g.questions?.length || 0), 0);
    if (ai?.ok && (quizCount >= 3 || looksLikeVocab(ai))) {
      return beginFromParsed(
        { words: ai.words || [], sentences: ai.sentences || [], groups: ai.groups, subject: ai.subject },
        ai.scope || fallbackScope,
      );
    }
    if (ai?.extracted) {
      const fromFile = parseMaterials(ai.extracted);
      if (looksLikeVocab(fromFile)) local = fromFile;
    }
    if (ai && !ai.ok) ui.notice = `${analyzeError(ai.error)} 请再试一次。`;
    else if (ai?.ok) ui.notice = "没能根据这份资料写出完整试题，请再试一次。";
  } catch (err) {
    const code = String(err?.message || "");
    const noProxy = /fetch|Load failed|http-|network/i.test(code);
    ui.notice = `${analyzeError(noProxy ? "no-proxy" : code)} 请再试一次。`;
  }
  ui.busy = false;
  if (looksLikeVocab(local)) {
    return beginFromParsed(local, fallbackScope);
  }
  if (!ui.notice || ui.notice.startsWith("正在")) {
    ui.notice = "没能根据这份资料出题。知识点讲义请再导入一次，词表可按「术语  释义」一行一条。";
  }
  ui.view = "import";
  render();
  return false;
}

function ingestFile(file) {
  if (!file || ui.busy) return;
  const name = file.name || "material.txt";
  file
    .arrayBuffer()
    .then((buf) => {
      const isText = /\.(txt|csv|tsv|md)$/i.test(name);
      const bytes = new Uint8Array(buf);
      const text = isText ? decodeBest(buf) : "";
      ui.draft.scope = scopeFromFile(name);
      ui.draft.text = text;
      return startFromAiOrLocal({
        filename: name,
        text,
        bytes: isText ? undefined : bytes,
        fallbackScope: ui.draft.scope,
      });
    })
    .catch(() => {
      ui.busy = false;
      ui.notice = "这个文件读不出来。";
      ui.view = "import";
      render();
    });
}

function decodeBest(buf) {
  const bytes = new Uint8Array(buf);
  if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe) {
    return new TextDecoder("utf-16le").decode(buf);
  }
  if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) {
    return new TextDecoder("utf-16be").decode(buf);
  }
  const utf8 = new TextDecoder("utf-8").decode(buf);
  const utf8Parsed = parseMaterials(utf8);
  if (utf8Parsed.words.length || utf8Parsed.sentences.length) return utf8;
  for (const enc of ["gbk", "gb18030"]) {
    try {
      const text = new TextDecoder(enc).decode(buf);
      const parsed = parseMaterials(text);
      if (parsed.words.length || parsed.sentences.length) return text;
    } catch {
      /* some browsers do not decode gbk */
    }
  }
  return utf8;
}

function onDragOver(event) {
  if (ui.view !== "import" && ui.view !== "setup") return;
  event.preventDefault();
  viewEl.querySelector(".dropzone")?.classList.add("is-over");
}

function onDrop(event) {
  if (ui.view !== "import" && ui.view !== "setup") return;
  event.preventDefault();
  viewEl.querySelector(".dropzone")?.classList.remove("is-over");
  const file = event.dataTransfer?.files?.[0];
  if (file) ingestFile(file);
}

function clampDays(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 20;
  return Math.min(MAX_DAYS, Math.max(MIN_DAYS, Math.round(n)));
}

function esc(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function logoSvg() {
  return `<svg class="brand-mark" viewBox="0 0 32 32" width="20" height="20" aria-hidden="true">
    <rect width="32" height="32" rx="8" fill="currentColor"/>
    <path fill="#f3efe6" d="M11 8h3.1v6.15L20.2 8H24l-6.7 7.35L24.2 24H20.3l-6.2-7.4V24H11V8z"/>
  </svg>`;
}

function goodsArt(kind) {
  if (kind === "pen") {
    return `<svg width="64" height="16" viewBox="0 0 64 16" aria-hidden="true">
      <rect x="2" y="6" width="46" height="4" rx="2" fill="#1c1915"/>
      <path d="M48 5l14 3-14 3z" fill="#9b3a2f"/>
    </svg>`;
  }
  if (kind === "book") {
    return `<svg width="52" height="40" viewBox="0 0 52 40" aria-hidden="true">
      <rect x="4" y="4" width="40" height="32" rx="4" fill="#1c1915"/>
      <rect x="10" y="4" width="34" height="32" rx="3" fill="#fbf7f0"/>
      <path d="M16 14h22M16 20h18" stroke="#c4a36a" stroke-width="2"/>
    </svg>`;
  }
  return `<svg width="56" height="36" viewBox="0 0 56 36" aria-hidden="true">
    <rect x="4" y="6" width="48" height="28" rx="4" fill="#fbf7f0" stroke="#1c1915"/>
    <rect x="8" y="2" width="18" height="12" rx="2" fill="#9b3a2f"/>
  </svg>`;
}
