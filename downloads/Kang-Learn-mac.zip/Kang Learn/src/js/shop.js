export const CATALOG = [
  {
    id: "postcard",
    name: "单词明信片",
    blurb: "四张一套，正面空白可写今日新词。",
    cost: 400,
    kind: "postcard",
    maxFirst: true,
  },
  {
    id: "pencil",
    name: "HB 铅笔",
    blurb: "练默写用，笔芯不易断。",
    cost: 780,
    kind: "pen",
  },
  {
    id: "notebook",
    name: "方格练习本",
    blurb: "A5 四十页，适合抄词和改错。",
    cost: 1500,
    kind: "book",
  },
  {
    id: "fountain",
    name: "墨水钢笔",
    blurb: "练字用。墨水另配。",
    cost: 2400,
    kind: "pen",
  },
];

export function redeem(state, itemId) {
  const item = CATALOG.find((entry) => entry.id === itemId);
  if (!item) return { ok: false, reason: "missing" };
  const isMax = state.planTier === "max";
  const usedFree = (state.orders || []).some((order) => order.itemId === item.id && order.free);
  const free = Boolean(isMax && item.maxFirst && !usedFree);
  const cost = free ? 0 : item.cost;
  if ((Number(state.ink) || 0) < cost) return { ok: false, reason: "ink" };
  state.ink -= cost;
  state.orders = state.orders || [];
  state.orders.push({
    itemId: item.id,
    name: item.name,
    at: Date.now(),
    cost,
    free,
    priority: isMax,
  });
  return { ok: true, item, cost, free, priority: isMax };
}

export function orderCount(state, itemId) {
  return (state.orders || []).filter((order) => order.itemId === itemId).length;
}
