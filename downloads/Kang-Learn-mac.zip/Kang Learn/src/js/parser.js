import { MAX_SENTENCES, MAX_WORDS } from "./config.js";
import { isJunkItem, isLatinScrap, tidyTerm } from "./quality.js";

const WORD_LINE =
  /^([A-Za-z][A-Za-z''.-]{0,42})\s*(?:[,，\t|]|-{1,2}|—|－)\s*(.+)$/;
const WORD_SPACES = /^([A-Za-z][A-Za-z''.-]{0,42})\s{2,}(.+)$/;
const WORD_CN = /^([A-Za-z][A-Za-z''.-]{0,42})\s+([\u4e00-\u9fff].+)$/;
const WORD_ONLY = /^[A-Za-z][A-Za-z''.-]{0,42}$/;
const TERM_LINE = /^(.{1,40}?)(?:\s{2,}|[,，\t|]|：|:|——)\s*(.{1,90})$/;

export function parseMaterials(text) {
  const lines = String(text || "")
    .replace(/^\uFEFF/, "")
    .split(/\r?\n/);

  const words = [];
  const seen = new Set();
  const passageLines = [];

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (/^(word|单词|english|vocab|术语|知识点)/i.test(line) && line.split(/[,，\t]/).length <= 3) {
      continue;
    }

    const parsed = parseWordLine(line);
    if (parsed) {
      const key = parsed.word.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        words.push(parsed);
      }
      continue;
    }

    if (WORD_ONLY.test(line) && line.length > 2 && !isLatinScrap(line)) {
      const key = line.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        words.push({ word: line, meaning: "" });
      }
      continue;
    }

    passageLines.push(line);
  }

  const sentences = splitSentences(passageLines.join(" ")).slice(0, MAX_SENTENCES);
  return {
    words: words.slice(0, MAX_WORDS),
    sentences,
  };
}

function parseWordLine(line) {
  if (line.length > 120) return null;
  const match = line.match(WORD_LINE) || line.match(WORD_SPACES) || line.match(WORD_CN) || line.match(TERM_LINE);
  if (!match) return null;
  const word = tidyTerm(match[1].replace(/[.]/g, "").trim());
  const meaning = match[2].replace(/^["'“”]|["'“”]$/g, "").trim();
  if (isJunkItem(word, meaning, false)) return null;
  if (word === meaning) return null;
  return { word, meaning };
}

export function looksLikeVocab(parsed) {
  const words = parsed?.words || [];
  if (words.length < 4) return false;
  const latin = words.filter((w) => /^[A-Za-z]/.test(String(w.word || "")) && w.meaning).length;
  return latin / words.length > 0.6;
}

export function splitSentences(text) {
  return String(text || "")
    .split(/(?<=[.!?。！？])\s*/)
    .map((s) => s.trim())
    .filter((s) => {
      if (!s) return false;
      if (/[\u4e00-\u9fff]/.test(s)) return s.length >= 8;
      return s.split(/\s+/).length >= 6;
    });
}

export function previewStats(parsed) {
  const withMeaning = parsed.words.filter((w) => w.meaning).length;
  return {
    wordCount: parsed.words.length,
    meaningCount: withMeaning,
    sentenceCount: parsed.sentences.length,
  };
}
