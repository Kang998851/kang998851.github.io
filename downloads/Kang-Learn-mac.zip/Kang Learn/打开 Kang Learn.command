#!/bin/bash
cd "$(dirname "$0")"
if ! command -v npm >/dev/null 2>&1; then
  open "https://nodejs.org/"
  osascript -e 'display dialog "请先安装 Node.js，然后再双击打开 Kang Learn。" buttons {"好"} default button 1' >/dev/null 2>&1 || true
  exit 1
fi
if [ ! -d node_modules/electron ]; then
  npm install
fi
npm start
