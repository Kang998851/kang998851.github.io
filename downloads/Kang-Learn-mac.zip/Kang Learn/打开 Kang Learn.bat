@echo off
cd /d "%~dp0"
where npm >nul 2>nul
if errorlevel 1 (
  start https://nodejs.org/
  echo 请先安装 Node.js，然后再打开 Kang Learn。
  pause
  exit /b 1
)
if not exist "node_modules\electron" npm install
call npm start
